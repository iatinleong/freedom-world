# SQL 助手 POC 說明報告

## 1. 目的

本資料夾整理了 5 個報表題目，原始目的為提供外部廠商進行 SQL 助手 POC 驗證。  
因正式資料不可直接提供，因此另外建立一套「可執行、可重跑、不可回推真實客戶」的虛擬資料環境，用來：

1. 模擬這 5 個題目會用到的資料表。
2. 讓廠商能在不接觸真實資料的情況下理解 SQL 結構。
3. 驗證 SQL 執行後的輸出欄位與資料型態。
4. 作為後續 prompt、schema mapping、SQL 生成能力測試的基底。

## 2. 本次交付內容

本次已產出以下檔案：

- [output/mock_tables.xlsx](C:\Users\user\Desktop\專案\小sql題目\output\mock_tables.xlsx)
- [output/sql_results.xlsx](C:\Users\user\Desktop\專案\小sql題目\output\sql_results.xlsx)
- [output/mock_table_schema.json](C:\Users\user\Desktop\專案\小sql題目\output\mock_table_schema.json)
- [output/sql_results.json](C:\Users\user\Desktop\專案\小sql題目\output\sql_results.json)
- [output/run_summary.json](C:\Users\user\Desktop\專案\小sql題目\output\run_summary.json)

另外提供可重跑程式：


- [scripts/read_dictionary_schema.ps1](C:\Users\user\Desktop\專案\小sql題目\scripts\read_dictionary_schema.ps1)
##  `read_dictionary_schema.ps1` 的用途（不一定要跑）

[`scripts/read_dictionary_schema.ps1`](C:\Users\user\Desktop\專案\小sql題目\scripts\read_dictionary_schema.ps1) 不是拿來直接跑報表 SQL 的，它的角色是「讀 schema」。

它會先去讀：

- [證券資料字典2.xlsx](C:\Users\user\Desktop\專案\小sql題目\證券資料字典2.xlsx)

然後把這次 POC 用到的表欄位資訊抽出來，提供給 [`scripts/generate_mock_sql_env.js`](C:\Users\user\Desktop\專案\小sql題目\scripts\generate_mock_sql_env.js) 使用。

它主要做三件事：

1. 抽出這次會用到的表名稱。
2. 抽出欄位名稱與欄位型別，例如 `VARCHAR2`、`NUMBER`、`DATE`。
3. 產出 mock DB 建表時需要的 schema 依據。

簡單講：

- `read_dictionary_schema.ps1` = 讀資料字典、整理 schema
- `generate_mock_sql_env.js` = 建 mock data、跑 SQL、輸出結果

##  為何需要重跑

並不是每次都一定要重跑。  
如果以下內容都沒有改，直接使用既有輸出即可：

- `證券資料字典2.xlsx`
- 原始 SQL
- mock data 生成規則

以下情況才建議重跑：

1. 你修改了 SQL。
2. 你調整了 mock data 的資料量或分布。
3. 你更新了資料字典欄位定義。
4. 你需要重新產出 `xlsx` 或 `json` 結果檔。


- [scripts/generate_mock_sql_env.js](C:\Users\user\Desktop\專案\小sql題目\scripts\generate_mock_sql_env.js)
## 如何跑generate_mock_sql_env.js（一定要跑）

在目前資料夾下執行：

```powershell
node scripts\generate_mock_sql_env.js
```

程式會：

1. 讀取 `證券資料字典2.xlsx`
2. 解析需要的 schema
3. 建立 in-memory SQLite 測試環境
4. 載入 mock data
5. 執行 5 個 folder 內的 SQL 邏輯
6. 重新輸出 xlsx 與 json

若 `mock_tables.xlsx` 或 `sql_results.xlsx` 正被 Excel 開啟，程式會自動改存新檔名，不會整個失敗。


## 3. 五個題目與用途

### 題目 1: `561`

主題為桃園分公司信用戶資料，輸出內容包含：

- 營業員資訊
- 客戶帳號與姓名
- 開戶日期
- 信用戶開戶日期
- 融資交易量
- 融券交易量

### 題目 2: `565`

主題為桃園分公司台股客戶的下單通路分析，輸出內容包含：

- E點通
- e+APP
- NEWONLINE
- 其他電子下單
- 非電子下單

### 題目 3: `客戶上送活動(2024Q4 & 2025Q1)的明細資料`

此 folder 內實際有 2 段查詢：

1. 2024Q4 上送活動
2. 2025Q1 上送活動

輸出內容包含：

- 營業員資訊
- 客戶帳號
- 上升前客群
- 本季交易量
- 上送成功與否

### 題目 4: `請協助撈取樹林分公司11月、12月營業員台、美股定期定額及美股實動(含定期定額)戶數`

主題為樹林分公司按營業員統計：

- 名下客戶數
- 美股累計實動戶數
- 美股定期定額累計實動戶數
- 台股定期定額累計實動戶數

### 題目 5: `請協助撈取離退同仁客戶交易狀況`

主題為樹林分公司離退同仁名下客戶的完整交易與貢獻概況，輸出內容包含：

- 離退營業員與接手營業員資訊
- 客戶帳號與證號
- ABCD 客群與現況客群
- 2023、2024 交易量
- 每月交易量
- 台股庫存
- 經紀貢獻度
- 財管貢獻度
- 雙向借券、不限用途借貸、基金、海外債、海外股票
- 期貨選擇權口數

## 4. 本次用到的資料表

### 4.1 來自 `證券資料字典2.xlsx` 的表

以下表格可從資料字典直接取得欄位定義：

- `M_AC_ACCOUNT`
- `M_AT_STOCK_TXN`
- `M_AT_ACCOUNT_TXN`
- `M_AC_ACCOUNT_INVENTORY`
- `M_AC_ACCOUNT_REVENUE`
- `M_AC_ACCOUNT_PROD_TXN`

### 4.2 字典中未找到、由 SQL 反推 schema 的表

以下表格未在 `證券資料字典2.xlsx` 中找到完整定義，因此以 SQL 實際使用欄位反推最小可執行 schema：

- `CSCD`
- `PARTY_NAME`
- `ES_PROJECTDATA`
- `D_S_ACCT_COMBINE`
- `D_S_CHANNEL`
- `D_S_SALES_AGENT_DAILY`
- `CD客群上送名單_2409_含G`
- `台股上送名單2025Q1`
- `樹林離退_20240801`
- `PARTY_NAME_ASOF_20241130`
- `經紀客群2024Q3_雙證`

## 5. 各題目對應的主要表

### 561

- `M_AC_ACCOUNT`
- `M_AT_STOCK_TXN`
- `CSCD`
- `PARTY_NAME`

### 565

- `M_AC_ACCOUNT`
- `M_AT_STOCK_TXN`
- `PARTY_NAME`

### 客戶上送活動

- `ES_PROJECTDATA`
- `D_S_ACCT_COMBINE`
- `D_S_CHANNEL`
- `D_S_SALES_AGENT_DAILY`
- `CD客群上送名單_2409_含G`
- `台股上送名單2025Q1`
- `M_AC_ACCOUNT`
- `M_AT_STOCK_TXN`

### 樹林分公司累計戶數

- `M_AC_ACCOUNT`
- `M_AT_STOCK_TXN`

### 離退同仁客戶交易狀況

- `樹林離退_20240801`
- `M_AC_ACCOUNT`
- `PARTY_NAME_ASOF_20241130`
- `經紀客群2024Q3_雙證`
- `M_AT_ACCOUNT_TXN`
- `M_AC_ACCOUNT_INVENTORY`
- `M_AC_ACCOUNT_REVENUE`
- `M_AC_ACCOUNT_PROD_TXN`

## 6. 虛擬資料生成原則

本次並非單純隨機造數，而是依照 SQL 的過濾條件與輸出欄位需求建立可執行資料，原則如下：

1. 保留真實查詢會使用的 key 欄位關係。
2. 保留分公司、營業員、帳號、客戶證號之間的一致性。
3. 保留活動期間、月份區間、產品別、通路別、交易型別等查詢條件。
4. 讓部分資料會命中條件、部分不命中，避免結果過於單一。
5. 所有姓名、帳號、客戶代碼均為虛擬內容，無法回推真實人員與客戶。

## 7. 目前資料量

本次已調整為較適合 POC 驗證的中型測試集。

主要表筆數如下：

- `M_AC_ACCOUNT`: 129
- `M_AT_STOCK_TXN`: 864
- `M_AT_ACCOUNT_TXN`: 864
- `M_AC_ACCOUNT_REVENUE`: 720
- `M_AC_ACCOUNT_PROD_TXN`: 396
- `M_AC_ACCOUNT_INVENTORY`: 36

其他輔助表筆數如下：

- `CSCD`: 24
- `PARTY_NAME`: 69
- `ES_PROJECTDATA`: 18
- `D_S_ACCT_COMBINE`: 24
- `D_S_CHANNEL`: 1
- `D_S_SALES_AGENT_DAILY`: 3
- `CD客群上送名單_2409_含G`: 18
- `台股上送名單2025Q1`: 12
- `樹林離退_20240801`: 12
- `PARTY_NAME_ASOF_20241130`: 36
- `經紀客群2024Q3_雙證`: 36

## 8. SQL 執行結果摘要

目前 6 個查詢結果筆數如下：

- `561_credit_accounts`: 24
- `565_channel_mix`: 45
- `campaign_2024q4`: 18
- `campaign_2025q1`: 12
- `shulin_monthly_counts`: 3
- `retired_sales_overview`: 12

說明：

- 因「客戶上送活動」folder 內含 2 段查詢，因此結果 sheet 共有 6 份。
- `sql_results.xlsx` 已將每段查詢輸出獨立成 sheet。







## 12. 適用範圍與限制

### 適用範圍

- SQL 助手 POC
- schema 理解測試
- SQL 生成測試
- SQL 改寫與解釋測試
- 報表欄位映射驗證

### 限制

1. 本資料並非真實業務分布，只是為了讓 SQL 可執行且結果具代表性。
2. 部分表格因資料字典未提供完整定義，因此 schema 為 SQL 反推的最小可用版本。
3. 若後續廠商要做成本估算、效能測試、索引策略或大規模 SQL 壓測，建議再擴充資料量。
4. 若要做更完整的語意測試，建議補更多 edge cases，例如空值比例、異常日期、多分公司同客戶、無交易但有庫存等情境。

