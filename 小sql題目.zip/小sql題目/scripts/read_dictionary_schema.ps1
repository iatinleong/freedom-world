param(
    [Parameter(Mandatory = $true)]
    [string]$WorkbookPath,

    [Parameter(Mandatory = $true)]
    [string[]]$TableNames
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

Add-Type -AssemblyName System.IO.Compression.FileSystem

function Get-EntryText {
    param(
        [Parameter(Mandatory = $true)]
        [System.IO.Compression.ZipArchive]$Zip,

        [Parameter(Mandatory = $true)]
        [string]$EntryName
    )

    $entry = $Zip.GetEntry($EntryName)
    if (-not $entry) {
        throw "Entry not found: $EntryName"
    }

    $reader = [System.IO.StreamReader]::new($entry.Open())
    try {
        return $reader.ReadToEnd()
    }
    finally {
        $reader.Dispose()
    }
}

function Get-CellValue {
    param(
        [Parameter(Mandatory = $true)]
        $Cell,

        [Parameter(Mandatory = $true)]
        [string[]]$SharedStrings
    )

    $valueNode = $Cell.SelectSingleNode('d:v', $script:SheetNs)
    if (-not $valueNode) {
        return ''
    }

    $cellType = $Cell.GetAttribute('t')
    if ($cellType -eq 's') {
        return $SharedStrings[[int]$valueNode.InnerText]
    }

    return $valueNode.InnerText
}

$resolvedPath = (Resolve-Path $WorkbookPath).Path
$zip = [System.IO.Compression.ZipFile]::OpenRead($resolvedPath)

try {
    [xml]$sharedXml = Get-EntryText -Zip $zip -EntryName 'xl/sharedStrings.xml'
    $sharedNs = [System.Xml.XmlNamespaceManager]::new($sharedXml.NameTable)
    $sharedNs.AddNamespace('d', 'http://schemas.openxmlformats.org/spreadsheetml/2006/main')
    $sharedStrings = @()
    foreach ($si in $sharedXml.SelectNodes('//d:si', $sharedNs)) {
        $texts = $si.SelectNodes('.//d:t', $sharedNs) | ForEach-Object { $_.InnerText }
        $sharedStrings += ($texts -join '')
    }

    [xml]$sheetXml = Get-EntryText -Zip $zip -EntryName 'xl/worksheets/sheet1.xml'
    $script:SheetNs = [System.Xml.XmlNamespaceManager]::new($sheetXml.NameTable)
    $script:SheetNs.AddNamespace('d', 'http://schemas.openxmlformats.org/spreadsheetml/2006/main')

    $rows = $sheetXml.SelectNodes('//d:sheetData/d:row', $script:SheetNs)
    $headerMap = @{}

    foreach ($cell in $rows[0].SelectNodes('d:c', $script:SheetNs)) {
        $columnRef = ($cell.r -replace '\d', '')
        $headerMap[$columnRef] = Get-CellValue -Cell $cell -SharedStrings $sharedStrings
    }

    $tableSet = [System.Collections.Generic.HashSet[string]]::new([string[]]$TableNames)
    $result = @{}

    foreach ($row in $rows | Select-Object -Skip 1) {
        $record = @{}
        foreach ($cell in $row.SelectNodes('d:c', $script:SheetNs)) {
            $columnRef = ($cell.r -replace '\d', '')
            $header = $headerMap[$columnRef]
            if ($header) {
                $record[$header] = Get-CellValue -Cell $cell -SharedStrings $sharedStrings
            }
        }

        $tableName = $record['表格名稱']
        if (-not $tableName -or -not $tableSet.Contains($tableName)) {
            continue
        }

        if (-not $result.ContainsKey($tableName)) {
            $result[$tableName] = @()
        }

        $result[$tableName] += [PSCustomObject]@{
            name        = $record['欄位名稱']
            zh_name     = $record['欄位中文名稱(BT)']
            data_type   = $record['欄位資料型態']
            pk_flag     = $record['Primary_Key']
            description = $record['欄位定義說明(Definition)']
            source      = 'dictionary'
        }
    }

    $result | ConvertTo-Json -Depth 6
}
finally {
    $zip.Dispose()
}
