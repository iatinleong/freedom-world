const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const crypto = require('node:crypto');
const { execFileSync } = require('node:child_process');
const { DatabaseSync } = require('node:sqlite');

const rootDir = path.resolve(__dirname, '..');
const outputDir = path.join(rootDir, 'output');
const dictionaryPath = path.join(rootDir, '證券資料字典2.xlsx');
const schemaReaderPath = path.join(__dirname, 'read_dictionary_schema.ps1');

const dictionaryTables = [
  'M_AC_ACCOUNT',
  'M_AT_STOCK_TXN',
  'M_AT_ACCOUNT_TXN',
  'M_AC_ACCOUNT_INVENTORY',
  'M_AC_ACCOUNT_REVENUE',
  'M_AC_ACCOUNT_PROD_TXN',
];

const inferredSchemas = {
  CSCD: [
    { name: 'BHNO', data_type: 'VARCHAR2(10 byte)', source: 'inferred' },
    { name: 'ACNO', data_type: 'VARCHAR2(11 byte)', source: 'inferred' },
    { name: 'ODATE', data_type: 'DATE(7 byte)', source: 'inferred' },
  ],
  PARTY_NAME: [
    { name: 'ACCT_NBR', data_type: 'VARCHAR2(11 byte)', source: 'inferred' },
    { name: 'PARTY_NAME', data_type: 'VARCHAR2(100 byte)', source: 'inferred' },
  ],
  ES_PROJECTDATA: [
    { name: 'PROJECT_NO', data_type: 'VARCHAR2(20 byte)', source: 'inferred' },
    { name: 'BHNO', data_type: 'VARCHAR2(10 byte)', source: 'inferred' },
    { name: 'SALESNO', data_type: 'VARCHAR2(10 byte)', source: 'inferred' },
    { name: 'ACNO', data_type: 'VARCHAR2(11 byte)', source: 'inferred' },
  ],
  D_S_ACCT_COMBINE: [
    { name: 'ACCT_NBR', data_type: 'VARCHAR2(11 byte)', source: 'inferred' },
    { name: 'CUSTOMER_ID', data_type: 'VARCHAR2(32 byte)', source: 'inferred' },
  ],
  D_S_CHANNEL: [
    { name: 'BRANCH_NBR', data_type: 'VARCHAR2(10 byte)', source: 'inferred' },
    { name: 'VALID_IND', data_type: 'VARCHAR2(1 byte)', source: 'inferred' },
  ],
  D_S_SALES_AGENT_DAILY: [
    { name: 'BRANCH_NBR', data_type: 'VARCHAR2(10 byte)', source: 'inferred' },
    { name: 'SALES_AGENT_NBR', data_type: 'VARCHAR2(10 byte)', source: 'inferred' },
    { name: 'EMP_NBR', data_type: 'VARCHAR2(6 byte)', source: 'inferred' },
    { name: 'SALES_AGENT_NAME', data_type: 'VARCHAR2(100 byte)', source: 'inferred' },
  ],
  'CD客群上送名單_2409_含G': [
    { name: 'ACCT_NBR', data_type: 'VARCHAR2(11 byte)', source: 'inferred' },
    { name: '現有客群', data_type: 'VARCHAR2(50 byte)', source: 'inferred' },
  ],
  '台股上送名單2025Q1': [
    { name: '營業員員編', data_type: 'VARCHAR2(6 byte)', source: 'inferred' },
    { name: '營業員姓名', data_type: 'VARCHAR2(100 byte)', source: 'inferred' },
    { name: '帳號', data_type: 'VARCHAR2(11 byte)', source: 'inferred' },
    { name: '備註1', data_type: 'VARCHAR2(50 byte)', source: 'inferred' },
    { name: '分公司代號', data_type: 'VARCHAR2(10 byte)', source: 'inferred' },
  ],
  '樹林離退_20240801': [
    { name: 'EMP_NBR', data_type: 'VARCHAR2(6 byte)', source: 'inferred' },
    { name: 'SALES_NBR', data_type: 'VARCHAR2(6 byte)', source: 'inferred' },
    { name: 'SALES_NAME', data_type: 'VARCHAR2(100 byte)', source: 'inferred' },
    { name: 'ACCT_NBR', data_type: 'VARCHAR2(11 byte)', source: 'inferred' },
    { name: 'PARTY_ID', data_type: 'VARCHAR2(32 byte)', source: 'inferred' },
  ],
  PARTY_NAME_ASOF_20241130: [
    { name: 'PARTY_ID', data_type: 'VARCHAR2(32 byte)', source: 'inferred' },
    { name: 'party_name', data_type: 'VARCHAR2(100 byte)', source: 'inferred' },
  ],
  '經紀客群2024Q3_雙證': [
    { name: '歸戶', data_type: 'VARCHAR2(32 byte)', source: 'inferred' },
    { name: '客群分類', data_type: 'VARCHAR2(100 byte)', source: 'inferred' },
    { name: '主ID', data_type: 'VARCHAR2(1 byte)', source: 'inferred' },
  ],
};

const tableNotes = {
  M_AC_ACCOUNT: 'Dictionary-backed. Only columns touched by the five SQL files are populated.',
  M_AT_STOCK_TXN: 'Dictionary-backed. Shared transaction fact table used by four folders.',
  M_AT_ACCOUNT_TXN: 'Dictionary-backed. Used by retired-sales monthly turnover query.',
  M_AC_ACCOUNT_INVENTORY: 'Dictionary-backed. Used by retired-sales inventory snapshot.',
  M_AC_ACCOUNT_REVENUE: 'Dictionary-backed. Used by retired-sales contribution metrics.',
  M_AC_ACCOUNT_PROD_TXN: 'Dictionary-backed. Used by retired-sales product metrics.',
  CSCD: 'Not found in dictionary workbook. Schema inferred from SQL.',
  PARTY_NAME: 'Not found in dictionary workbook. Schema inferred from SQL.',
  ES_PROJECTDATA: 'Not found in dictionary workbook. Schema inferred from SQL.',
  D_S_ACCT_COMBINE: 'Not found in dictionary workbook. Schema inferred from SQL.',
  D_S_CHANNEL: 'Not found in dictionary workbook. Schema inferred from SQL.',
  D_S_SALES_AGENT_DAILY: 'Not found in dictionary workbook. Schema inferred from SQL.',
  'CD客群上送名單_2409_含G': 'Not found in dictionary workbook. Schema inferred from SQL.',
  '台股上送名單2025Q1': 'Not found in dictionary workbook. Schema inferred from SQL.',
  '樹林離退_20240801': 'Not found in dictionary workbook. Schema inferred from SQL.',
  PARTY_NAME_ASOF_20241130: 'Not found in dictionary workbook. Schema inferred from SQL.',
  '經紀客群2024Q3_雙證': 'Not found in dictionary workbook. Schema inferred from SQL.',
};

function padNumber(value, width) {
  return String(value).padStart(width, '0');
}

function monthRange(start, end) {
  const result = [];
  let year = Number(start.slice(0, 4));
  let month = Number(start.slice(4, 6));
  const endYear = Number(end.slice(0, 4));
  const endMonth = Number(end.slice(4, 6));

  while (year < endYear || (year === endYear && month <= endMonth)) {
    result.push(`${year}${padNumber(month, 2)}`);
    month += 1;
    if (month === 13) {
      month = 1;
      year += 1;
    }
  }
  return result;
}

function createMockTables() {
  const tables = {
    M_AC_ACCOUNT: [],
    M_AT_STOCK_TXN: [],
    CSCD: [],
    PARTY_NAME: [],
    ES_PROJECTDATA: [],
    D_S_ACCT_COMBINE: [],
    D_S_CHANNEL: [],
    D_S_SALES_AGENT_DAILY: [],
    'CD客群上送名單_2409_含G': [],
    '台股上送名單2025Q1': [],
    '樹林離退_20240801': [],
    PARTY_NAME_ASOF_20241130: [],
    '經紀客群2024Q3_雙證': [],
    M_AT_ACCOUNT_TXN: [],
    M_AC_ACCOUNT_INVENTORY: [],
    M_AC_ACCOUNT_REVENUE: [],
    M_AC_ACCOUNT_PROD_TXN: [],
  };

  const tySales = [
    { emp: 'E96501', sales: 'S9651', name: '王大明' },
    { emp: 'E96502', sales: 'S9652', name: '李小華' },
    { emp: 'E96503', sales: 'S9653', name: '周雅婷' },
  ];
  const hcSales = [
    { emp: 'C201', sales: 'SC201', name: '白小姐' },
    { emp: 'C202', sales: 'SC202', name: '張專員' },
    { emp: 'C203', sales: 'SC203', name: '許顧問' },
  ];
  const slSales = [
    { emp: 'E6201', sales: 'SE201', name: '陳接手' },
    { emp: 'E6202', sales: 'SE202', name: '林接手' },
    { emp: 'E6203', sales: 'SE203', name: '黃接手' },
  ];
  const retiredSales = [
    { emp: 'R8001', sales: 'RS01', name: '舊業務甲' },
    { emp: 'R8002', sales: 'RS02', name: '舊業務乙' },
    { emp: 'R8003', sales: 'RS03', name: '舊業務丙' },
  ];
  const segments = ['A.核心客群', 'B.成長客群', 'C.一般客群', 'D.一般客群：3,000萬以下'];
  const campSegments = ['C.高資產', 'D1潛力', 'D2一般', 'G潛力'];
  const productMix = [
    '雙向借券',
    '不限用途借貸',
    '集保境內基金',
    '信託境內外基金',
    '複委託境外基金',
    '海外債',
    '海外股票',
    '國內期貨',
    '國外期貨',
    '國內選擇權',
    '選擇權',
  ];

  const hsinchuProjectAccounts = [];
  const shulinStockAccounts = [];
  const shulinOverseaAccounts = [];

  for (let i = 1; i <= 45; i += 1) {
    const sale = tySales[(i - 1) % tySales.length];
    const acctNbr = `9665A${padNumber(i, 5)}X`;
    const partyId = `P9665${padNumber(i, 4)}`;
    const isCredit = i <= 24;
    tables.M_AC_ACCOUNT.push({
      ACCT_NBR: acctNbr,
      PROD_TYPE_CODE: '100',
      PROD_TYPE_DESC: '台股',
      PARTY_ID: partyId,
      SYS_NEW_ACCT_NBR: acctNbr,
      ACCT_VALID_FLAG: 'Y',
      OPEN_DATE: `2024-${padNumber((i % 12) + 1, 2)}-${padNumber((i % 25) + 1, 2)}`,
      CLOSE_DATE: null,
      C_ACCT_VALID_FLAG: isCredit ? 'Y' : null,
      C_START_DATE: isCredit ? `2025-${padNumber((i % 6) + 1, 2)}-${padNumber((i % 20) + 1, 2)}` : null,
      C_CLOSE_DATE: null,
      BRANCH_CODE: '9665',
      BRANCH_NAME: '桃園分公司',
      EMP_NBR: sale.emp,
      SALES_NBR: sale.sales,
      SALES_NAME: sale.name,
      NW_SEGMENT_DESC: segments[i % segments.length],
    });
    tables.PARTY_NAME.push({ ACCT_NBR: acctNbr, PARTY_NAME: `桃園客戶${padNumber(i, 3)}` });
    if (isCredit) {
      tables.CSCD.push({
        BHNO: '9665',
        ACNO: acctNbr.slice(0, 10),
        ODATE: `2025-${padNumber((i % 6) + 1, 2)}-${padNumber((i % 20) + 1, 2)}`,
      });
    }

    monthRange('202501', '202512').forEach((yyyymm, monthIndex) => {
      const sourceCodes = ['001', '004', '016', '099'];
      const detailCodes = ['005', '006', '007', '008'];
      tables.M_AT_STOCK_TXN.push({
        ACCT_NBR: acctNbr,
        PARTY_ID: partyId,
        PROD_TYPE_CODE: '100',
        BRANCH_CODE: '9665',
        TXN_YYYYMM: yyyymm,
        TXN_TYPE_CODE: monthIndex % 5 === 0 ? '102' : '101',
        TXN_TYPE_DETAIL_CODE: detailCodes[(i + monthIndex) % detailCodes.length],
        CHANNEL_CODE: monthIndex % 4 === 3 ? '002' : '001',
        TXN_SOURCE_CODE: sourceCodes[(i + monthIndex) % sourceCodes.length],
        TXN_AMT_TWD: 400000 + i * 35000 + monthIndex * 50000,
      });
    });
  }

  tables.D_S_CHANNEL.push({ BRANCH_NBR: '962C', VALID_IND: 'Y' });
  hcSales.forEach((sale) => {
    tables.D_S_SALES_AGENT_DAILY.push({
      BRANCH_NBR: '962C',
      SALES_AGENT_NBR: sale.sales,
      EMP_NBR: sale.emp,
      SALES_AGENT_NAME: sale.name,
    });
  });

  for (let i = 1; i <= 24; i += 1) {
    const sale = hcSales[(i - 1) % hcSales.length];
    const acctNbr = `962CA${padNumber(i, 5)}X`;
    const partyId = `P962C${padNumber(i, 4)}`;
    hsinchuProjectAccounts.push({ acctNbr, partyId, sale, index: i });
    tables.M_AC_ACCOUNT.push({
      ACCT_NBR: acctNbr,
      PROD_TYPE_CODE: '100',
      PROD_TYPE_DESC: '台股',
      PARTY_ID: partyId,
      SYS_NEW_ACCT_NBR: acctNbr,
      ACCT_VALID_FLAG: 'Y',
      OPEN_DATE: `2024-${padNumber(((i + 3) % 12) + 1, 2)}-${padNumber((i % 25) + 1, 2)}`,
      CLOSE_DATE: null,
      C_ACCT_VALID_FLAG: null,
      C_START_DATE: null,
      C_CLOSE_DATE: null,
      BRANCH_CODE: '962C',
      BRANCH_NAME: '竹科分公司',
      EMP_NBR: sale.emp,
      SALES_NBR: sale.sales,
      SALES_NAME: sale.name,
      NW_SEGMENT_DESC: segments[(i + 1) % segments.length],
    });
    tables.PARTY_NAME.push({ ACCT_NBR: acctNbr, PARTY_NAME: `竹科客戶${padNumber(i, 3)}` });
    tables.D_S_ACCT_COMBINE.push({ ACCT_NBR: acctNbr, CUSTOMER_ID: partyId });

    if (i <= 18) {
      tables.ES_PROJECTDATA.push({
        PROJECT_NO: 'DS20241015',
        BHNO: '962C',
        SALESNO: sale.sales,
        ACNO: acctNbr,
      });
      tables['CD客群上送名單_2409_含G'].push({
        ACCT_NBR: acctNbr,
        現有客群: campSegments[(i - 1) % campSegments.length],
      });
    }

    if (i <= 12) {
      const note = ['C;高資產', 'D1;潛力', 'D2;一般', 'G;潛力'][(i - 1) % 4];
      tables['台股上送名單2025Q1'].push({
        營業員員編: sale.emp,
        營業員姓名: sale.name,
        帳號: acctNbr,
        備註1: note,
        分公司代號: '962C',
      });
    }

    ['202410', '202411', '202412', '202501', '202502', '202503'].forEach((yyyymm, monthIndex) => {
      const baseAmount = i <= 6
        ? 55000000 - monthIndex * 2500000
        : i <= 12
          ? 17000000 - monthIndex * 1000000
          : 4000000 + i * 180000 + monthIndex * 120000;
      tables.M_AT_STOCK_TXN.push({
        ACCT_NBR: acctNbr,
        PARTY_ID: partyId,
        PROD_TYPE_CODE: '100',
        BRANCH_CODE: '962C',
        TXN_YYYYMM: yyyymm,
        TXN_TYPE_CODE: '001',
        TXN_TYPE_DETAIL_CODE: '001',
        CHANNEL_CODE: '001',
        TXN_SOURCE_CODE: '001',
        TXN_AMT_TWD: baseAmount,
      });
    });
  }

  for (let i = 1; i <= 36; i += 1) {
    const sale = slSales[(i - 1) % slSales.length];
    const acctNbr = `962EA${padNumber(i, 5)}X`;
    const partyId = `P962E${padNumber(i, 4)}`;
    shulinStockAccounts.push({ acctNbr, partyId, sale, index: i });
    tables.M_AC_ACCOUNT.push({
      ACCT_NBR: acctNbr,
      PROD_TYPE_CODE: '100',
      PROD_TYPE_DESC: '台股',
      PARTY_ID: partyId,
      SYS_NEW_ACCT_NBR: acctNbr,
      ACCT_VALID_FLAG: 'Y',
      OPEN_DATE: `2024-${padNumber(((i + 5) % 12) + 1, 2)}-${padNumber((i % 25) + 1, 2)}`,
      CLOSE_DATE: null,
      C_ACCT_VALID_FLAG: i <= 18 ? 'Y' : null,
      C_START_DATE: i <= 18 ? `2024-${padNumber(((i + 1) % 12) + 1, 2)}-10` : null,
      C_CLOSE_DATE: null,
      BRANCH_CODE: '962E',
      BRANCH_NAME: '樹林分公司',
      EMP_NBR: sale.emp,
      SALES_NBR: sale.sales,
      SALES_NAME: sale.name,
      NW_SEGMENT_DESC: segments[(i + 2) % segments.length],
    });
    tables.PARTY_NAME_ASOF_20241130.push({ PARTY_ID: partyId, party_name: `樹林客戶${padNumber(i, 3)}` });
    tables['經紀客群2024Q3_雙證'].push({
      歸戶: partyId,
      客群分類: ['A. 高資產客群', 'B. 核心客群', 'C. 成長客群', 'D. 一般客群：3,000萬以下'][(i - 1) % 4],
      主ID: 'Y',
    });
    if (i <= 12) {
      const retired = retiredSales[(i - 1) % retiredSales.length];
      tables['樹林離退_20240801'].push({
        EMP_NBR: retired.emp,
        SALES_NBR: retired.sales,
        SALES_NAME: retired.name,
        ACCT_NBR: acctNbr,
        PARTY_ID: partyId,
      });
    }

    monthRange('202301', '202412').forEach((yyyymm, monthIndex) => {
      tables.M_AT_ACCOUNT_TXN.push({
        ACCT_NBR: acctNbr,
        PROD_TYPE_CODE: '100',
        SNAP_YYYYMM: yyyymm,
        TXN_AMT_TWD: 120000 + i * 18000 + monthIndex * 9000,
      });
    });

    tables.M_AC_ACCOUNT_INVENTORY.push({
      ACCT_NBR: acctNbr,
      PROD_TYPE_CODE: '100',
      SNAP_YYYYMM: '202605',
      BAL_AMT_TWD: 250000 + i * 80000,
    });

    monthRange('202401', '202412').forEach((yyyymm, monthIndex) => {
      tables.M_AC_ACCOUNT_REVENUE.push({
        ACCT_NBR: acctNbr,
        PROD_TYPE_CODE: '100',
        SNAP_YYYYMM: yyyymm,
        REV_AMT_TWD: 900 + i * 45 + monthIndex * 12,
      });
    });

    productMix.forEach((product, productIndex) => {
      tables.M_AC_ACCOUNT_PROD_TXN.push({
        ACCT_NBR: acctNbr,
        PROD_TYPE_CODE: '100',
        SNAP_YYYYMM: `2024${padNumber((productIndex % 8) + 5, 2)}`,
        PROD_MTYPE_DESC: product,
        TXN_AMT_TWD: product.includes('期貨') || product.includes('選擇權') ? 0 : 50000 + i * 6000 + productIndex * 15000,
        FUTURE_TXN_QTY: product.includes('期貨') || product.includes('選擇權') ? ((i + productIndex) % 9) + 1 : 0,
      });
    });
  }

  shulinStockAccounts.slice(0, 24).forEach(({ partyId, sale, index }) => {
    const acctNbr = `962EE${padNumber(index, 5)}X`;
    shulinOverseaAccounts.push({ acctNbr, partyId, sale, index });
    tables.M_AC_ACCOUNT.push({
      ACCT_NBR: acctNbr,
      PROD_TYPE_CODE: '200',
      PROD_TYPE_DESC: '複委託',
      PARTY_ID: partyId,
      SYS_NEW_ACCT_NBR: acctNbr,
      ACCT_VALID_FLAG: 'Y',
      OPEN_DATE: `2024-${padNumber(((index + 2) % 12) + 1, 2)}-15`,
      CLOSE_DATE: null,
      BRANCH_CODE: '962E',
      BRANCH_NAME: '樹林分公司',
      EMP_NBR: sale.emp,
      SALES_NBR: sale.sales,
      SALES_NAME: sale.name,
      NW_SEGMENT_DESC: segments[index % segments.length],
    });

    monthRange('202511', '202601').forEach((yyyymm, monthIndex) => {
      tables.M_AT_STOCK_TXN.push({
        ACCT_NBR: shulinStockAccounts[index - 1].acctNbr,
        PARTY_ID: partyId,
        PROD_TYPE_CODE: '200',
        BRANCH_CODE: '962E',
        TXN_YYYYMM: yyyymm,
        TXN_TYPE_CODE: monthIndex % 2 === 0 ? '101' : '102',
        TXN_TYPE_DETAIL_CODE: '001',
        CHANNEL_CODE: '001',
        TXN_SOURCE_CODE: '001',
        TXN_AMT_TWD: 6000 + index * 700 + monthIndex * 1200,
      });
    });

    monthRange('202401', '202412').forEach((yyyymm, monthIndex) => {
      tables.M_AC_ACCOUNT_REVENUE.push({
        ACCT_NBR: acctNbr,
        PROD_TYPE_CODE: '200',
        SNAP_YYYYMM: yyyymm,
        REV_AMT_TWD: 500 + index * 30 + monthIndex * 8,
      });
    });
  });

  monthRange('202511', '202601').forEach((yyyymm, monthIndex) => {
    shulinStockAccounts.forEach(({ acctNbr, partyId, index }) => {
      tables.M_AT_STOCK_TXN.push({
        ACCT_NBR: acctNbr,
        PARTY_ID: partyId,
        PROD_TYPE_CODE: '100',
        BRANCH_CODE: '962E',
        TXN_YYYYMM: yyyymm,
        TXN_TYPE_CODE: '102',
        TXN_TYPE_DETAIL_CODE: '001',
        CHANNEL_CODE: '001',
        TXN_SOURCE_CODE: '001',
        TXN_AMT_TWD: 1800 + index * 120 + monthIndex * 90,
      });
    });
  });

  return tables;
}

const tables = createMockTables();

const queries = [
  {
    key: '561_credit_accounts',
    sheetName: '561_credit',
    sql: `
WITH TXN AS (
  SELECT
    ACCT_NBR,
    SUM(CASE WHEN TXN_TYPE_DETAIL_CODE IN ('005', '007') THEN TXN_AMT_TWD ELSE 0 END) AS "融資交易量",
    SUM(CASE WHEN TXN_TYPE_DETAIL_CODE IN ('006', '008') THEN TXN_AMT_TWD ELSE 0 END) AS "融券交易量"
  FROM "M_AT_STOCK_TXN"
  WHERE TXN_YYYYMM BETWEEN '202501' AND '202512'
    AND PROD_TYPE_CODE = '100'
    AND BRANCH_CODE = '9665'
    AND TXN_TYPE_DETAIL_CODE IN ('005', '006', '007', '008')
  GROUP BY ACCT_NBR
),
CSCD_ODATE AS (
  SELECT ACNO, MIN(ODATE) AS ODATE
  FROM "CSCD"
  WHERE BHNO = '9665'
  GROUP BY ACNO
)
SELECT
  ACC.EMP_NBR AS "營業員員編",
  ACC.SALES_NBR AS "營業員代碼",
  ACC.SALES_NAME AS "營業員姓名",
  ACC.ACCT_NBR AS "客戶帳號",
  NAME.PARTY_NAME AS "客戶姓名",
  ACC.OPEN_DATE AS "開戶日期",
  CSCD_ODATE.ODATE AS "信用戶開戶日期",
  COALESCE(TXN."融資交易量", 0) AS "融資交易量",
  COALESCE(TXN."融券交易量", 0) AS "融券交易量"
FROM "M_AC_ACCOUNT" ACC
LEFT JOIN "PARTY_NAME" NAME ON NAME.ACCT_NBR = ACC.ACCT_NBR
LEFT JOIN TXN ON TXN.ACCT_NBR = ACC.ACCT_NBR
LEFT JOIN CSCD_ODATE ON CSCD_ODATE.ACNO = substr(ACC.ACCT_NBR, 1, 10)
WHERE ACC.PROD_TYPE_CODE = '100'
  AND ACC.BRANCH_CODE = '9665'
  AND ACC.ACCT_VALID_FLAG = 'Y' AND ACC.CLOSE_DATE IS NULL
  AND ACC.C_START_DATE IS NOT NULL
  AND ACC.C_ACCT_VALID_FLAG = 'Y' AND ACC.C_CLOSE_DATE IS NULL
  AND substr(CSCD_ODATE.ODATE, 1, 4) = '2025'
ORDER BY ACC.EMP_NBR, ACC.ACCT_NBR
`,
  },
  {
    key: '565_channel_mix',
    sheetName: '565_channel',
    sql: `
WITH TXN AS (
  SELECT
    ACCT_NBR,
    SUM(CASE WHEN CHANNEL_CODE = '001' AND TXN_SOURCE_CODE = '001' THEN TXN_AMT_TWD ELSE 0 END) AS "E點通",
    SUM(CASE WHEN CHANNEL_CODE = '001' AND TXN_SOURCE_CODE = '004' THEN TXN_AMT_TWD ELSE 0 END) AS "e+APP",
    SUM(CASE WHEN CHANNEL_CODE = '001' AND TXN_SOURCE_CODE = '016' THEN TXN_AMT_TWD ELSE 0 END) AS "NEWONLINE",
    SUM(CASE WHEN CHANNEL_CODE = '001' AND TXN_SOURCE_CODE NOT IN ('001', '004', '016') THEN TXN_AMT_TWD ELSE 0 END) AS "其他電子下單",
    SUM(CASE WHEN CHANNEL_CODE <> '001' THEN TXN_AMT_TWD ELSE 0 END) AS "非電子下單"
  FROM "M_AT_STOCK_TXN"
  WHERE PROD_TYPE_CODE = '100'
    AND TXN_YYYYMM BETWEEN '202501' AND '202512'
    AND BRANCH_CODE = '9665'
    AND TXN_SOURCE_CODE <> '024'
  GROUP BY ACCT_NBR
)
SELECT
  ACC.EMP_NBR AS "營業員員編",
  ACC.SALES_NBR AS "營業員代碼",
  ACC.SALES_NAME AS "營業員姓名",
  ACC.ACCT_NBR AS "客戶帳號",
  NAME.PARTY_NAME AS "客戶姓名",
  ACC.OPEN_DATE AS "開戶日期",
  COALESCE(TXN."E點通", 0) AS "E點通",
  COALESCE(TXN."e+APP", 0) AS "e+APP",
  COALESCE(TXN."NEWONLINE", 0) AS "NEWONLINE",
  COALESCE(TXN."其他電子下單", 0) AS "其他電子下單",
  COALESCE(TXN."非電子下單", 0) AS "非電子下單"
FROM "M_AC_ACCOUNT" ACC
LEFT JOIN "PARTY_NAME" NAME ON NAME.ACCT_NBR = ACC.ACCT_NBR
LEFT JOIN TXN ON TXN.ACCT_NBR = ACC.ACCT_NBR
WHERE ACC.BRANCH_CODE = '9665'
  AND ACC.PROD_TYPE_CODE = '100'
  AND ACC.ACCT_VALID_FLAG = 'Y' AND ACC.CLOSE_DATE IS NULL
ORDER BY ACC.EMP_NBR, ACC.ACCT_NBR
`,
  },
  {
    key: 'campaign_2024q4',
    sheetName: 'camp_2024Q4',
    sql: `
WITH "自打名單" AS (
  SELECT
    SALES.EMP_NBR AS "EMP_NBR",
    SALES.SALES_AGENT_NAME AS "SALES_AGENT_NAME",
    ACCT.CUSTOMER_ID AS "CUSTOMER_ID",
    ES.ACNO AS "ACNO",
    replace(substr(LIST."現有客群", 1, 2), '.', '') AS "上升前客群"
  FROM "ES_PROJECTDATA" ES
  LEFT JOIN "D_S_ACCT_COMBINE" ACCT ON ES.ACNO = ACCT.ACCT_NBR
  LEFT JOIN "D_S_CHANNEL" CHANNEL ON ES.BHNO = CHANNEL.BRANCH_NBR
  LEFT JOIN "D_S_SALES_AGENT_DAILY" SALES
    ON ES.BHNO = SALES.BRANCH_NBR AND ES.SALESNO = SALES.SALES_AGENT_NBR
  INNER JOIN "CD客群上送名單_2409_含G" LIST ON ES.ACNO = LIST.ACCT_NBR
  WHERE ES.PROJECT_NO = 'DS20241015'
    AND CHANNEL.VALID_IND = 'Y'
    AND ES.BHNO = '962C'
),
"成交紀錄" AS (
  SELECT PARTY_ID, BRANCH_CODE, SUM(TXN_AMT_TWD) AS "本季交易量"
  FROM "M_AT_STOCK_TXN"
  WHERE PROD_TYPE_CODE = '100'
    AND TXN_YYYYMM >= '202410' AND TXN_YYYYMM <= '202412'
    AND BRANCH_CODE = '962C'
  GROUP BY PARTY_ID, BRANCH_CODE
)
SELECT
  L."EMP_NBR",
  L."SALES_AGENT_NAME",
  L."CUSTOMER_ID",
  L."ACNO",
  L."上升前客群",
  T."本季交易量",
  CASE
    WHEN L."上升前客群" = 'C' AND COALESCE(T."本季交易量", 0) >= 100000000 THEN 'Y'
    WHEN L."上升前客群" = 'D1' AND COALESCE(T."本季交易量", 0) >= 30000000 THEN 'Y'
    WHEN L."上升前客群" = 'D2' AND COALESCE(T."本季交易量", 0) >= 10000000 THEN 'Y'
    WHEN L."上升前客群" = 'G' AND COALESCE(T."本季交易量", 0) >= 10000000 THEN 'Y'
    ELSE 'N'
  END AS "上送成功與否"
FROM "自打名單" L
LEFT JOIN "成交紀錄" T ON L."CUSTOMER_ID" = T.PARTY_ID
ORDER BY L."EMP_NBR", L."ACNO"
`,
  },
  {
    key: 'campaign_2025q1',
    sheetName: 'camp_2025Q1',
    sql: `
SELECT
  SRC."營業員員編",
  SRC."營業員姓名",
  ACC.PARTY_ID,
  SRC."帳號",
  replace(substr(SRC."備註1", 1, 2), ';', '') AS "上升前客群",
  TXN."本季交易量",
  CASE
    WHEN replace(substr(SRC."備註1", 1, 2), ';', '') = 'C' AND COALESCE(TXN."本季交易量", 0) >= 100000000 THEN 'Y'
    WHEN replace(substr(SRC."備註1", 1, 2), ';', '') = 'D1' AND COALESCE(TXN."本季交易量", 0) >= 30000000 THEN 'Y'
    WHEN replace(substr(SRC."備註1", 1, 2), ';', '') = 'D2' AND COALESCE(TXN."本季交易量", 0) >= 10000000 THEN 'Y'
    WHEN replace(substr(SRC."備註1", 1, 2), ';', '') = 'G' AND COALESCE(TXN."本季交易量", 0) >= 10000000 THEN 'Y'
    ELSE 'N'
  END AS "上送成功與否"
FROM "台股上送名單2025Q1" SRC
INNER JOIN "M_AC_ACCOUNT" ACC ON ACC.ACCT_NBR = SRC."帳號" AND ACC.PROD_TYPE_CODE = '100'
LEFT JOIN (
  SELECT PARTY_ID, BRANCH_CODE, SUM(TXN_AMT_TWD) AS "本季交易量"
  FROM "M_AT_STOCK_TXN"
  WHERE PROD_TYPE_CODE = '100'
    AND TXN_YYYYMM >= '202501' AND TXN_YYYYMM <= '202503'
    AND BRANCH_CODE = '962C'
  GROUP BY PARTY_ID, BRANCH_CODE
) TXN ON ACC.PARTY_ID = TXN.PARTY_ID
WHERE SRC."分公司代號" = '962C'
ORDER BY SRC."營業員員編", SRC."帳號"
`,
  },
  {
    key: 'shulin_monthly_counts',
    sheetName: 'shulin_counts',
    sql: `
WITH TXN AS (
  SELECT
    ACCT_NBR,
    SUM(CASE WHEN TXN_YYYYMM BETWEEN '202501' AND '202511' AND PROD_TYPE_CODE = '200' THEN TXN_AMT_TWD ELSE 0 END) AS "上上月份美股",
    SUM(CASE WHEN TXN_YYYYMM BETWEEN '202501' AND '202511' AND PROD_TYPE_CODE = '200' AND TXN_TYPE_CODE = '102' THEN TXN_AMT_TWD ELSE 0 END) AS "上上月份美股定期定額",
    SUM(CASE WHEN TXN_YYYYMM BETWEEN '202501' AND '202511' AND PROD_TYPE_CODE = '100' AND TXN_TYPE_CODE = '102' THEN TXN_AMT_TWD ELSE 0 END) AS "上上月份台股定期定額",
    SUM(CASE WHEN TXN_YYYYMM BETWEEN '202501' AND '202512' AND PROD_TYPE_CODE = '200' THEN TXN_AMT_TWD ELSE 0 END) AS "上月份美股",
    SUM(CASE WHEN TXN_YYYYMM BETWEEN '202501' AND '202512' AND PROD_TYPE_CODE = '200' AND TXN_TYPE_CODE = '102' THEN TXN_AMT_TWD ELSE 0 END) AS "上月份美股定期定額",
    SUM(CASE WHEN TXN_YYYYMM BETWEEN '202501' AND '202512' AND PROD_TYPE_CODE = '100' AND TXN_TYPE_CODE = '102' THEN TXN_AMT_TWD ELSE 0 END) AS "上月份台股定期定額",
    SUM(CASE WHEN TXN_YYYYMM BETWEEN '202501' AND '202601' AND PROD_TYPE_CODE = '200' THEN TXN_AMT_TWD ELSE 0 END) AS "本月份美股",
    SUM(CASE WHEN TXN_YYYYMM BETWEEN '202501' AND '202601' AND PROD_TYPE_CODE = '200' AND TXN_TYPE_CODE = '102' THEN TXN_AMT_TWD ELSE 0 END) AS "本月份美股定期定額",
    SUM(CASE WHEN TXN_YYYYMM BETWEEN '202501' AND '202601' AND PROD_TYPE_CODE = '100' AND TXN_TYPE_CODE = '102' THEN TXN_AMT_TWD ELSE 0 END) AS "本月份台股定期定額"
  FROM "M_AT_STOCK_TXN"
  WHERE BRANCH_CODE = '962E'
    AND TXN_YYYYMM BETWEEN '202511' AND '202601'
  GROUP BY ACCT_NBR
),
MAPPING_ AS (
  SELECT
    ACC.EMP_NBR AS "營業員員編",
    ACC.SALES_NBR AS "營業員代碼",
    ACC.SALES_NAME AS "營業員姓名",
    ACC.ACCT_NBR AS "客戶帳號",
    COALESCE(TXN."上上月份美股", 0) AS "上上月份美股",
    COALESCE(TXN."上上月份美股定期定額", 0) AS "上上月份美股定期定額",
    COALESCE(TXN."上上月份台股定期定額", 0) AS "上上月份台股定期定額",
    COALESCE(TXN."上月份美股", 0) AS "上月份美股",
    COALESCE(TXN."上月份美股定期定額", 0) AS "上月份美股定期定額",
    COALESCE(TXN."上月份台股定期定額", 0) AS "上月份台股定期定額",
    COALESCE(TXN."本月份美股", 0) AS "本月份美股",
    COALESCE(TXN."本月份美股定期定額", 0) AS "本月份美股定期定額",
    COALESCE(TXN."本月份台股定期定額", 0) AS "本月份台股定期定額"
  FROM "M_AC_ACCOUNT" ACC
  LEFT JOIN TXN ON TXN.ACCT_NBR = ACC.ACCT_NBR
  WHERE ACC.BRANCH_CODE = '962E'
    AND ACC.PROD_TYPE_CODE = '100'
    AND ACC.ACCT_VALID_FLAG = 'Y' AND ACC.CLOSE_DATE IS NULL
)
SELECT
  "營業員員編",
  "營業員姓名",
  COUNT("客戶帳號") AS "名下客戶數",
  COUNT(DISTINCT CASE WHEN "上上月份美股" > 0 THEN "客戶帳號" END) AS "上上月份美股累計實動戶數",
  COUNT(DISTINCT CASE WHEN "上月份美股" > 0 THEN "客戶帳號" END) AS "上月份美股累計實動戶數",
  COUNT(DISTINCT CASE WHEN "本月份美股" > 0 THEN "客戶帳號" END) AS "本月份美股累計實動戶數",
  COUNT(DISTINCT CASE WHEN "上上月份美股定期定額" > 0 THEN "客戶帳號" END) AS "上上月份美股定期定額累計實動戶數",
  COUNT(DISTINCT CASE WHEN "上月份美股定期定額" > 0 THEN "客戶帳號" END) AS "上月份美股定期定額累計實動戶數",
  COUNT(DISTINCT CASE WHEN "本月份美股定期定額" > 0 THEN "客戶帳號" END) AS "本月份美股定期定額累計實動戶數",
  COUNT(DISTINCT CASE WHEN "上上月份台股定期定額" > 0 THEN "客戶帳號" END) AS "上上月份台股定期定額累計實動戶數",
  COUNT(DISTINCT CASE WHEN "上月份台股定期定額" > 0 THEN "客戶帳號" END) AS "上月份台股定期定額累計實動戶數",
  COUNT(DISTINCT CASE WHEN "本月份台股定期定額" > 0 THEN "客戶帳號" END) AS "本月份台股定期定額累計實動戶數"
FROM MAPPING_
GROUP BY "營業員員編", "營業員姓名"
ORDER BY "營業員姓名"
`,
  },
  {
    key: 'retired_sales_overview',
    sheetName: 'retired_sales',
    sql: `
WITH ACC AS (
  SELECT ACCT_NBR, PARTY_ID, BRANCH_CODE, BRANCH_NAME, EMP_NBR, SALES_NBR, SALES_NAME, PROD_TYPE_CODE, PROD_TYPE_DESC, NW_SEGMENT_DESC, SYS_NEW_ACCT_NBR
  FROM "M_AC_ACCOUNT"
),
AA AS (
  SELECT PARTY_ID, MAX(party_name) AS CUSTOMER_NAME
  FROM "PARTY_NAME_ASOF_20241130"
  GROUP BY PARTY_ID
),
E AS (
  SELECT "歸戶" AS PARTY_ID, MAX("客群分類") AS "客群分類"
  FROM "經紀客群2024Q3_雙證"
  WHERE "主ID" = 'Y'
  GROUP BY "歸戶"
),
C AS (
  SELECT
    ACCT_NBR,
    SUM(CASE WHEN SNAP_YYYYMM = '202401' THEN TXN_AMT_TWD ELSE 0 END) AS "202401_交易量",
    SUM(CASE WHEN SNAP_YYYYMM = '202402' THEN TXN_AMT_TWD ELSE 0 END) AS "202402_交易量",
    SUM(CASE WHEN SNAP_YYYYMM = '202403' THEN TXN_AMT_TWD ELSE 0 END) AS "202403_交易量",
    SUM(CASE WHEN SNAP_YYYYMM = '202404' THEN TXN_AMT_TWD ELSE 0 END) AS "202404_交易量",
    SUM(CASE WHEN SNAP_YYYYMM = '202405' THEN TXN_AMT_TWD ELSE 0 END) AS "202405_交易量",
    SUM(CASE WHEN SNAP_YYYYMM = '202406' THEN TXN_AMT_TWD ELSE 0 END) AS "202406_交易量",
    SUM(CASE WHEN SNAP_YYYYMM = '202407' THEN TXN_AMT_TWD ELSE 0 END) AS "202407_交易量",
    SUM(CASE WHEN SNAP_YYYYMM = '202408' THEN TXN_AMT_TWD ELSE 0 END) AS "202408_交易量",
    SUM(CASE WHEN SNAP_YYYYMM = '202409' THEN TXN_AMT_TWD ELSE 0 END) AS "202409_交易量",
    SUM(CASE WHEN SNAP_YYYYMM = '202410' THEN TXN_AMT_TWD ELSE 0 END) AS "202410_交易量",
    SUM(CASE WHEN SNAP_YYYYMM = '202411' THEN TXN_AMT_TWD ELSE 0 END) AS "202411_交易量",
    SUM(CASE WHEN SNAP_YYYYMM = '202412' THEN TXN_AMT_TWD ELSE 0 END) AS "202412_交易量"
  FROM "M_AT_ACCOUNT_TXN"
  WHERE PROD_TYPE_CODE = '100'
    AND SNAP_YYYYMM BETWEEN '202401' AND '202412'
  GROUP BY ACCT_NBR
),
TXN_23 AS (
  SELECT ACCT_NBR, SUM(TXN_AMT_TWD) AS "2023_交易量"
  FROM "M_AT_ACCOUNT_TXN"
  WHERE PROD_TYPE_CODE = '100'
    AND SNAP_YYYYMM BETWEEN '202301' AND '202312'
  GROUP BY ACCT_NBR
),
CC AS (
  SELECT ACCT_NBR, SUM(TXN_AMT_TWD) AS "2024_交易量"
  FROM "M_AT_ACCOUNT_TXN"
  WHERE PROD_TYPE_CODE = '100'
    AND SNAP_YYYYMM BETWEEN '202401' AND '202412'
  GROUP BY ACCT_NBR
),
INV AS (
  SELECT ACCT_NBR, SUM(BAL_AMT_TWD) AS "2024_台股庫存"
  FROM "M_AC_ACCOUNT_INVENTORY"
  WHERE PROD_TYPE_CODE = '100'
    AND SNAP_YYYYMM = '202605'
  GROUP BY ACCT_NBR
),
SREV AS (
  SELECT
    B.BRANCH_CODE,
    B.BRANCH_NAME,
    B.PARTY_ID,
    SUM(A.REV_AMT_TWD) AS "2024_經紀貢獻度"
  FROM "M_AC_ACCOUNT_REVENUE" A
  LEFT JOIN ACC B ON A.ACCT_NBR = B.SYS_NEW_ACCT_NBR AND A.PROD_TYPE_CODE = B.PROD_TYPE_CODE
  WHERE A.SNAP_YYYYMM BETWEEN '202401' AND '202412'
    AND A.PROD_TYPE_CODE IN ('100', '300')
  GROUP BY B.BRANCH_CODE, B.BRANCH_NAME, B.PARTY_ID
),
F AS (
  SELECT
    B.BRANCH_CODE,
    B.BRANCH_NAME,
    B.PARTY_ID,
    SUM(CASE WHEN A.SNAP_YYYYMM BETWEEN '202401' AND '202412' THEN A.REV_AMT_TWD ELSE 0 END) AS "2024_財管貢獻度"
  FROM "M_AC_ACCOUNT_REVENUE" A
  LEFT JOIN ACC B ON A.ACCT_NBR = B.SYS_NEW_ACCT_NBR AND A.PROD_TYPE_CODE = B.PROD_TYPE_CODE
  WHERE A.SNAP_YYYYMM BETWEEN '202201' AND '202412'
    AND A.PROD_TYPE_CODE IN ('200', '400', '600')
  GROUP BY B.BRANCH_CODE, B.BRANCH_NAME, B.PARTY_ID
),
WPTran AS (
  SELECT
    B.BRANCH_CODE,
    B.BRANCH_NAME,
    B.PARTY_ID,
    SUM(CASE WHEN A.PROD_MTYPE_DESC = '雙向借券' THEN A.TXN_AMT_TWD ELSE 0 END) AS "雙向借券_金額",
    SUM(CASE WHEN A.PROD_MTYPE_DESC = '不限用途借貸' THEN A.TXN_AMT_TWD ELSE 0 END) AS "不限用途借貸_金額",
    SUM(CASE WHEN A.PROD_MTYPE_DESC = '集保境內基金' THEN A.TXN_AMT_TWD ELSE 0 END) AS "集保境內基金_金額",
    SUM(CASE WHEN A.PROD_MTYPE_DESC = '信託境內外基金' THEN A.TXN_AMT_TWD ELSE 0 END) AS "信託境內外基金_金額",
    SUM(CASE WHEN A.PROD_MTYPE_DESC = '複委託境外基金' THEN A.TXN_AMT_TWD ELSE 0 END) AS "複委託境外基金_金額",
    SUM(CASE WHEN A.PROD_MTYPE_DESC = '海外債' THEN A.TXN_AMT_TWD ELSE 0 END) AS "海外債_金額",
    SUM(CASE WHEN A.PROD_MTYPE_DESC = '海外股票' THEN A.TXN_AMT_TWD ELSE 0 END) AS "海外股票_金額"
  FROM "M_AC_ACCOUNT_PROD_TXN" A
  LEFT JOIN ACC B ON A.ACCT_NBR = B.SYS_NEW_ACCT_NBR AND A.PROD_TYPE_CODE = B.PROD_TYPE_CODE
  WHERE A.SNAP_YYYYMM BETWEEN '202401' AND '202412'
  GROUP BY B.BRANCH_CODE, B.BRANCH_NAME, B.PARTY_ID
),
WPQty AS (
  SELECT
    B.BRANCH_CODE,
    B.BRANCH_NAME,
    B.PARTY_ID,
    SUM(CASE WHEN A.PROD_MTYPE_DESC = '國內期貨' THEN A.FUTURE_TXN_QTY ELSE 0 END) AS "國內期貨_口數",
    SUM(CASE WHEN A.PROD_MTYPE_DESC = '國外期貨' THEN A.FUTURE_TXN_QTY ELSE 0 END) AS "國外期貨_口數",
    SUM(CASE WHEN A.PROD_MTYPE_DESC = '國內選擇權' THEN A.FUTURE_TXN_QTY ELSE 0 END) AS "國內選擇權_口數",
    SUM(CASE WHEN A.PROD_MTYPE_DESC = '選擇權' THEN A.FUTURE_TXN_QTY ELSE 0 END) AS "國外選擇權_口數"
  FROM "M_AC_ACCOUNT_PROD_TXN" A
  LEFT JOIN ACC B ON A.ACCT_NBR = B.SYS_NEW_ACCT_NBR AND A.PROD_TYPE_CODE = B.PROD_TYPE_CODE
  WHERE A.SNAP_YYYYMM BETWEEN '202401' AND '202412'
  GROUP BY B.BRANCH_CODE, B.BRANCH_NAME, B.PARTY_ID
)
SELECT
  '2026-05-08' AS "資料年月日",
  ACC.BRANCH_NAME AS "分公司名稱",
  TEMP.EMP_NBR AS "離退營業員員編",
  TEMP.SALES_NBR AS "離退營業員代碼",
  TEMP.SALES_NAME AS "離退營業員姓名",
  ACC.EMP_NBR AS "接手營業員員編",
  ACC.SALES_NBR AS "接手營業員代碼",
  ACC.SALES_NAME AS "接手營業員姓名",
  ACC.PROD_TYPE_DESC AS "帳戶類別",
  TEMP.ACCT_NBR AS "客戶帳號",
  TEMP.PARTY_ID AS "客戶證號",
  AA.CUSTOMER_NAME AS "客戶姓名",
  COALESCE(E."客群分類", 'D. 一般客群：3,000萬以下') AS "ABCD客群",
  ACC.NW_SEGMENT_DESC AS "客群",
  COALESCE(INV."2024_台股庫存", 0) AS "2024_台股庫存",
  COALESCE(C."202401_交易量", 0) AS "202401_交易量",
  COALESCE(C."202402_交易量", 0) AS "202402_交易量",
  COALESCE(C."202403_交易量", 0) AS "202403_交易量",
  COALESCE(C."202404_交易量", 0) AS "202404_交易量",
  COALESCE(C."202405_交易量", 0) AS "202405_交易量",
  COALESCE(C."202406_交易量", 0) AS "202406_交易量",
  COALESCE(C."202407_交易量", 0) AS "202407_交易量",
  COALESCE(C."202408_交易量", 0) AS "202408_交易量",
  COALESCE(C."202409_交易量", 0) AS "202409_交易量",
  COALESCE(C."202410_交易量", 0) AS "202410_交易量",
  COALESCE(C."202411_交易量", 0) AS "202411_交易量",
  COALESCE(C."202412_交易量", 0) AS "202412_交易量",
  COALESCE(CC."2024_交易量", 0) AS "2024_交易量",
  COALESCE(round(SREV."2024_經紀貢獻度", 0), 0) AS "2024_經紀貢獻度",
  COALESCE(TXN_23."2023_交易量", 0) AS "2023_交易量",
  COALESCE(round(F."2024_財管貢獻度", 0), 0) AS "2024_財管貢獻度",
  COALESCE(WPTran."雙向借券_金額", 0) AS "2024_雙向借券_金額",
  COALESCE(WPTran."不限用途借貸_金額", 0) AS "2024_不限用途借貸_金額",
  COALESCE(WPQty."國內期貨_口數", 0) + COALESCE(WPQty."國外期貨_口數", 0) + COALESCE(WPQty."國內選擇權_口數", 0) + COALESCE(WPQty."國外選擇權_口數", 0) AS "2024_期貨選擇權_口數",
  COALESCE(WPTran."集保境內基金_金額", 0) + COALESCE(WPTran."信託境內外基金_金額", 0) + COALESCE(WPTran."複委託境外基金_金額", 0) AS "2024_基金_金額",
  COALESCE(WPTran."海外債_金額", 0) AS "2024_海外債_金額",
  COALESCE(WPTran."海外股票_金額", 0) AS "2024_海外股票_金額"
FROM "樹林離退_20240801" TEMP
LEFT JOIN ACC
  ON TEMP.ACCT_NBR = ACC.ACCT_NBR
 AND TEMP.PARTY_ID = ACC.PARTY_ID
LEFT JOIN AA ON TEMP.PARTY_ID = AA.PARTY_ID
LEFT JOIN E ON TEMP.PARTY_ID = E.PARTY_ID
LEFT JOIN C ON TEMP.ACCT_NBR = C.ACCT_NBR
LEFT JOIN TXN_23 ON TEMP.ACCT_NBR = TXN_23.ACCT_NBR
LEFT JOIN CC ON TEMP.ACCT_NBR = CC.ACCT_NBR
LEFT JOIN INV ON TEMP.ACCT_NBR = INV.ACCT_NBR
LEFT JOIN SREV ON ACC.BRANCH_CODE = SREV.BRANCH_CODE AND ACC.BRANCH_NAME = SREV.BRANCH_NAME AND TEMP.PARTY_ID = SREV.PARTY_ID
LEFT JOIN F ON ACC.BRANCH_CODE = F.BRANCH_CODE AND ACC.BRANCH_NAME = F.BRANCH_NAME AND TEMP.PARTY_ID = F.PARTY_ID
LEFT JOIN WPTran ON ACC.BRANCH_CODE = WPTran.BRANCH_CODE AND ACC.BRANCH_NAME = WPTran.BRANCH_NAME AND TEMP.PARTY_ID = WPTran.PARTY_ID
LEFT JOIN WPQty ON ACC.BRANCH_CODE = WPQty.BRANCH_CODE AND ACC.BRANCH_NAME = WPQty.BRANCH_NAME AND TEMP.PARTY_ID = WPQty.PARTY_ID
WHERE ACC.BRANCH_CODE = '962E'
  AND ACC.PROD_TYPE_CODE = '100'
ORDER BY TEMP.EMP_NBR, TEMP.ACCT_NBR, TEMP.PARTY_ID
`,
  },
];

function runPowerShell(command, args = []) {
  return execFileSync(
    'powershell',
    ['-NoProfile', '-ExecutionPolicy', 'Bypass', ...args, ...(command ? ['-Command', command] : [])],
    { cwd: rootDir, encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] },
  );
}

function loadDictionarySchemas() {
  const raw = execFileSync(
    'powershell',
    [
      '-NoProfile',
      '-ExecutionPolicy',
      'Bypass',
      '-File',
      schemaReaderPath,
      '-WorkbookPath',
      dictionaryPath,
      '-TableNames',
      dictionaryTables.join(','),
    ],
    { cwd: rootDir, encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] },
  );
  return JSON.parse(raw);
}

function mergeSchemas(dictSchemas) {
  const merged = { ...dictSchemas };
  for (const [tableName, cols] of Object.entries(inferredSchemas)) {
    merged[tableName] = cols;
  }
  return merged;
}

function gatherUsedColumns(tableRows) {
  const columnSet = new Set();
  for (const row of tableRows) {
    Object.keys(row).forEach((key) => columnSet.add(key));
  }
  return Array.from(columnSet);
}

function sqliteTypeFromOracle(dataType) {
  const text = (dataType || '').toUpperCase();
  if (text.includes('NUMBER')) {
    return 'REAL';
  }
  return 'TEXT';
}

function sqlQuoteIdentifier(identifier) {
  return `"${String(identifier).replace(/"/g, '""')}"`;
}

function ensureDirectory(dirPath) {
  fs.mkdirSync(dirPath, { recursive: true });
}

function timestampSuffix() {
  const now = new Date();
  const pad = (value) => String(value).padStart(2, '0');
  return `${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}_${pad(now.getHours())}${pad(now.getMinutes())}${pad(now.getSeconds())}`;
}

function isFileBusyError(error) {
  return Boolean(error && (error.code === 'EBUSY' || error.code === 'EPERM'));
}

function resolveWritableOutputPath(destinationPath) {
  try {
    if (fs.existsSync(destinationPath)) {
      fs.rmSync(destinationPath, { force: true });
    }
    return { path: destinationPath, renamed: false };
  } catch (error) {
    if (!isFileBusyError(error)) {
      throw error;
    }

    const parsed = path.parse(destinationPath);
    const fallbackPath = path.join(parsed.dir, `${parsed.name}_${timestampSuffix()}${parsed.ext}`);
    return { path: fallbackPath, renamed: true, originalPath: destinationPath };
  }
}

function escapeXml(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

function columnNumberToName(index) {
  let num = index + 1;
  let result = '';
  while (num > 0) {
    const mod = (num - 1) % 26;
    result = String.fromCharCode(65 + mod) + result;
    num = Math.floor((num - mod) / 26);
  }
  return result;
}

function buildWorksheetXml(headers, rows) {
  const dataRows = [];
  const allRows = [headers, ...rows.map((row) => headers.map((header) => row[header] ?? ''))];

  for (let rowIndex = 0; rowIndex < allRows.length; rowIndex += 1) {
    const values = allRows[rowIndex];
    const cells = [];

    for (let colIndex = 0; colIndex < values.length; colIndex += 1) {
      const cellRef = `${columnNumberToName(colIndex)}${rowIndex + 1}`;
      const rawValue = values[colIndex];
      if (rawValue === null || rawValue === undefined || rawValue === '') {
        continue;
      }

      if (typeof rawValue === 'number' && Number.isFinite(rawValue)) {
        cells.push(`<c r="${cellRef}"><v>${rawValue}</v></c>`);
      } else {
        cells.push(`<c r="${cellRef}" t="inlineStr"><is><t>${escapeXml(rawValue)}</t></is></c>`);
      }
    }

    dataRows.push(`<row r="${rowIndex + 1}">${cells.join('')}</row>`);
  }

  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <sheetData>
    ${dataRows.join('\n    ')}
  </sheetData>
</worksheet>`;
}

function buildWorkbookPackage(sheets, destinationPath) {
  const tempRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'mock-xlsx-'));
  const workbookRoot = path.join(tempRoot, 'pkg');
  const xlDir = path.join(workbookRoot, 'xl');
  const worksheetsDir = path.join(xlDir, 'worksheets');
  const relsDir = path.join(workbookRoot, '_rels');
  const xlRelsDir = path.join(xlDir, '_rels');
  const docPropsDir = path.join(workbookRoot, 'docProps');

  [workbookRoot, xlDir, worksheetsDir, relsDir, xlRelsDir, docPropsDir].forEach(ensureDirectory);

  const workbookSheets = [];
  const workbookRels = [];
  const contentTypeOverrides = [];

  sheets.forEach((sheet, index) => {
    const sheetId = index + 1;
    const sheetFile = `sheet${sheetId}.xml`;
    fs.writeFileSync(path.join(worksheetsDir, sheetFile), buildWorksheetXml(sheet.headers, sheet.rows), 'utf8');

    workbookSheets.push(`<sheet name="${escapeXml(sheet.name)}" sheetId="${sheetId}" r:id="rId${sheetId}"/>`);
    workbookRels.push(
      `<Relationship Id="rId${sheetId}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/${sheetFile}"/>`,
    );
    contentTypeOverrides.push(
      `<Override PartName="/xl/worksheets/${sheetFile}" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`,
    );
  });

  fs.writeFileSync(
    path.join(workbookRoot, '[Content_Types].xml'),
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
  <Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
  <Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>
  <Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>
  ${contentTypeOverrides.join('\n  ')}
</Types>`,
    'utf8',
  );

  fs.writeFileSync(
    path.join(relsDir, '.rels'),
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>
  <Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>
</Relationships>`,
    'utf8',
  );

  fs.writeFileSync(
    path.join(xlDir, 'workbook.xml'),
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"
          xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <sheets>
    ${workbookSheets.join('\n    ')}
  </sheets>
</workbook>`,
    'utf8',
  );

  fs.writeFileSync(
    path.join(xlRelsDir, 'workbook.xml.rels'),
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  ${workbookRels.join('\n  ')}
</Relationships>`,
    'utf8',
  );

  fs.writeFileSync(
    path.join(xlDir, 'styles.xml'),
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <fonts count="1"><font><sz val="11"/><name val="Calibri"/></font></fonts>
  <fills count="1"><fill><patternFill patternType="none"/></fill></fills>
  <borders count="1"><border/></borders>
  <cellStyleXfs count="1"><xf/></cellStyleXfs>
  <cellXfs count="1"><xf xfId="0"/></cellXfs>
  <cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>
</styleSheet>`,
    'utf8',
  );

  const nowIso = new Date().toISOString();
  fs.writeFileSync(
    path.join(docPropsDir, 'core.xml'),
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties"
                   xmlns:dc="http://purl.org/dc/elements/1.1/"
                   xmlns:dcterms="http://purl.org/dc/terms/"
                   xmlns:dcmitype="http://purl.org/dc/dcmitype/"
                   xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <dc:creator>Codex</dc:creator>
  <cp:lastModifiedBy>Codex</cp:lastModifiedBy>
  <dcterms:created xsi:type="dcterms:W3CDTF">${nowIso}</dcterms:created>
  <dcterms:modified xsi:type="dcterms:W3CDTF">${nowIso}</dcterms:modified>
</cp:coreProperties>`,
    'utf8',
  );

  fs.writeFileSync(
    path.join(docPropsDir, 'app.xml'),
    `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties"
            xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes">
  <Application>Codex</Application>
</Properties>`,
    'utf8',
  );

  const outputTarget = resolveWritableOutputPath(destinationPath);
  const finalPath = outputTarget.path;
  const zipPath = `${finalPath}.zip`;
  if (fs.existsSync(zipPath)) {
    fs.rmSync(zipPath, { force: true });
  }

  const escapePs = (value) => String(value).replace(/'/g, "''");
  runPowerShell(
    `Compress-Archive -Path '${escapePs(path.join(workbookRoot, '*'))}' -DestinationPath '${escapePs(zipPath)}' -Force`,
  );
  fs.renameSync(zipPath, finalPath);
  fs.rmSync(tempRoot, { recursive: true, force: true });
  return outputTarget;
}

function buildCatalogSheet(mergedSchemas) {
  const rows = [];
  for (const [tableName, schema] of Object.entries(mergedSchemas)) {
    const populatedRows = tables[tableName] || [];
    rows.push({
      table_name: tableName,
      schema_source: schema[0]?.source || 'unknown',
      row_count: populatedRows.length,
      columns: schema.map((col) => `${col.name}:${col.data_type}`).join(' | '),
      note: tableNotes[tableName] || '',
    });
  }
  return {
    name: 'catalog',
    headers: ['table_name', 'schema_source', 'row_count', 'columns', 'note'],
    rows,
  };
}

function buildTableSheets(mergedSchemas) {
  const orderedTables = Object.keys(tables);
  return orderedTables.map((tableName, index) => {
    const schemaColumns = (mergedSchemas[tableName] || []).map((col) => col.name);
    const dataColumns = gatherUsedColumns(tables[tableName]);
    const headers = schemaColumns.length ? schemaColumns.filter((col) => dataColumns.includes(col)) : dataColumns;
    const rows = tables[tableName].map((row) => {
      const out = {};
      headers.forEach((header) => {
        out[header] = row[header] ?? '';
      });
      return out;
    });
    return {
      name: `${String(index + 1).padStart(2, '0')}_${tableName}`.slice(0, 31),
      headers,
      rows,
    };
  });
}

function buildResultWorkbookSheets(results) {
  const summaryRows = results.map((result) => ({
    query_key: result.key,
    result_rows: result.rows.length,
    sheet_name: result.sheetName,
  }));

  const sheets = [
    {
      name: 'summary',
      headers: ['query_key', 'result_rows', 'sheet_name'],
      rows: summaryRows,
    },
  ];

  for (const result of results) {
    const headers = result.rows.length ? Object.keys(result.rows[0]) : ['no_data'];
    const rows = result.rows.length ? result.rows : [{ no_data: 'No rows returned' }];
    sheets.push({ name: result.sheetName.slice(0, 31), headers, rows });
  }

  return sheets;
}

function createDatabase(mergedSchemas) {
  const db = new DatabaseSync(':memory:');
  for (const [tableName, rows] of Object.entries(tables)) {
    const schema = mergedSchemas[tableName] || [];
    const columns = schema.length
      ? schema.map((col) => col.name)
      : gatherUsedColumns(rows);

    const columnDefs = columns.map((column) => {
      const schemaCol = schema.find((item) => item.name === column);
      return `${sqlQuoteIdentifier(column)} ${sqliteTypeFromOracle(schemaCol?.data_type)}`;
    });

    db.exec(`CREATE TABLE ${sqlQuoteIdentifier(tableName)} (${columnDefs.join(', ')})`);

    if (!rows.length) {
      continue;
    }

    const placeholders = columns.map(() => '?').join(', ');
    const insertSql = `INSERT INTO ${sqlQuoteIdentifier(tableName)} (${columns.map(sqlQuoteIdentifier).join(', ')}) VALUES (${placeholders})`;
    const insertStmt = db.prepare(insertSql);
    for (const row of rows) {
      insertStmt.run(...columns.map((column) => row[column] ?? null));
    }
  }
  return db;
}

function runQueries(db) {
  return queries.map((query) => ({
    key: query.key,
    sheetName: query.sheetName,
    sql: query.sql.trim(),
    rows: db.prepare(query.sql).all(),
  }));
}

function writeJsonOutputs(mergedSchemas, results) {
  ensureDirectory(outputDir);

  const schemaSummary = {};
  for (const [tableName, schema] of Object.entries(mergedSchemas)) {
    schemaSummary[tableName] = {
      row_count: (tables[tableName] || []).length,
      schema_source: schema[0]?.source || 'unknown',
      columns: schema,
    };
  }

  fs.writeFileSync(
    path.join(outputDir, 'mock_table_schema.json'),
    JSON.stringify(schemaSummary, null, 2),
    'utf8',
  );
  fs.writeFileSync(
    path.join(outputDir, 'sql_results.json'),
    JSON.stringify(
      results.map((result) => ({
        key: result.key,
        row_count: result.rows.length,
        rows: result.rows,
      })),
      null,
      2,
    ),
    'utf8',
  );
}

function main() {
  ensureDirectory(outputDir);

  const dictSchemas = loadDictionarySchemas();
  const mergedSchemas = mergeSchemas(dictSchemas);
  const db = createDatabase(mergedSchemas);
  const results = runQueries(db);
  writeJsonOutputs(mergedSchemas, results);

  const mockTablesOutput = buildWorkbookPackage(
    [buildCatalogSheet(mergedSchemas), ...buildTableSheets(mergedSchemas)],
    path.join(outputDir, 'mock_tables.xlsx'),
  );
  const sqlResultsOutput = buildWorkbookPackage(
    buildResultWorkbookSheets(results),
    path.join(outputDir, 'sql_results.xlsx'),
  );

  const summary = {
    generated_at: new Date().toISOString(),
    output_files: [
      path.relative(rootDir, mockTablesOutput.path),
      path.relative(rootDir, sqlResultsOutput.path),
      'output/mock_table_schema.json',
      'output/sql_results.json',
    ],
    output_renamed: [
      mockTablesOutput.renamed ? { original: path.relative(rootDir, mockTablesOutput.originalPath), actual: path.relative(rootDir, mockTablesOutput.path) } : null,
      sqlResultsOutput.renamed ? { original: path.relative(rootDir, sqlResultsOutput.originalPath), actual: path.relative(rootDir, sqlResultsOutput.path) } : null,
    ].filter(Boolean),
    query_row_counts: Object.fromEntries(results.map((result) => [result.key, result.rows.length])),
    table_row_counts: Object.fromEntries(Object.entries(tables).map(([tableName, rows]) => [tableName, rows.length])),
  };

  fs.writeFileSync(path.join(outputDir, 'run_summary.json'), JSON.stringify(summary, null, 2), 'utf8');
  console.log(JSON.stringify(summary, null, 2));
}

main();
