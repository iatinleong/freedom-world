#!/usr/bin/env python
# coding: utf-8
# %%

# %%


import sys
import time
import calendar
from predict.choose_predict_model import main_code
import Module.config as config
from Module.Sql_module import get_SQL_raw_data

def make_query_mlops_predict_status(snap_date):
    return f"""
SELECT DISTINCT product,target,population
FROM test_mlops_ref_info
where snap_date = '{str(snap_date)}'
order by  product, population
"""
year=config.ym[0:4]
month=config.ym[4:6]

end_day = calendar.monthrange(int(year),int(month))[1]
snap_date = year+'/'+month+'/'+str(end_day)

query = make_query_mlops_predict_status(snap_date)


# while True:
try:
    # completed_df = get_SQL_raw_data(query)
    # if len(completed_df) == 41:
    #     print("全執行完畢")
    #     break
        
    main_code()
    
except Exception as e:
    print(f"發生錯誤:{e}，跳過")
time.sleep(30)


# # update model new prediction label

# %%


import random
import sys
import os
import time
from IPython.display import display
import warnings
warnings.filterwarnings("ignore")
import Module.config as config
from Module.Sql_module import execute_sql
ym = config.ym
target1 = '新戶開發與靜止戶活化'
target2 = '瞌睡客戶關懷'
target3 = '客群上送預測'
target4 = '潛在高價值客戶'


# %%

all_prod_list = os.listdir(config.storage_root + '/models/MLops/審核通過模型')
if '.ipynb_checkpoints' in all_prod_list : all_prod_list.remove('.ipynb_checkpoints')
if 'mlops_predict' in all_prod_list : all_prod_list.remove('mlops_predict')
if 'mlops_retrain' in all_prod_list : all_prod_list.remove('mlops_retrain')


# %%


#all_prod_list


# %%


def set_N_mlops_ref_info_model_valid(ym):
    return f"""
UPDATE test_mlops_ref_info  
SET model_valid_falg ='N'
"""


# %%


sql = set_N_mlops_ref_info_model_valid(ym)
execute_sql(sql)


# %%


def update_mlops_ref_info_model_valid(ym,string,product,target,population):
    return f"""
UPDATE test_mlops_ref_info   
SET model_valid_falg ='{string}'
where product = '{product}' 
and target = '{target}' 
and population = '{population}' 
and edition = (select max(edition) from (select a.*,regexp_substr(edition,'[^.]+',1,1)*1000+regexp_substr(edition,'[^.]+',1,2)rk from test_mlops_ref_info a where product = '{product}' and target = '{target}' and population = '{population}' and edition is not null order by rk desc fetch next 1 rows only))
"""


# %%

for prod in all_prod_list:
    if prod == '流失預警':
        population = '不分潛客'
        sql = update_mlops_ref_info_model_valid(ym,'Y',prod,target2,population)
        execute_sql(sql)
        time.sleep(1)
    elif prod == '客群上送':
        population = '不分潛客'
        sql = update_mlops_ref_info_model_valid(ym,'Y',prod,target3,population)
        execute_sql(sql)
        time.sleep(1)
    elif prod == '潛在高價值客戶':
        population = '不分潛客'
        sql = update_mlops_ref_info_model_valid(ym,'Y',prod,target4,population)
        execute_sql(sql)
        time.sleep(1)
    else:
        population = '非潛客'
        sql = update_mlops_ref_info_model_valid(ym,'Y',prod,target1,population)
        execute_sql(sql)
        population = '潛客'
        sql = update_mlops_ref_info_model_valid(ym,'Y',prod,target1,population)
        execute_sql(sql)
        time.sleep(1)


# %%




