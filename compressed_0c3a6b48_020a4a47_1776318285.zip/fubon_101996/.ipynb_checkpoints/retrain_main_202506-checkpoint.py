#!/usr/bin/env python
# coding: utf-8
# %%


import sys
import time
import Module.config as config
from retrain.choose_retrain_model import main_code
from Module.Sql_module import get_SQL_raw_data

def make_query_mlops_retrain_status(ym):
    return f"""
SELECT DISTINCT A."模型名稱",A."母體"
FROM {config.model_log} A
left join {config.retrain_log} B
on A."模型名稱" = B."模型名稱" and A."母體" = B."母體" and ABS(TO_DATE(A."retrain日期",'YYYYMMDD HH24:MI') - TO_DATE(B."retrain日期",'YYYYMMDD HH24:MI'))<= 0.0007
where B."retrain日期" >= '{str(int(ym))}' 
order by  A."模型名稱",A."母體" 
"""


query = make_query_mlops_retrain_status(config.mlops_retrain_day)


# while True:
#     try:
completed_df = get_SQL_raw_data(query)
if len(completed_df) == 41:
    print("全執行完畢")
    #break
    
main_code()
        
    # except Exception as e:
    #     print(f"發生錯誤:{e}，跳過")
    # time.sleep(30)


# %%





# %%
