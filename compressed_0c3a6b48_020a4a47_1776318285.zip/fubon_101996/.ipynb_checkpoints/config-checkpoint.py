#!/usr/bin/env python
# coding: utf-8
# %%
import os
from pathlib import Path
from dotenv import load_dotenv
from datetime import datetime, timedelta
from vdclient_magic.core.utils import get_datasource_config

# %%
try:
    parent_dir = Path(__file__).resolve().parent.parent
except NameError:
    parent_dir = Path().resolve().parent

target_environment = os.getenv('target_environment')
load_dotenv(dotenv_path=f"{parent_dir}/env/env.{target_environment}", override=False)  # 如果 env 有值就抓, 沒有值就用排程傳進來的

# %%
task_created_time = datetime.strptime(os.getenv('TASK_CREATED_TIME'), '%Y-%m-%d %H:%M:%S')
storage_root = os.getenv('storage_root')
datasource = os.getenv('datasource')

# %%
datasource_config = get_datasource_config(datasource)
HOST = datasource_config['host']
PORT = datasource_config['port']
SEVICE_NAME = datasource_config['service_name']

account = datasource_config['username']
pwd = datasource_config['password']
account_yichieh, pwd_yichieh = account, pwd
account_yt, pwd_yt  = account, pwd

# %%


# config parameter
feature_file_path = storage_root + '/Features'
feature_file_path_fubon = feature_file_path + '/new_features'
feature_file_path_jihsun = feature_file_path + '/new_features_js'
feature_file_path_mlops = feature_file_path + '/new_features_mlops'
feature_file_path_ntb = feature_file_path + '/new_features_ntb'

feature_trans_path = feature_file_path_fubon + '/feature_translate.csv'

dump_feature_log_path = feature_file_path + '/new_features_log'

object_list = ['customer_id','yyyymm'] 

table_orginal_list = ['CUST', 'AP', 'BC', 'FD', 'FDEBT', 'FS', 'FU', 'LIFEINS'
                     , 'SIP', 'STDT', 'STMT', 'STRUPRO', 'STSS', 'STST', 'UU'
                     , 'INVBNF', 'BNF', 'AUM'
                       ,'FTBD_profile'
                     ]

table_append_list = ['FTBD_PROFOLIO1', 'FTBD_PROFOLIO2', 'FTBD_PROFOLIO3'
                     ,'FTBD_ACTUBNF', 'FTBD_INVBNF'
                     ,'EDM_INTERACT', 'FTBD_INTERACT', 'LINE_INTERACT'
                     ,'TRANS_CATE1', 'TRANS_CATE2', 'TRANS_CATE3', 'TRANS_CATE31', 'TRANS_CATE32', 'TRANS_CATE4','TRANS_CATE5'
                     ,'SAFETY_STOCK', 'SAFETY_STOCK_1', 'SAFETY_STOCK_2'
                     ]


table_append_list_2024 = [ 'CUST', 'AP', 'BC', 'FD', 'FDEBT', 'FS', 'FU', 'LIFEINS'
                          , 'SIP', 'STDT', 'STMT', 'STRUPRO', 'STSS', 'STST', 'UU'
                          , 'AUM'
                          ,'FTBD_profile'
                          , 'FTBD_PROFOLIO1', 'FTBD_PROFOLIO2', 'FTBD_PROFOLIO3'
                          , 'FTBD_ACTUBNF'
                          , 'SAFETY_STOCK_1', 'SAFETY_STOCK_2'
                          , 'TRANS_CATE1', 'TRANS_CATE2', 'TRANS_CATE31', 'TRANS_CATE32', 'TRANS_CATE4', 'TRANS_CATE5'
                          , 'LINE_INTERACT','EDM_INTERACT','FTBD_INTERACT'
                          , 'FTBD_CONTRACT1','FTBD_CONTRACT2','FTBD_EVENT','FTBD_KYCQA','FTBD_INVBNF_PLUS'
                          , 'FTBD_JCI','FTBD_DGT1'
                          ]

table_append_list_2025 = ['CF_CUSTID','CF_ACTUBNF', 'CF_ACTUBNFROI', 'CF_ASSET1', 'CF_ASSET2', 'CF_ASSET3', 'CF_ASSET4', 'CF_AUM',
                         'CF_CONTRACT', 'CF_CONTRACT_DUE', 'CF_DGT1', 'CF_DGT2', 'CF_EVENT',
                         'CF_INTERACT_ECDAY', 'CF_INTERACT_ECPROD', 'CF_INTERACT_EDM', 'CF_INTERACT_LINE',
                         'CF_INVBNF', 'CF_INVBNFROI', 'CF_JCI', 'CF_KYCQA', 'CF_PROFILE',
                         'CF_PROFOLIO1', 'CF_PROFOLIO2', 'CF_PROFOLIO3', 'CF_PROFOLIO4', 'CF_PROFOLIO5', 'CF_PROFOLIO6', 'CF_PROFOLIO7',
                         'CF_TXN_AP', 'CF_TXN_BSBL', 'CF_TXN_CURRENCY', 'CF_TXN_FB', 'CF_TXN_FD', 'CF_TXN_FPBR',
                         'CF_TXN_FS', 'CF_TXN_FU', 'CF_TXN_INSURANCE', 'CF_TXN_LOAN', 'CF_TXN_MAEC', 'CF_TXN_SIP',
                         'CF_TXN_SN', 'CF_TXN_STDT', 'CF_TXN_STMT', 'CF_TXN_STSS', 'CF_TXN_STST', 'CF_TXN_STYPE']

table_check_list = [ 'CUST', 'AP', 'BC', 'FD', 'FDEBT', 'FS', 'FU', 'LIFEINS'
                    , 'SIP', 'STDT', 'STMT', 'STRUPRO', 'STSS', 'STST', 'UU'
                    , 'AUM'
                    , 'FTBD_profile'
                    , 'FTBD_PROFOLIO1', 'FTBD_PROFOLIO2', 'FTBD_PROFOLIO3'
                    , 'FTBD_ACTUBNF'
                    , 'SAFETY_STOCK_1', 'SAFETY_STOCK_2'
                    , 'TRANS_CATE1', 'TRANS_CATE2', 'TRANS_CATE31', 'TRANS_CATE32', 'TRANS_CATE4', 'TRANS_CATE5'
                    , 'LINE_INTERACT','EDM_INTERACT','FTBD_INTERACT'
                    , 'FTBD_CONTRACT1','FTBD_CONTRACT2','FTBD_EVENT','FTBD_KYCQA','FTBD_INVBNF_PLUS'
                    , 'FTBD_JCI','FTBD_DGT1'
                    ]


table_not_fixed_column_list = ['TRANS_CATE1', 'TRANS_CATE2', 'TRANS_CATE3', 'TRANS_CATE31', 'TRANS_CATE32', 'TRANS_CATE4','TRANS_CATE5'
                               ,'SAFETY_STOCK', 'SAFETY_STOCK_1', 'SAFETY_STOCK_2']

colname_object_list = ['customer_id','yyyymm']   
colname_catgory_list_1 = ['gender_code','edu_desc','postal_rsd_code','postal_hh_code','use_fubon_acct'
                          ,'aml_highrisk_flag','nw_segment_desc','segment_desc','valid_flag','e_acct_valid_flag'
                          ,'emp_flag','pro_invest_flag','aml_risk_desc','kyc_risk_desc','email_flag','line_bc_flag'
                         ]
colname_catgory_list_2 = ['c_acct_valid_flag', 'subbrok_acct_open_flag','future_acct_open_flag','trust_acct_open_flag']

colname_catgory_list_3 = ['kycqa_q5', 'kycqa_q6','kycqa_q7','kycqa_q8','kycqa_q10', 'kycqa_q11','kycqa_q12','kycqa_q13'
                         ,'kycqa_q91', 'kycqa_q92','kycqa_q93','kycqa_q94','kycqa_q95', 'kycqa_q96','kycqa_q97','kycqa_q98']
colname_catgory_list_4 = ['histy_segment_desc','compare_histy_segment_desc','once_be_pi_customer']
colname_catgory_list_5 = ['agent_flag']
colname_catgory_list_6 = ['dgt_acct_freqtfct','dgt_stafth_freqtfct','dgt_smtstp_freqtfct','dgt_afthif_freqtfct','dgt_stqt_fqtps'
                          ,'dgt_stdtqt_fqtps','dgt_finnews_fqtps','dgt_stcqt_fqtps','dgt_wa_fqtps','dgt_intf_fqtps']

colname_catgory_list_202503 = ['gender_code','edu_desc','postal_rsd_code','postal_hh_code','use_fubon_acct'
                        ,'aml_highrisk_flag','nw_segment_desc','segment_desc','valid_flag','e_acct_valid_flag'
                        ,'emp_flag','pro_invest_flag','aml_risk_desc','kyc_risk_desc','email_flag','line_bc_flag'
                        ,'c_acct_valid_flag', 'subbrok_acct_open_flag','future_acct_open_flag','trust_acct_open_flag'
                        ,'kycqa_q5', 'kycqa_q6','kycqa_q7','kycqa_q9','kycqa_q10', 'kycqa_q11','kycqa_q12','kycqa_q13'
                        ,'kycqa_q81', 'kycqa_q82','kycqa_q83','kycqa_q84','kycqa_q85', 'kycqa_q86','kycqa_q87','kycqa_q88'
                        ,'histy_segment_desc','compare_histy_segment_desc','once_be_pi_customer'
                        ,'agent_flag','dgt_acct_freqtfct','dgt_stafth_freqtfct','dgt_smtstp_freqtfct','dgt_afthif_freqtfct','dgt_stqt_fqtps_m'
                        ,'dgt_stdtqt_fqtps_m','dgt_finnews_fqtps_m','dgt_stcqt_fqtps_m','dgt_wa_fqtps_m','dgt_intf_fqtps_m']
colname_catgory_list_202503_1 = ['gender_code','edu_desc','postal_rsd_code','postal_hh_code','use_fubon_acct'
                        ,'aml_highrisk_flag','nw_segment_desc','segment_desc','valid_flag','e_acct_valid_flag'
                        ,'emp_flag','pro_invest_flag','aml_risk_desc','kyc_risk_desc','email_flag','line_bc_flag'
                        ,'c_acct_valid_flag', 'subbrok_acct_open_flag','future_acct_open_flag','trust_acct_open_flag']
colname_catgory_list_202503_2 = ['kycqa_q5', 'kycqa_q6','kycqa_q7','kycqa_q9','kycqa_q10', 'kycqa_q11','kycqa_q12','kycqa_q13'
                        ,'kycqa_q81', 'kycqa_q82','kycqa_q83','kycqa_q84','kycqa_q85', 'kycqa_q86','kycqa_q87','kycqa_q88'
                        ,'histy_segment_desc','compare_histy_segment_desc','once_be_pi_customer'
                        ,'agent_flag','dgt_acct_freqtfct','dgt_stafth_freqtfct','dgt_smtstp_freqtfct','dgt_afthif_freqtfct','dgt_stqt_fqtps_m'
                        ,'dgt_stdtqt_fqtps_m','dgt_finnews_fqtps_m','dgt_stcqt_fqtps_m','dgt_wa_fqtps_m','dgt_intf_fqtps_m']


# %%


# import sys
# import pandas as pd 
# sys.path.append('/home/cdsw/Tony/Mlops_new/Module')
# from Sql_module import get_SQL_raw_data
# # 測試DJ
# test_df_dj = get_SQL_raw_data('select * from s_taichiehfan.mlops_ref_info_double', account=account, pwd=pwd)
# if isinstance(test_df_dj, pd.DataFrame):
#     print('DJ OK!')
# else:
#     print('DJ 密碼有問題')
# # 測試EJ
# test_df_dj = get_SQL_raw_data('select * from s_taichiehfan.mlops_ref_info_double', account=account_yichieh, pwd=pwd_yichieh)
# if isinstance(test_df_dj, pd.DataFrame):
#     print('EJ OK!')
# else:
#     print('EJ 密碼有問題')
# # 測試PS
# test_df_dj = get_SQL_raw_data('select * from s_taichiehfan.mlops_ref_info_double', account=account_paoshiang, pwd=pwd_paoshiang)
# if isinstance(test_df_dj, pd.DataFrame):
#     print('PS OK!')
# else:
#     print('PS 密碼有問題')


# %%
import pandas as pd
from dateutil.relativedelta import relativedelta
# 模型間不需修改
algorithm = 'xgboost'
test_month = task_created_time - relativedelta(months=3)
train_ym_last =  test_month - relativedelta(years=1)
do_ym_list_pd_3m = pd.date_range(train_ym_last.replace(day = 1),test_month.replace(day = 1), freq = '3MS' ).strftime('%Y%m').tolist()
train_month_last = test_month - relativedelta(months=3)
do_ym_list_pd_3m_detail =  pd.date_range(train_ym_last.replace(day = 1),train_month_last.replace(day = 1), freq = '1MS' ).strftime('%Y%m').tolist()
do_ym_list_pd_3m_detail.append(test_month.strftime('%Y%m'))
last_ym = task_created_time - relativedelta(years=1)
last2_ym = task_created_time - relativedelta(years=2)
last2_ym_plus3m = last2_ym + relativedelta(months=3)
do_ym_list_pd_12m = [last2_ym.strftime('%Y%m')]
do_ym_list_pd_12m.extend(pd.date_range(last2_ym_plus3m.replace(day = 1),last_ym.replace(day = 1), freq = '3MS' ).strftime('%Y%m'))
ym = task_created_time.strftime('%Y%m')
mlops_retrain_day = task_created_time.strftime('%Y%m%d')

print(f'do_ym_list_pd_3m:{do_ym_list_pd_3m}')
print(f'do_ym_list_pd_3m_detail:{do_ym_list_pd_3m_detail}')
print(f'do_ym_list_pd_12m: {do_ym_list_pd_12m}')
print(f'ym: {ym}')
print(f'mlops_retrain_day: {mlops_retrain_day}')

# %%
ym_ntb_retrain = '20250924'
ym_ntb_predict = '20251109'
do_ym_list_ntb = ['20250420','20250504','20250518','20250601','20250615','20250629','20250713','20250727','20250810','20250824','20250907']
write_db_Y_N = True
limit_size_select = 100000
limit_size_build= 400000
frequency = '批次'
edition_detail = '新資料retrain'
edition_detail_ntb = '跳10週+雙週y'
write_feature_Y_N = False


# %%


# Model parameter 

#潛客參數
max_depth_a = 3 
scale_pos_weight_a = 4
n_estimator_a = 100

#非潛客參數
max_depth_b = 3 
scale_pos_weight_b = 4
n_estimator_b = 100






