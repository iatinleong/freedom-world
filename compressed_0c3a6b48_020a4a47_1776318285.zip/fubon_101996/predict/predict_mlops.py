#!/usr/bin/env python
# coding: utf-8
# %%

# %%


# loading parameter
import sys
import Module.config as config 
import calendar
account, pwd = config.account, config.pwd
account_yt, pwd_yt = config.account_yt, config.pwd_yt 


# %%


#前版本predict_mlops_np_and_p_double_OPT_market_flag
def predict_mlops_202503(this_file_path,target,papulation_colname,papulation_except_value,mother_list,query_list,ym,
                           algorithm,write_db_Y_N,drop_key_word,frequency,edition_detail, market_flag_Y_N):
    
    import sys
    from Module.Model import monthdelta, confirm_retrain_log, get_bin_with_dif_mother,get_bin_with_dif_mother_version230417,     predict_df_v230517, predict_log, save_db_mlops,save_db_ref_info_mlops,save_db_id_list_mlops,get_next_model_version,whether_done_next_population_predict,     get_max_model_retrain_version, get_bin_with_dif_mother_conversion
    from Module.Pretreatment import get_feature_by_SOP_202503
    from Module.Sql_module import get_SQL_raw_data,get_SQL_raw_data2
    #import config
    import os
    #該檔案路徑
    writing_path = this_file_path
    this_prod = this_file_path.split('/')[-1]
    from sqlalchemy import create_engine
    import time
    import pandas as pd
    import pickle
    import numpy as np
    from sqlalchemy.types import String, Integer, Float
    from datetime import date, timedelta , datetime
#     from IPython.display import display
    import gc
    year=ym[0:4]
    month=ym[4:6]

    end_day = calendar.monthrange(int(year),int(month))[1]
    snap_date = year+'/'+month+'/'+str(end_day)

    # 確認母體跟商品下的最新retrain結果
    confirm_retrain_log(this_prod, mother_list, table_name='test_mlops_retrain_log')
    # 最新版
    new_edition_list = []
    for index, mother in enumerate(mother_list): 
    #         new_edition = get_next_model_version(this_prod,target,mother,frequency,edition_detail, table_name = 'mlops_ref_info_double')
        new_edition = get_max_model_retrain_version(config.mlops_retrain_day[0:6], 'test_mlops_retrain_log', this_prod, mother)
        new_edition_list.append(new_edition)
        break
    if market_flag_Y_N :
        # 抓取對應母體的bin
        bins_list, bins_label_list = get_bin_with_dif_mother_conversion(this_prod, mother_list, new_edition_list, table_name='test_mlops_retrain_log')
        # 轉換率對應的真實情形
        label_to_rank_list = get_bin_with_dif_mother_version230417(this_prod, mother_list, table_name='test_mlops_model_log')

    else:
        # 抓取對應母體的bin
        bins_list = get_bin_with_dif_mother_version230417(this_prod, mother_list, table_name='test_mlops_model_log')
    # 判斷是設定有無問題
    if len(mother_list) == len(bins_list) :
        print(f'將會以母體執行迴圈 {mother_list} \n切分方式為 {bins_list}\n ')
    else:
        raise Exception('mother_list、bins_list 長度不一致')
    
    query_function = query_list[0]
    print(f'query_function  : {query_function}')
    # 開始執行迴圈
    for index, mother in enumerate(mother_list):    
        print(f'mother : {mother}')

        bins = bins_list[index]
        print(f'bins  : {bins}')

        # BIN的類型
        print(f'type(bins[1]) : {type(bins[1])}')

        if market_flag_Y_N :
            # bins_label_list
            bins_label = bins_label_list[index]
            print(f'bins_label: {bins_label}')  

            label_to_rank = label_to_rank_list[index]
            print(f'真實轉換等級的label_to_rank: {label_to_rank}')  
        # 版本
        new_edition = new_edition_list[index]
        print(f'new_edition : {new_edition}')

        if not whether_done_next_population_predict(this_file_path, this_prod, mother, target, algorithm, snap_date,
                                        db_table_rf='test_mlops_ref_info', db_table_IL='test_mlops_id_list',
                                        account=config.account_yt, pwd=config.pwd_yt):  

            def get_df_combined():
                # 抓取母體
                date =  datetime.date(datetime.strptime(ym,'%Y%m'))
#                 next_month = monthdelta(date, 1)
#                 print(next_month)    
                query = query_function(this_prod , mother , ym, papulation_colname)

                if type(query) == str: 
                    df_papu = get_SQL_raw_data2(query, account=config.account_yt, pwd=config.pwd_yt)
                else:
                    df_papu = query

                today = datetime.now().date()
                if today < monthdelta(date, 3):
                    df_papu['y'] = '999'
                    print(f"today: {today} < {ym} + 3 months, so don't have true y (all is 999)")
                else:
                    print(f"today: {today} >= {ym} + 3 months, so have true y")
                print('df_papu : ')
                print(df_papu.head())      


                # 將母體與特徵左右拼接
                writing_feature_file_path = None
                concat_df_outcome = get_feature_by_SOP_202503([ym], mother, drop_key_word, df_papu, this_prod, Fill_zero=True)

                key = str(ym)+'_df'
                df_combined =concat_df_outcome[key]
                print('df_combined : ')
                print(len(df_combined))
#                 print(df_combined.head().to_string(index = False))

                return df_combined

            # 拉取母體
            df_combined = get_df_combined()


            # 進行預測，產出各等級人數、預測後等級與特徵、DB名單檔、DB參照資訊檔
            df_level_with_bin_num, df_pred_and_features, id_list_to_db, ref_info_to_db =             predict_df_v230517(df_combined, [ym], writing_path, this_prod, mother, algorithm,
                               bins,papulation_colname, papulation_except_value,
                               target, frequency, edition_detail,new_edition)
            if market_flag_Y_N:
                # 轉換為 轉換率等級
                bins_label.sort(reverse=True)
                rank_list = list(set(id_list_to_db['rank'][id_list_to_db['rank'] != papulation_colname]))
                rank_list.sort()

                for ri, rk in enumerate(rank_list):
                    binlabel = bins_label[ri]
                    print(f'將等級{rk}轉換成{binlabel}')
                    df_pred_and_features['model_level'][df_pred_and_features['model_level']==str(rk)] = binlabel
                    id_list_to_db['rank'][id_list_to_db['rank']==str(rk)] = binlabel

                # 用真實轉換率標籤再轉回等級
                for lbri, lbrk in enumerate(label_to_rank):
                    label_rank = label_to_rank[lbri]
                    rank_label = str(lbri+1)
                    print(f'將轉換率標籤{lbrk}轉換成等級{rank_label}')
                    df_pred_and_features['model_level'][df_pred_and_features['model_level']==lbrk] = rank_label
                    id_list_to_db['rank'][id_list_to_db['rank']==lbrk] = rank_label


            print('df_level_with_bin_num : ')
            print(df_level_with_bin_num.to_string(index = False))

            print('df_pred_and_features : ')
            print(df_pred_and_features.head().to_string(index = False))

            print('id_list_to_db  : ')
            print(id_list_to_db.head().to_string(index = False))
            print('id_list_to_db (except) : ')
            print(id_list_to_db[np.isnan(id_list_to_db['probability'])].head().to_string(index = False))

            print('ref_info_to_db : ')
            print(ref_info_to_db.to_string(index = False))

            # 寫入DB(名單檔)
            save_db_id_list_mlops(write_db_Y_N, id_list_to_db, table_name='test_mlops_id_list')
            # 寫入DB(參照資訊檔)
            save_db_ref_info_mlops(write_db_Y_N, ref_info_to_db, table_name='test_mlops_ref_info')

            print(f'{this_prod}_{mother}_{snap_date} 名單產出完畢，先跳出迴圈!')
            break



        else:
            print(f'{this_prod}_{mother}_{snap_date} 先前已執行過了，執行下個母體!')  
        break

    need_other_tag = False
    untrain_mother = '潛客'
    if '非潛客' in mother_list and untrain_mother not in mother_list:
        if not whether_done_next_population_predict(this_file_path, this_prod, untrain_mother, target, algorithm, snap_date, 
                            db_table_rf='test_mlops_ref_info', db_table_IL='test_mlops_id_list',
                            account=config.account_yt, pwd=config.pwd_yt): 
            need_other_tag = True
            # 宣告沒有建模的名單參數
            mother = untrain_mother
            if untrain_mother =='潛客': show_name = '潛力客群'
            tag_name = show_name + '註記'
            rank = show_name
            print(f'{this_prod}沒有對{untrain_mother}進行建模,用{show_name}註記')
            date =  datetime.date(datetime.strptime(ym,'%Y%m'))
#             next_month = monthdelta(date, 1)
#             print(ym)    
            query = query_function(this_prod , mother , ym, papulation_colname)
            df_papu_untrain_mother = get_SQL_raw_data2(query)
            today = datetime.now().date()
            if today < monthdelta(date, 3):
                df_papu_untrain_mother['y'] = '999'
                print(f"today: {today} < {ym} + 3 months, so don't have true y (all is 999)")
            else:
                print(f"today: {today} >= {ym} + 3 months, so have true y")


            query = f"""
                select * from ds_sec.cf_custid where yyyymm = '{ym}'
            """
            df = get_SQL_raw_data2(query, account=config.account_yt, pwd=config.pwd_yt)
            df['yyyymm'] = df['yyyymm'].astype('int')

            df_papu_untrain_mother['yyyymm'] = df_papu_untrain_mother['yyyymm'].astype('int')
            papu_and_y_yyyymm = df_papu_untrain_mother[df_papu_untrain_mother['yyyymm']==int(ym)]

            df_untrain_mother = pd.merge(df, papu_and_y_yyyymm, how='left', on=['customer_id','yyyymm']) 
            mask_papulation = df_untrain_mother['y'].notna()
            df_untrain_mother = df_untrain_mother[mask_papulation]
            df_untrain_mother['y'] = df_untrain_mother['y'].astype('int')
        else:
            print(f'{this_prod}_{mother}_{snap_date} 先前已執行過了，執行下個母體!')  
    if need_other_tag:
        # 預測時間
        pred_date = datetime.today().strftime('%Y/%m/%d %H:%M')

        print('df_papu_untrain_mother : ')
        print(df_papu_untrain_mother.head().to_string(index = False))      

        id_list_to_db = pd.DataFrame(data={
                                            'product': this_prod,
                                            'target': target ,
                                            'population': mother,
                                            'frequency': frequency,
                                            'snap_date': snap_date,
                                            'party_id': df_untrain_mother['customer_id'],
                                            'tag_name': tag_name,
                                            'probability': np.nan,
                                            'rank': rank,
                                            'pred_date': pred_date})
        print('id_list_to_db_untrain : ')
        print(id_list_to_db.head().to_string(index = False))  


        ref_info_to_db = pd.DataFrame(data={
                                            'product': this_prod,
                                            'target': target ,
                                            'population': mother,
                                            'frequency': frequency,
                                            'edition': np.nan,
                                            'snap_date': snap_date ,
                                            'model_valid_falg': np.nan,
                                            'tag_name':  tag_name,
                                            'exception': '' ,
                                            'edition_detail': '沒有進行建模純註記',
                                            'pred_date': pred_date


                                        },index=[0])  
        print('ref_info_to_db_untrain : ')
        print(ref_info_to_db.to_string(index = False))

        save_db_id_list_mlops(write_db_Y_N, id_list_to_db, table_name='test_mlops_id_list')
        save_db_ref_info_mlops(write_db_Y_N, ref_info_to_db, table_name='test_mlops_ref_info')








# %%
