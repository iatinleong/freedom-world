#!/usr/bin/env python
# coding: utf-8
# %%


# loading parameter
import sys
import Module.config as config
# feature_file_path_fubon = config.feature_file_path_fubon
# feature_file_path_mlops = config.feature_file_path_mlops
# feature_file_path_ntb = config.feature_file_path_ntb
dump_feature_log_path = config.dump_feature_log_path
account, pwd = config.account, config.pwd
# table_orginal_list = config.table_orginal_list
# table_append_list = config.table_append_list
colname_object_list = config.colname_object_list 
colname_catgory_list_1 = config.colname_catgory_list_1
colname_catgory_list_2 = config.colname_catgory_list_2
colname_catgory_list_3 = config.colname_catgory_list_3
colname_catgory_list_4 = config.colname_catgory_list_4
colname_catgory_list_5 = config.colname_catgory_list_5
colname_catgory_list_6 = config.colname_catgory_list_6


# %%


import numpy as np
import pyarrow as pa
import pandas as pd
import matplotlib.pyplot as plt
import time
import pickle
import pandas.core.algorithms as algos
import scipy.stats.stats as stats
import re
import traceback
from datetime import datetime, timedelta
from numpy import mean
from pandas import Series
from sklearn.preprocessing import OneHotEncoder
from sklearn.model_selection import train_test_split, GridSearchCV, cross_val_score
from sklearn.ensemble import RandomForestClassifier
from xgboost import XGBClassifier
from sklearn.model_selection import RepeatedStratifiedKFold
from sklearn.metrics import roc_auc_score
import numpy as np
import pandas as pd
import time
import pickle
import gc
import os
import oracledb
from sqlalchemy.types import String, Integer, Float, DateTime, Boolean


# %%


# def create_feature_dir(input_ym ,feature_file_path = feature_file_path_mlops):
#     path = feature_file_path + '/' + input_ym + '/'
#     if not os.path.exists(path):
#         os.makedirs(path)
#         print(path, 'directory has been created')
#     else:
#         print('directory had already existed')


# %%


HOST = config.HOST # IP for ods
PORT =  config.PORT
SEVICE_NAME = config.SEVICE_NAME


# %%


def get_SQL_raw_data(query, account=account, pwd=pwd, table=''):
    from sqlalchemy import create_engine
    from sqlalchemy import text
    
    ACCOUNT = account # user name for ods
    PASSWORD = pwd # password 

    oracledb.init_oracle_client(lib_dir='/opt/instantclient_23_26')
    
    url = f"oracle+oracledb://{ACCOUNT}:{PASSWORD}@{HOST}:{PORT}/?service_name={SEVICE_NAME}"

    engine = create_engine(url)
    
    t0 = time.time()
    
    query_status = False
    
    try:
        sql_query = query # sql command
        with engine.connect() as conn:
            df = pd.read_sql(text(sql_query), conn) # DB table in python

        t1 = time.time()
        print("Running time of %s: %.0f sec" %(table, t1 - t0))
        print(table, 'loading completed')
        query_status = True
        engine.dispose()
        if len(df) > 0:
            return df
        else:
            print('length of dataframme is 0 !!')
            return pd.DataFrame()
    except Exception as e:
        print(f'[使用帳號] {account}')
        print(table, str(e))
        engine.dispose()
        return str(e)
    
    engine.dispose()
    
#     if query_status:
#         if len(df) > 0:
#             return df
#         else:
#             print('length of dataframme is 0 !!')
#             return pd.DataFrame()
#     else:
#         print('Query Failed !!!!')
#         return pd.DataFrame()


# %%


def get_SQL_raw_data2(query, account=account, pwd=pwd, table=''):
    ACCOUNT = account # user name for ods
    PASSWORD = pwd # password 

    oracledb.init_oracle_client(lib_dir='/opt/instantclient_23_26')
    dsn = oracledb.makedsn(host=HOST, port=PORT, service_name=SEVICE_NAME)
    conn , cursor= None, None
    try:
        conn = oracledb.connect(user=ACCOUNT,password=PASSWORD, dsn=dsn)
        cursor = conn.cursor()
        cursor.arraysize = 10000

        t0 = time.time()

        query_status = False
        print("執行查詢")
        cursor.execute(query)
        column_names = [item.lower() if isinstance(item,str) else item for item in [desc[0] for desc in cursor.description]]        
        data = cursor.fetchall()
        t1 = time.time()
#         print("取回資料 : %.0f sec" %( t1 - t0))
        try:
            cursor.close() if cursor else ''
            conn.close() if conn else ''
        except:
            print(str(e))
        
        df = pd.DataFrame(data,columns = column_names)
        t2 = time.time()
#         print("建arrow+轉pandas : %.0f sec" %( t2 - t1))
        
        print("Running time of : %.0f sec" %( t2 - t0))
        print('loading completed')
        query_status = True
        if len(df) > 0:
            return df
        else:
            print('length of dataframme is 0 !!')
            return pd.DataFrame()
    except Exception as e:
        print(f'[使用帳號] {account}')
        print( str(e))
        cursor.close() if cursor else ''
        conn.close() if conn else ''
        return str(e)
    
    engine.dispose()


# %%


def execute_sql(query, account=account, pwd=pwd, table=''):
    from sqlalchemy import create_engine
    from sqlalchemy import text
    
    ACCOUNT = account # user name for ods
    PASSWORD = pwd # password 
    
    oracledb.init_oracle_client(lib_dir='/opt/instantclient_23_26')
    
    url = f"oracle+oracledb://{ACCOUNT}:{PASSWORD}@{HOST}:{PORT}/?service_name={SEVICE_NAME}"
    
    engine = create_engine(url)

    t0 = time.time()
    try:
        sql_query = query # sql command
        with engine.begin() as conn:
            conn.execute(text(sql_query))
        conn.close()
        t1 = time.time()
        print("Running time of %s: %.0f sec" %(table, t1 - t0))
        print(table, 'executing completed')
    except Exception as e:
        print(table, str(e))
        
    engine.dispose()


# %%


def drop_SQL_raw_data(account, pwd, table_name):
    from sqlalchemy import create_engine
    from sqlalchemy import MetaData
    from sqlalchemy.ext.declarative import declarative_base
    
    ACCOUNT = account # user name for ods
    PASSWORD = pwd # password 

    oracledb.init_oracle_client(lib_dir='/opt/instantclient_23_26')
    
    url = f"oracle+oracledb://{ACCOUNT}:{PASSWORD}@{HOST}:{PORT}/?service_name={SEVICE_NAME}"

    engine = create_engine(url)
    
    # try:
    #     base = declarative_base()
    #     metadata = MetaData(engine, reflect=True)
    #     table = metadata.tables.get(table_name)
    #     if table is not None:
    #         query = 'drop table '+table_name+' purge'
    #         with engine.begin() as conn:
    #             conn.execute(text(query))
    #         t1 = time.time()
    #         conn.close()
    #         print(table_name, 'deleting')
    #     else:
    #         print(table_name, 'did not exist')
    # except Exception as e:
    #     print(table, str(e))
        
    engine.dispose()


# %%


def write_data_to_SQL(table_name, df, account=account, pwd=pwd, exist_action='append', chunk_size=10000, col_types=None):
#     col_types = {
#     '模型名稱' : String(30),
#     '母體' : String(30),
#     'retrain日期' : String(30),
#     'train_period' : String(250),
#     'valid_period': String(250),
#     'test_period': String(30),
#     'valid_auc': Float(),
#     'test_auc': Float(),
#     '訓練母體人數': Integer(),
#     '訓練母體y=1人數': Integer(),
#     'VALID_人數' :String(200),
#     'VALID_購買率' :String(200),
#     'TEST_人數' :String(200),
#     'TEST_購買率' :String(200),
#     '是否通過標準': String(30),
#     '版本':String(10),
#     'train_auc': Float() }
    from sqlalchemy import create_engine
    from sqlalchemy.types import String, Integer, Float
    ACCOUNT = account # user name for ods
    PASSWORD = pwd # password 

    oracledb.init_oracle_client(lib_dir='/opt/instantclient_23_26')
    
    url = f"oracle+oracledb://{ACCOUNT}:{PASSWORD}@{HOST}:{PORT}/?service_name={SEVICE_NAME}"

    engine = create_engine(url)

    table_name = table_name.upper()
    try:
        t0 = time.time()
        with engine.begin() as conn:
            df.to_sql(table_name, engine, if_exists=exist_action, index=False, chunksize=chunk_size, dtype=col_types)
        conn.close()
        t1 = time.time()
        print("[Success writing down to db] Running time : %.0f sec" %(t1 - t0))
    except Exception as e:
        print(table_name, str(e))   
        print("[Failed writing down to db]" )
    
    engine.dispose()


# %%


# define function to reduce the DF size
def reduce_mem_usage(df, verbose=True):
    numerics = ['int16', 'int32', 'int64', 'float16', 'float32', 'float64']
    start_mem = df.memory_usage().sum() / 1024**2    
    for col in df.columns:
        col_type = df[col].dtypes
        if col_type in numerics:
            c_min = df[col].min()
            c_max = df[col].max()
            if str(col_type)[:3] == 'int':
                if c_min > np.iinfo(np.int8).min and c_max < np.iinfo(np.int8).max:
                    df[col] = df[col].astype(np.int8)
                elif c_min > np.iinfo(np.int16).min and c_max < np.iinfo(np.int16).max:
                    df[col] = df[col].astype(np.int16)
                elif c_min > np.iinfo(np.int32).min and c_max < np.iinfo(np.int32).max:
                    df[col] = df[col].astype(np.int32)
                elif c_min > np.iinfo(np.int64).min and c_max < np.iinfo(np.int64).max:
                    df[col] = df[col].astype(np.int64)  
            else:
                if c_min > np.finfo(np.float16).min and c_max < np.finfo(np.float16).max:
                    df[col] = df[col].astype(np.float16)
                elif c_min > np.finfo(np.float32).min and c_max < np.finfo(np.float32).max:
                    df[col] = df[col].astype(np.float32)
                else:
                    df[col] = df[col].astype(np.float64)    
    end_mem = df.memory_usage().sum() / 1024**2
    if verbose: print('Mem. usage decreased to {:5.2f} Mb ({:.1f}% reduction)'.format(end_mem, 100 * (start_mem - end_mem) / start_mem))
    return df


# %%


def dump_table_log(table_name, feature_date, status, import_date):
    log_path = dump_feature_log_path + '/table_log_{0}.pickle'.format(feature_date)
    if not os.path.exists(log_path):
        t_log = {'0':
                    {
                    'table_name' : table_name,
                    'feature_date' : feature_date,
                    'status': status,
                    'import_date': import_date
                    }
                }
        with open(log_path, 'wb') as handler:
            pickle.dump(t_log, handler, protocol=pickle.HIGHEST_PROTOCOL)
        print('table_log on', feature_date, 'has been inserted')
    else:
        t_log = pd.read_pickle(log_path)
        t_log.update({str(len(t_log)):
                       {
                        'table_name' : table_name,
                        'feature_date' : feature_date,
                        'status': status,
                        'import_date': import_date
                        }
                     })
        with open(log_path, 'wb') as handler:
            pickle.dump(t_log, handler, protocol=pickle.HIGHEST_PROTOCOL)
        print('table_log on year:', feature_date, 'has been updated')


# %%


def feature_dump_202504(yyyymm_lst, sql_table_name_list, feature_file_path,account=account, pwd=pwd):
    account = account # user name for ods
    pwd = pwd # password 
    for ym in yyyymm_lst:
        # 確認是否有存在資料夾,若沒有則創建
        create_feature_dir(input_ym=ym)
        # LOOP
        for table in sql_table_name_list:
            # filename by case
            if str(table)[-1] != '_':
                file_path = feature_file_path + '/' + ym + '/' + table + '_' + ym + '.pickle'
            else:
                file_path = feature_file_path + '/' + ym + '/' + table + ym + '.pickle'
            # if pickle files existed, ignored them to prevent overwritting
            if os.path.exists(file_path):
                print(table, 'already existed')
                delete_table = table.lower()
                if table != 'CUST_':
                    drop_SQL_raw_data(account, pwd, delete_table)
            else:
                print(table, 'starting query')
                query = """SELECT * FROM {}""".format(table)
                df = get_SQL_raw_data(query=query, account=account, pwd=pwd, table=table)
                
#                 time.sleep(10)
                if df is not None:
#                     if table != 'CUST_':
#                         IDFOLLOW = pickle.load(open(feature_file_path + '/' + ym + '/CUST_' + ym + '.pickle', 'rb'))['customer_id']
#                         df = pd.merge(IDFOLLOW, df, how='left', on=['customer_id']) 
                    stime = time.time()
                    df = reduce_mem_usage(df)                     
                    if len(df) > 0:
                        #將 id,ym 轉成 object type
                        for col in colname_object_list:
                            if col in list(df.columns):
                                df[col] = df[col].astype('object')
                        #將 profile 內的類別型變數轉換成 category type 
                        if table == 'FTBD_profile_':
                            df[colname_catgory_list_1] = df[colname_catgory_list_1].astype('category')
                            print(colname_catgory_list_1)
                            if 'c_acct_valid_flag' in df.columns:
                                df[colname_catgory_list_2] = df[colname_catgory_list_2].astype('category')  
                                print(colname_catgory_list_2)
                        if table == 'FTBD_KYCQA_':
                            df[colname_catgory_list_3] = df[colname_catgory_list_3].astype('category')
                            print(colname_catgory_list_3)
                        if table == 'FTBD_EVENT_':
                            df[colname_catgory_list_4] = df[colname_catgory_list_4].astype('category')
                            print(colname_catgory_list_4)
                        if table == 'FTBD_JCI_':
                            df[colname_catgory_list_5] = df[colname_catgory_list_5].astype('category')
                            print(colname_catgory_list_5)
                        if table == 'FTBD_DGT1_':
                            df[colname_catgory_list_6] = df[colname_catgory_list_6].astype('category')
                            print(colname_catgory_list_6)
                        #將剩餘 object 特徵轉成 float type
                        if 'yyyymm' in list(df.columns):
                            cols = df.select_dtypes('object').drop(['customer_id','yyyymm'],axis=1).columns
                        else:
                            cols = df.select_dtypes('object').drop(['customer_id'],axis=1).columns
                        if cols.tolist() != []:
                            print('trans to float: '.format(cols.tolist()))
                            df[cols.tolist()] = df[cols.tolist()].astype('float') 
                        #轉完型態後寫入CDSW
                        pickle.dump(df, open(file_path, 'wb'), protocol = 4)
                        dump_table_log(table_name=table, feature_date=ym, status='Y', import_date=datetime.now().strftime('%Y%m%d %H:%M:%S'))
                        print('save', table, 'completed')
                        #drop the table from sql
                        time.sleep(1)
                        delete_table = table.lower()
                        if table != 'CUST_':
                            drop_SQL_raw_data(account, pwd, delete_table)
                    else:
                        dump_table_log(table_name=table, feature_date=ym, status='N', import_date=datetime.now().strftime('%Y%m%d %H:%M:%S'))
                        print(table, 'did not have data')
                    etime = time.time() - stime
                    print('saving table', table, 'requires', etime, 'sec')
                else:
                    print(table, 'no data on SQL')
#             time.sleep(10)


# %%


def send_table_to_sql(targ, table_name, account, pwd, exist_action = 'append'):
    dtype_dist = {}
    for col,dtype in targ.dtypes.items():
        dtype_name = str(dtype)
        if "object" == dtype_name or "category" == dtype_name :
            max_length = targ[col].apply(lambda x:len(str(x).encode('utf-8'))).max()
            string_length = int(max_length*1.2)
            dtype_dist[col] = String(length = string_length)
        elif "float" in dtype_name:
            dtype_dist[col] = Float
        elif "int" in dtype_name:
            dtype_dist[col] = Integer
        elif "datetime" in dtype_name:
            dtype_dist[col] = DateTime
        elif "bool" in dtype_name:
            dtype_dist[col] = Boolean

    write_data_to_SQL(table_name=table_name, df = targ, account = account, pwd = pwd,col_types=dtype_dist, exist_action=exist_action)





