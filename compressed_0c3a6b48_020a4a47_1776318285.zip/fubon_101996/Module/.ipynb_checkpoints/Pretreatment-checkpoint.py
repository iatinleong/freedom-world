#!/usr/bin/env python
# coding: utf-8
# %%

# %%

# loading parameter
import sys
import Module.config as config
account, pwd = config.account, config.pwd

table_append_list_2025 = config.table_append_list_2025
table_fin_table_path =  config.feature_file_path + '/df_fin_feats.csv'
compare_column_ym = '202302'

colname_catgory_list_202503 = config.colname_catgory_list_202503
colname_catgory_list_202503_1 = config.colname_catgory_list_202503_1
colname_catgory_list_202503_2 = config.colname_catgory_list_202503_2
write_monthly_path = config.temp_concat_path
skip_existing=True


# %%


# import packages
import numpy as np
import pandas as pd
import pyarrow.dataset as ds
import pyarrow as pa
import matplotlib.pyplot as plt
import time
import pickle
import pandas.core.algorithms as algos
import scipy.stats.stats as stats
import re
import traceback
import gc
import random
import os
from numpy import mean
from pandas import Series
from sklearn.preprocessing import OneHotEncoder
from sklearn.model_selection import train_test_split, GridSearchCV, cross_val_score
from sklearn.ensemble import RandomForestClassifier
from xgboost import XGBClassifier
from sklearn.model_selection import RepeatedStratifiedKFold
from sklearn.metrics import roc_auc_score
from sklearn.utils import resample
from os import listdir


# %%


# define function to reduce the DF size
def reduce_mem_usage(df, verbose=True):
    numerics = ['int16', 'int32', 'int64', 'float16', 'float32', 'float64']
    start_mem = df.memory_usage().sum() / 1024**2    
    for col in df.columns:
        col_type = df[col].dtypes
        if col_type in numerics:
            c_min = df[col].min()
            c_max = df[col].max()
            if str(col_type)[:3] == 'int':
                if c_min > np.iinfo(np.int8).min and c_max < np.iinfo(np.int8).max:
                    df[col] = df[col].astype(np.int8)
                elif c_min > np.iinfo(np.int16).min and c_max < np.iinfo(np.int16).max:
                    df[col] = df[col].astype(np.int16)
                elif c_min > np.iinfo(np.int32).min and c_max < np.iinfo(np.int32).max:
                    df[col] = df[col].astype(np.int32)
                elif c_min > np.iinfo(np.int64).min and c_max < np.iinfo(np.int64).max:
                    df[col] = df[col].astype(np.int64)  
            else:
                if c_min > np.finfo(np.float16).min and c_max < np.finfo(np.float16).max:
                    df[col] = df[col].astype(np.float16)
                elif c_min > np.finfo(np.float32).min and c_max < np.finfo(np.float32).max:
                    df[col] = df[col].astype(np.float32)
                else:
                    df[col] = df[col].astype(np.float64)    
    end_mem = df.memory_usage().sum() / 1024**2
    if verbose: print('Mem. usage decreased to {:5.2f} Mb ({:.1f}% reduction)'.format(end_mem, 100 * (start_mem - end_mem) / start_mem))
    return df


def reduce_mem_usage_plus(
    df: pd.DataFrame,
    verbose: bool = True,
    exclude_cols: tuple = ('customer_id', 'yyyymm'),
    convert_object_to_numeric: bool = True,
    convert_object_to_category: bool = True,
    to_category_codes: bool = False,   # 若模型可吃整數類別，可開
    prefer_unsigned: bool = False,      # 非負整數優先用 uint
    prefer_float32: bool = True,       # 禁用 float16，統一走 float32
    sparse_zero_threshold: float = None  # 例如 0.95 → 稀疏化比例 >=95% 是 0
):
    """
    安全且高效的降型：
    - 數值：int64→(u)int32, float64→float32（避免 float16）
    - object：可選轉 numeric 或 category；category 也可轉 codes（int32）
    - 稀疏：可選把高比例 0 的數值欄位轉 SparseDtype
    - 排除欄位：避免 key 被誤轉
    """
    if df is None or len(df) == 0:
        return df

    start_mem = df.memory_usage(deep=True).sum() / 1024**2

    # 先處理 object 欄位
    obj_cols = df.select_dtypes(include=['object']).columns.difference(exclude_cols)
    if len(obj_cols) > 0:
        if convert_object_to_numeric:
            # 將數字字串轉為數值；非數字變 NaN
            df.loc[:, obj_cols] = df.loc[:, obj_cols].apply(pd.to_numeric, errors='coerce')
        if convert_object_to_category:
            # 對仍是 object 的欄位，轉為 category
            obj_cols2 = df.select_dtypes(include=['object']).columns.difference(exclude_cols)
            for c in obj_cols2:
                df[c] = df[c].astype('category')

    # 若需要把 category 轉 codes（int32），常見於樹模型
    if to_category_codes:
        cat_cols = df.select_dtypes(include=['category']).columns.difference(exclude_cols)
        for c in cat_cols:
            df[c] = df[c].cat.codes.astype('int32')  # -1 代表 NA

    # 數值欄位降型：抓所有數值欄，再逐欄判斷是整數或浮點
    num_cols = df.select_dtypes(include=[np.number]).columns
    for col in num_cols:
        if col in exclude_cols:
            continue
        col_type = df[col].dtype

        if pd.api.types.is_integer_dtype(col_type):
            # 先看是否有 NA
            has_na = df[col].isna().any()
            c_min, c_max = df[col].min(), df[col].max()

            if prefer_unsigned and not has_na and c_min >= 0:
                # 非負：優先用無號整數（省一點）
                if c_max <= np.iinfo(np.uint8).max:
                    df[col] = df[col].astype('uint8')
                elif c_max <= np.iinfo(np.uint16).max:
                    df[col] = df[col].astype('uint16')
                elif c_max <= np.iinfo(np.uint32).max:
                    df[col] = df[col].astype('uint32')
                else:
                    df[col] = df[col].astype('uint64')
            else:
                # 有 NA 或有負數：用有號整數，或改用 nullable 整數
                if has_na:
                    # Pandas nullable 整數型，避免因 NA 變浮點
                    if c_min >= np.iinfo(np.int8).min and c_max <= np.iinfo(np.int8).max:
                        df[col] = df[col].astype('Int8')
                    elif c_min >= np.iinfo(np.int16).min and c_max <= np.iinfo(np.int16).max:
                        df[col] = df[col].astype('Int16')
                    elif c_min >= np.iinfo(np.int32).min and c_max <= np.iinfo(np.int32).max:
                        df[col] = df[col].astype('Int32')
                    else:
                        df[col] = df[col].astype('Int64')
                else:
                    if c_min >= np.iinfo(np.int8).min and c_max <= np.iinfo(np.int8).max:
                        df[col] = df[col].astype('int8')
                    elif c_min >= np.iinfo(np.int16).min and c_max <= np.iinfo(np.int16).max:
                        df[col] = df[col].astype('int16')
                    elif c_min >= np.iinfo(np.int32).min and c_max <= np.iinfo(np.int32).max:
                        df[col] = df[col].astype('int32')
                    else:
                        df[col] = df[col].astype('int64')

        elif pd.api.types.is_float_dtype(col_type):
            # 避免 float16；統一降到 float32
            if prefer_float32:
                df[col] = pd.to_numeric(df[col], downcast='float')  # 通常變 float32

    # 稀疏化（可選）：對高度稀疏的數值欄位轉 SparseDtype
    if sparse_zero_threshold is not None and 0 < sparse_zero_threshold < 1:
        num_cols2 = df.select_dtypes(include=[np.number]).columns.difference(exclude_cols)
        for c in num_cols2:
            s = df[c]
            # 只在數值欄上做；判斷 0 的比例
            try:
                zero_ratio = (s == 0).mean()
                if zero_ratio >= sparse_zero_threshold:
                    # 決定稀疏 dtype（保留原類型語意）
                    if pd.api.types.is_integer_dtype(s.dtype):
                        df[c] = df[c].astype(pd.SparseDtype('int', fill_value=0))
                    elif pd.api.types.is_float_dtype(s.dtype):
                        df[c] = df[c].astype(pd.SparseDtype('float', fill_value=0.0))
            except Exception:
                pass

    end_mem = df.memory_usage(deep=True).sum() / 1024**2
    if verbose:
        reduction = 100 * (start_mem - end_mem) / (start_mem if start_mem > 0 else 1)
        print(f"Mem. usage decreased to {end_mem:5.2f} Mb ({reduction:.1f}% reduction)")
    return df


def postprocess(df, category_cols=None, to_category_codes=False,
                exclude_cols=('customer_id','yyyymm')):
    """
    單表的輕量降型與欄位處理：
    - 指定的類別欄位先轉 category；如需再轉 codes（int32）
    - 其他欄位用 reduce_mem_usage_plus 做 object→numeric/category、float64→float32、int 寬度
    """
    if df is None or len(df) == 0:
        return df

    # 先處理指定的類別欄位（保留你原本語意）
    if category_cols:
        intersect = [c for c in category_cols if c in df.columns]
        for c in intersect:
            df[c] = df[c].astype('category')
            if to_category_codes:
                df[c] = df[c].cat.codes.astype('int32')  # -1 代表 NA

    # 再做通用降型（這裡預設不把所有 category 轉 codes，只做降型）
    df = reduce_mem_usage_plus(
        df,
        exclude_cols=exclude_cols,
        convert_object_to_numeric=True,   # 數字字串→數值
        convert_object_to_category=True,  # 其餘字串→category
        to_category_codes=False           # 類別清單另行處理，不在這裡全轉 codes
    )
    return df




def parquet_safe_cast(
    df: pd.DataFrame,
    target_engine: str = 'pyarrow',
    category_to_codes: bool = False,
    keep_uint8_uint16_on_pyarrow: bool = True,
    verbose: bool = True,
) -> pd.DataFrame:
    """
    寫 Parquet 前處理不相容 dtype：
    - 依引擎處理 UInt*：
      * pyarrow：保留 UInt8/UInt16（可選），強制將 UInt32/UInt64 → Int64（nullable）
      * fastparquet：所有 UInt* → Int64（nullable）
    - Sparse → densify（to_dense）
    - 可選：category → codes（int32）
    - 輸出轉型摘要（verbose）
    """
    out = df.copy()
    changes = []

    for c in out.columns:
        dt = out[c].dtype

        # 稀疏欄位 densify
        if pd.api.types.is_sparse(dt):
            out[c] = out[c].sparse.to_dense()
            changes.append((c, str(dt), 'dense'))

        # 無號整數處理
        if str(dt).startswith('UInt'):
            if target_engine == 'pyarrow':
                # 保留小位寬（可選），但避免 UInt32/UInt64
                if keep_uint8_uint16_on_pyarrow and str(dt) in ('UInt8', 'UInt16'):
                    # 保留，不動
                    continue
                # 其餘一律轉成 pandas nullable Int64
                out[c] = out[c].astype('Int64')
                changes.append((c, str(dt), 'Int64'))
            else:
                # fastparquet 或其他：全部轉 Int64（nullable）
                out[c] = out[c].astype('Int64')
                changes.append((c, str(dt), 'Int64'))

        # 類別欄位可選轉 codes
        if category_to_codes and pd.api.types.is_categorical_dtype(out[c].dtype):
            out[c] = out[c].cat.codes.astype('int32')  # -1 代表 NA
            changes.append((c, 'category', 'int32 codes'))

    if verbose and changes:
        print("[parquet_safe_cast] dtype 轉型摘要：")
        for c, src, tgt in changes:
            print(f"  {c}: {src} -> {tgt}")

    return out



def write_one_month_parquet(concat_df_outcome, ym, write_monthly_path,
                            compression='zstd', engine='pyarrow',
                            category_to_codes=False):
    """
    只寫當月的 concat_df，並把 outcome 中該月 _df 轉成 _path。
    安全處理：
    - 在寫檔前做 dtype 保險（UInt*→Int64、Sparse→dense）
    - 預設使用 pyarrow 引擎；保留 compression 與 index=False
    - 可選將 category 轉 codes（int32），增加互通性（例如給 Spark/其他系統）
    """
    os.makedirs(write_monthly_path, exist_ok=True)

    key_df = f"{ym}_df"
    key_path = f"{ym}_path"

    if key_df in concat_df_outcome:
        df = concat_df_outcome[key_df]

        # 寫前保險：處理 UInt* / Sparse / 可選 category→codes
        df_safe = parquet_safe_cast(df)
        if category_to_codes:
            # 僅對剩餘的 category 做 codes（避免 parquet_safe_cast 中重複）
            cat_cols = df_safe.select_dtypes(include=['category']).columns
            for c in cat_cols:
                df_safe[c] = df_safe[c].cat.codes.astype('int32')  # -1 表示 NA

        # 輸出路徑
        out_path = os.path.join(write_monthly_path, f"{ym}.parquet")

        # 寫入：建議使用 pyarrow；如需 fastparquet，請確保已移除 UInt* 與 Sparse
        df_safe.to_parquet(out_path, compression=compression, engine=engine, index=False)

        # 記錄路徑與釋放記憶體
        concat_df_outcome[key_path] = out_path
        del concat_df_outcome[key_df]
        gc.collect()

    return concat_df_outcome



# def write_one_month_parquet(concat_df_outcome, ym, write_monthly_path, compression='zstd'):
#     """只寫當月的 concat_df，並把 outcome 中該月 _df 轉成 _path。"""
#     os.makedirs(write_monthly_path, exist_ok=True)
#     key_df = f"{ym}_df"
#     key_path = f"{ym}_path"
#     if key_df in concat_df_outcome:
#         out_path = os.path.join(write_monthly_path, f"{ym}.parquet")
#         concat_df_outcome[key_df].to_parquet(out_path, compression=compression)
#         concat_df_outcome[key_path] = out_path
#         # 釋放該月的 df，避免持有所有月份的大 DF
#         del concat_df_outcome[key_df]
#         gc.collect()
#     return concat_df_outcome



# def read_parquet_with_dataset(dataset_dir, filter_expr=None, batch_size=200_000, cast_uint_to_int64=True):
#     dataset = ds.dataset(dataset_dir, format="parquet")
#     batches = dataset.to_batches(columns=None, filter=filter_expr, batch_size=batch_size)
#     df_list = []
#     for b in batches:
#         if cast_uint_to_int64:
#             # 把 batch 轉 Table 後做 cast 再轉 pandas
#             tbl = pa.Table.from_batches([b])
#             fields = []
#             for f in tbl.schema:
#                 if pa.types.is_unsigned_integer(f.type):
#                     fields.append(pa.field(f.name, pa.int64()))
#                 else:
#                     fields.append(f)
#             new_schema = pa.schema(fields)
#             tbl = tbl.cast(new_schema)
#             df = tbl.to_pandas()  # 預設用 int64
#         else:
#             df = b.to_pandas()
#         df_list.append(df)
#     return pd.concat(df_list, axis=0, ignore_index=True, sort=False, copy=False)


def _cast_unsigned_to_int64(table: pa.Table) -> pa.Table:
    """
    只在 schema 存在無號整數時才做 cast → int64（有 NA 的情境也安全）。
    """
    fields = []
    need_cast = False
    for f in table.schema:
        if pa.types.is_unsigned_integer(f.type):
            fields.append(pa.field(f.name, pa.int64()))
            need_cast = True
        else:
            fields.append(f)
    if need_cast:
        return table.cast(pa.schema(fields))
    return table


def _types_mapper_nullable(pa_type: pa.DataType):
    """
    把 PyArrow 型別映射成 pandas 的 nullable dtypes（避免 float64/整數被提升）。
    - Int8/16/32/64 → pandas Int8/16/32/64（nullable）
    - Float32 → pandas Float32（nullable）
    - 其他維持預設（由 to_pandas 決定）
    """
    import numpy as np
    if pa.types.is_integer(pa_type):
        bw = pa_type.bit_width
        # Arrow 的 int → pandas 的 nullable Int*
        if bw == 8:
            return pd.Int8Dtype()
        elif bw == 16:
            return pd.Int16Dtype()
        elif bw == 32:
            return pd.Int32Dtype()
        elif bw == 64:
            return pd.Int64Dtype()
    elif pa.types.is_floating(pa_type):
        # 明確保留 Float32（避免變成 float64）
        if pa.types.is_float32(pa_type):
            return pd.Float32Dtype()
        # float64 用預設即可
    # 其他型別交給預設處理
    return None


def read_parquet_with_dataset(dataset_dir,filter_expr=None,columns=None,batch_size=200_000,
    cast_uint_to_int64=True,
    categorical=True,
    use_threads=True,
    preserve_nullable=True,
) -> pd.DataFrame:

    """
    以 PyArrow Dataset 讀取 parquet 目錄：
    - 使用 dataset.to_batches(...)，避免使用各版本不一致的 .scan API。
    - categorical=True：Arrow dictionary → pandas Categorical（保留語義）。
    - preserve_nullable=True：Int* / Float32 以 pandas nullable dtype 回復。
    - cast_uint_to_int64=True：如有 UInt* 欄位，轉成 int64 以避免下游不相容。
    """
    dataset = ds.dataset(dataset_dir, format="parquet")

    batches = dataset.to_batches(
        columns=columns,
        filter=filter_expr,
        batch_size=batch_size,
        use_threads=use_threads,
    )

    df_list = []
    for rb in batches:
        # 轉為 Table，以便進行 schema cast
        table = pa.Table.from_batches([rb])
        if cast_uint_to_int64:
            table = _cast_unsigned_to_int64(table)
        types_mapper = _types_mapper_nullable if preserve_nullable else None
        df = table.to_pandas(types_mapper=types_mapper, categorical=categorical)
        df_list.append(df)

    if not df_list:
        return pd.DataFrame()
    return pd.concat(df_list, axis=0, ignore_index=True, sort=False, copy=False)




# %%

def combine_multi_year_df(do_ym_lst, concat_df_outcome):
    colname_initial = concat_df_outcome[str(do_ym_lst[0])+'_df'].columns
    col_match_status = []
    for ym in do_ym_lst[1:] :
        colname = concat_df_outcome[str(ym)+'_df'].columns
        if len(colname) == len(colname_initial):
            if sum(colname == colname_initial) == len(colname):
                print('{} concat_df : colnames are no problemed'.format(ym))
                col_match_status.append(True)
            else:
                print('{} concat_df : colnames are not matched!!!!'.format(ym))
                col_match_status.append(False)                
        else:
            print('{} concat_df : colsize is not matched!!!! '.format(ym))
            col_match_status.append(False)
    if sum(col_match_status)+1 == len(do_ym_lst):
        st_time = time.time()
        combine_ym_table_list = []
        for ym in do_ym_lst :
            combine_ym_table_list.append(concat_df_outcome[str(ym)+'_df'])
        #合併TABLE
        print('{} year will be concated ......'.format(do_ym_lst))
        df_combine_ym = pd.concat(combine_ym_table_list, axis = 0, ignore_index=True)
        end_time = time.time()
        print('combine_multi_year_df,  runtime: {} minutes'.format(round((end_time-st_time)/60),2))
        # 確認所有類別變數的型態
        print('Confirm categorical feature ...'.format(do_ym_lst))
        st_time = time.time() 
        obj_cols = df_combine_ym.select_dtypes('object').drop(['customer_id'],axis=1).columns
        obj_cols_list = obj_cols.tolist()
        if len(obj_cols_list) > 0 :
            df_combine_ym[obj_cols_list] = df_combine_ym[obj_cols_list].astype('category') 
#             for obj_col in obj_cols_list:
#                 df_combine_ym[obj_col] = df_combine_ym[obj_col].astype('category')            
        else:
            print('don"t have any object col for trans to categorical feature') 
        print('trans to categorical feature,  runtime: {} minutes'.format(round((end_time-st_time)/60),2))
        return df_combine_ym
    else:
        print('col_match_status is false')
        raise ValueError('col_match_status is false')


# %%


def read_feature_by_sampling(ym,this_prod,mother,drop_key_word,Fill_zero):
    from Module.Sql_module import get_SQL_raw_data,get_SQL_raw_data2
    
    query1 = f"""
    select
    /*+ PARALLEL(a 4) PARALLEL(inn 4) PARALLEL(b 4) PARALLEL(c 4) PARALLEL(d 4) PARALLEL(e 4) PARALLEL(f 4) PARALLEL(g 4) PARALLEL(h 4) PARALLEL(i 4)*/
    *
    from (select * from ds_sec.cf_custid PARTITION ("P_{ym}")) a
    join(select customer_id,yyyymm from mlops_population_sampling where product = '{this_prod}' and population = '{mother}' and yyyymm = '{ym}') inn
    using (customer_id ,yyyymm)
    join (select * from ds_sec.cf_asset1 PARTITION ("P_{ym}")) b
    using (customer_id ,yyyymm)
    join (select * from ds_sec.cf_asset2 PARTITION ("P_{ym}")) c
    using (customer_id ,yyyymm)
    join (select * from ds_sec.cf_asset3 PARTITION ("P_{ym}")) d
    using (customer_id ,yyyymm)
    join (select * from ds_sec.cf_asset4 PARTITION ("P_{ym}")) e
    using (customer_id ,yyyymm)
    join (select * from ds_sec.cf_actubnf PARTITION ("P_{ym}")) f
    using (customer_id ,yyyymm)
    join (select * from ds_sec.cf_actubnfroi PARTITION ("P_{ym}")) g
    using (customer_id ,yyyymm)
    join (select * from ds_sec.cf_invbnf PARTITION ("P_{ym}")) h
    using (customer_id ,yyyymm)
    join (select * from ds_sec.cf_invbnfroi PARTITION ("P_{ym}")) i
    using (customer_id ,yyyymm)
    """
    
    query2 = f"""
    select
    /*+ PARALLEL(a 4) PARALLEL(inn 4) PARALLEL(b 4) PARALLEL(c 4) PARALLEL(d 4) PARALLEL(e 4) PARALLEL(f 4) PARALLEL(g 4) PARALLEL(h 4) PARALLEL(i 4) PARALLEL(j 4)*/
    *
    from (select * from ds_sec.cf_custid PARTITION ("P_{ym}")) a
    join(select customer_id,yyyymm from mlops_population_sampling where product = '{this_prod}' and population = '{mother}' and yyyymm = '{ym}')inn
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_TXN_AP PARTITION ("P_{ym}")) b
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_TXN_FD PARTITION ("P_{ym}")) c
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_TXN_FB PARTITION ("P_{ym}")) d
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_TXN_FS PARTITION ("P_{ym}")) e
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_TXN_FU PARTITION ("P_{ym}")) f
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_TXN_STMT PARTITION ("P_{ym}")) g
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_TXN_SN PARTITION ("P_{ym}")) h
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_TXN_STSS PARTITION ("P_{ym}")) i
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_TXN_STST PARTITION ("P_{ym}")) j
    using (customer_id ,yyyymm)
    """
        
    query3 = f"""
    select
    /*+ PARALLEL(a 4) PARALLEL(inn 4) PARALLEL(b 4) PARALLEL(c 4) PARALLEL(d 4) PARALLEL(e 4) PARALLEL(f 4) PARALLEL(g 4) PARALLEL(h 4) PARALLEL(i 4) PARALLEL(j 4) PARALLEL(k 4)*/
    *
    from (select * from ds_sec.cf_custid PARTITION ("P_{ym}")) a
    join(select customer_id,yyyymm from mlops_population_sampling where product = '{this_prod}' and population = '{mother}' and yyyymm = '{ym}')inn
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_TXN_BSBL PARTITION ("P_{ym}")) b
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_TXN_INSURANCE PARTITION ("P_{ym}")) c
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_TXN_SIP PARTITION ("P_{ym}")) d
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_TXN_STDT PARTITION ("P_{ym}")) e
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_TXN_LOAN PARTITION ("P_{ym}")) f
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_TXN_STYPE PARTITION ("P_{ym}")) g
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_TXN_MAEC PARTITION ("P_{ym}")) h
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_TXN_CURRENCY PARTITION ("P_{ym}")) i
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_TXN_FPBR PARTITION ("P_{ym}")) j
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_AUM PARTITION ("P_{ym}")) k
    using (customer_id ,yyyymm)
    """
        
    query4 = f"""
    select
    /*+ PARALLEL(a 4) PARALLEL(inn 4) PARALLEL(b 4) PARALLEL(c 4) PARALLEL(d 4) PARALLEL(e 4) PARALLEL(f 4) PARALLEL(g 4) PARALLEL(h 4) PARALLEL(i 4)*/
    *
    from (select * from ds_sec.cf_custid PARTITION ("P_{ym}")) a
    join(select customer_id,yyyymm from mlops_population_sampling where product = '{this_prod}' and population = '{mother}' and yyyymm = '{ym}')inn
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_PROFILE PARTITION ("P_{ym}")) b
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_PROFOLIO1 PARTITION ("P_{ym}")) c
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_PROFOLIO2 PARTITION ("P_{ym}")) d
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_PROFOLIO3 PARTITION ("P_{ym}")) e
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_PROFOLIO4 PARTITION ("P_{ym}")) f
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_PROFOLIO5 PARTITION ("P_{ym}")) g
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_PROFOLIO6 PARTITION ("P_{ym}")) h
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_PROFOLIO7 PARTITION ("P_{ym}")) i
    using (customer_id ,yyyymm)
    """
        
    query5 = f"""
    select
    /*+ PARALLEL(a 4) PARALLEL(inn 4) PARALLEL(b 4) PARALLEL(c 4) PARALLEL(d 4) PARALLEL(e 4) PARALLEL(f 4) PARALLEL(g 4) PARALLEL(h 4) PARALLEL(i 4) PARALLEL(j 4) PARALLEL(k 4) PARALLEL(l 4)*/
    *
    from (select * from ds_sec.cf_custid PARTITION ("P_{ym}")) a
    join(select customer_id,yyyymm from mlops_population_sampling where product = '{this_prod}' and population = '{mother}' and yyyymm = '{ym}')inn
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_INTERACT_ECDAY PARTITION ("P_{ym}")) b
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_INTERACT_ECPROD PARTITION ("P_{ym}")) c
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_INTERACT_EDM PARTITION ("P_{ym}")) d
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_INTERACT_LINE PARTITION ("P_{ym}")) e
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_CONTRACT_DUE PARTITION ("P_{ym}")) f
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_CONTRACT PARTITION ("P_{ym}")) g
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_EVENT PARTITION ("P_{ym}")) h
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_KYCQA PARTITION ("P_{ym}")) i
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_JCI PARTITION ("P_{ym}")) j
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_DGT1 PARTITION ("P_{ym}")) k
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_DGT2 PARTITION ("P_{ym}")) l
    using (customer_id ,yyyymm)
    """
    
    try:

        # 逐張表查詢
        df1 = get_SQL_raw_data2(query=query1); print(f"特徵1: {0 if df1 is None else len(df1)}")
        df2 = get_SQL_raw_data2(query=query2); print(f"特徵2: {0 if df2 is None else len(df2)}")
        df3 = get_SQL_raw_data2(query=query3); print(f"特徵3: {0 if df3 is None else len(df3)}")
        df4 = get_SQL_raw_data2(query=query4); print(f"特徵4: {0 if df4 is None else len(df4)}")
        df5 = get_SQL_raw_data2(query=query5); print(f"特徵5: {0 if df5 is None else len(df5)}")

        # 任一為 None 直接返回
        dfs = [df1, df2, df3, df4, df5]
        if any(d is None or len(d)==0 for d in dfs):
            print("有特徵表未撈到資料")
            return None
 ########################################################################################################                  
        # === 各表個別降型/類別處理（df4/df5 用你指定的類別欄位清單） ===
        df1 = postprocess(df1)
        df2 = postprocess(df2)
        df3 = postprocess(df3)
        df4 = postprocess(df4, category_cols=colname_catgory_list_202503_1)
        df5 = postprocess(df5, category_cols=colname_catgory_list_202503_2)
#########################################################################################################            
        # === 排除不要的特徵（每表自己先 drop，避免最後大表才 drop 的複製成本） ===
        if drop_key_word:
            for drop_kw in drop_key_word:
                for d in (df1, df2, df3, df4, df5):
                    to_drop = [a for a in d.columns if drop_kw in a]
                    if to_drop:
                        d.drop(columns=to_drop, inplace=True, errors='ignore')

        # === 用 MultiIndex 對齊後做連續 join（取代排序+reset+concat） ===
        # df1 保留 key 欄位；其他表在設好 index 後，先把 key 欄位去掉避免重複
        df1 = df1.set_index(['customer_id','yyyymm'], drop=False)

        def set_idx_and_drop_keys(d):
            d = d.set_index(['customer_id','yyyymm'], drop=False)
            d = d.drop(columns=['customer_id','yyyymm'], errors='ignore')
            return d

        df2 = set_idx_and_drop_keys(df2)
        df3 = set_idx_and_drop_keys(df3)
        df4 = set_idx_and_drop_keys(df4)
        df5 = set_idx_and_drop_keys(df5)

        # 連續 join（how='left' 保留 df1 母集合；不排序、不 reset、不額外 copy）
        merge_df = df1.join(df2, how='left')\
                      .join(df3, how='left')\
                      .join(df4, how='left')\
                      .join(df5, how='left')
        if Fill_zero:
            feature_list = list(merge_df.select_dtypes(exclude = ['category','object']))
            merge_df[feature_list] = merge_df[feature_list].fillna(0)       
        # merge_df = pd.concat([df1,df2,df3,df4,df5],axis = 1,copy = False).copy()
        
        return merge_df
    except Exception as e:
        print(f"查詢失敗:-{e}")
        return None


# %%


def read_feature_by_all(ym,this_prod,mother,drop_key_word,Fill_zero):
    from Module.Sql_module import get_SQL_raw_data,get_SQL_raw_data2

    query1 = f"""
    select
    /*+ PARALLEL(a 4) PARALLEL(inn 4) PARALLEL(b 4) PARALLEL(c 4) PARALLEL(d 4) PARALLEL(e 4) PARALLEL(f 4) PARALLEL(g 4) PARALLEL(h 4) PARALLEL(i 4)*/
    *
    from (select * from ds_sec.cf_custid PARTITION ("P_{ym}")) a
    join(select customer_id,yyyymm FROM MLOPS_POPULATION WHERE YYYYMM = '{ym}' AND SEGMENT = '{mother}')inn
    using (customer_id ,yyyymm)
    join (select * from ds_sec.cf_asset1 PARTITION ("P_{ym}")) b
    using (customer_id ,yyyymm)
    join (select * from ds_sec.cf_asset2 PARTITION ("P_{ym}")) c
    using (customer_id ,yyyymm)
    join (select * from ds_sec.cf_asset3 PARTITION ("P_{ym}")) d
    using (customer_id ,yyyymm)
    join (select * from ds_sec.cf_asset4 PARTITION ("P_{ym}")) e
    using (customer_id ,yyyymm)
    join (select * from ds_sec.cf_actubnf PARTITION ("P_{ym}")) f
    using (customer_id ,yyyymm)
    join (select * from ds_sec.cf_actubnfroi PARTITION ("P_{ym}")) g
    using (customer_id ,yyyymm)
    join (select * from ds_sec.cf_invbnf PARTITION ("P_{ym}")) h
    using (customer_id ,yyyymm)
    join (select * from ds_sec.cf_invbnfroi PARTITION ("P_{ym}")) i
    using (customer_id ,yyyymm)
    """
    
    query2 = f"""
    select
    /*+ PARALLEL(a 4) PARALLEL(inn 4) PARALLEL(b 4) PARALLEL(c 4) PARALLEL(d 4) PARALLEL(e 4) PARALLEL(f 4) PARALLEL(g 4) PARALLEL(h 4) PARALLEL(i 4) PARALLEL(j 4)*/
    *
    from (select * from ds_sec.cf_custid PARTITION ("P_{ym}")) a
    join(select customer_id,yyyymm FROM MLOPS_POPULATION WHERE YYYYMM = '{ym}' AND SEGMENT = '{mother}')inn
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_TXN_AP PARTITION ("P_{ym}")) b
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_TXN_FD PARTITION ("P_{ym}")) c
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_TXN_FB PARTITION ("P_{ym}")) d
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_TXN_FS PARTITION ("P_{ym}")) e
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_TXN_FU PARTITION ("P_{ym}")) f
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_TXN_STMT PARTITION ("P_{ym}")) g
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_TXN_SN PARTITION ("P_{ym}")) h
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_TXN_STSS PARTITION ("P_{ym}")) i
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_TXN_STST PARTITION ("P_{ym}")) j
    using (customer_id ,yyyymm)
    """
        
    query3 = f"""
    select
    /*+ PARALLEL(a 4) PARALLEL(inn 4) PARALLEL(b 4) PARALLEL(c 4) PARALLEL(d 4) PARALLEL(e 4) PARALLEL(f 4) PARALLEL(g 4) PARALLEL(h 4) PARALLEL(i 4) PARALLEL(j 4) PARALLEL(k 4)*/
    *
    from (select * from ds_sec.cf_custid PARTITION ("P_{ym}")) a
    join(select customer_id,yyyymm FROM MLOPS_POPULATION WHERE YYYYMM = '{ym}' AND SEGMENT = '{mother}')inn
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_TXN_BSBL PARTITION ("P_{ym}")) b
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_TXN_INSURANCE PARTITION ("P_{ym}")) c
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_TXN_SIP PARTITION ("P_{ym}")) d
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_TXN_STDT PARTITION ("P_{ym}")) e
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_TXN_LOAN PARTITION ("P_{ym}")) f
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_TXN_STYPE PARTITION ("P_{ym}")) g
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_TXN_MAEC PARTITION ("P_{ym}")) h
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_TXN_CURRENCY PARTITION ("P_{ym}")) i
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_TXN_FPBR PARTITION ("P_{ym}")) j
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_AUM PARTITION ("P_{ym}")) k
    using (customer_id ,yyyymm)
    """
        
    query4 = f"""
    select
    /*+ PARALLEL(a 4) PARALLEL(inn 4) PARALLEL(b 4) PARALLEL(c 4) PARALLEL(d 4) PARALLEL(e 4) PARALLEL(f 4) PARALLEL(g 4) PARALLEL(h 4) PARALLEL(i 4)*/
    *
    from (select * from ds_sec.cf_custid PARTITION ("P_{ym}")) a
    join(select customer_id,yyyymm FROM MLOPS_POPULATION WHERE YYYYMM = '{ym}' AND SEGMENT = '{mother}')inn
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_PROFILE PARTITION ("P_{ym}")) b
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_PROFOLIO1 PARTITION ("P_{ym}")) c
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_PROFOLIO2 PARTITION ("P_{ym}")) d
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_PROFOLIO3 PARTITION ("P_{ym}")) e
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_PROFOLIO4 PARTITION ("P_{ym}")) f
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_PROFOLIO5 PARTITION ("P_{ym}")) g
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_PROFOLIO6 PARTITION ("P_{ym}")) h
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_PROFOLIO7 PARTITION ("P_{ym}")) i
    using (customer_id ,yyyymm)
    """
        
    query5 = f"""
    select
    /*+ PARALLEL(a 4) PARALLEL(inn 4) PARALLEL(b 4) PARALLEL(c 4) PARALLEL(d 4) PARALLEL(e 4) PARALLEL(f 4) PARALLEL(g 4) PARALLEL(h 4) PARALLEL(i 4) PARALLEL(j 4) PARALLEL(k 4) PARALLEL(l 4)*/
    *
    from (select * from ds_sec.cf_custid PARTITION ("P_{ym}")) a
    join(select customer_id,yyyymm FROM MLOPS_POPULATION WHERE YYYYMM = '{ym}' AND SEGMENT = '{mother}')inn
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_INTERACT_ECDAY PARTITION ("P_{ym}")) b
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_INTERACT_ECPROD PARTITION ("P_{ym}")) c
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_INTERACT_EDM PARTITION ("P_{ym}")) d
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_INTERACT_LINE PARTITION ("P_{ym}")) e
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_CONTRACT_DUE PARTITION ("P_{ym}")) f
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_CONTRACT PARTITION ("P_{ym}")) g
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_EVENT PARTITION ("P_{ym}")) h
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_KYCQA PARTITION ("P_{ym}")) i
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_JCI PARTITION ("P_{ym}")) j
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_DGT1 PARTITION ("P_{ym}")) k
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_DGT2 PARTITION ("P_{ym}")) l
    using (customer_id ,yyyymm)
    """
    
    query6 = f"""
    select
    /*+ PARALLEL(a 4) PARALLEL(inn 4) PARALLEL(b 4) PARALLEL(c 4) PARALLEL(d 4) PARALLEL(e 4) PARALLEL(f 4) PARALLEL(g 4) PARALLEL(h 4) PARALLEL(i 4)*/
    *
    from (select * from ds_sec.cf_custid PARTITION ("P_{ym}")) a
    join(select customer_id,yyyymm FROM MLOPS_POPULATION WHERE YYYYMM = '{ym}')inn
    using (customer_id ,yyyymm)
    join (select * from ds_sec.cf_asset1 PARTITION ("P_{ym}")) b
    using (customer_id ,yyyymm)
    join (select * from ds_sec.cf_asset2 PARTITION ("P_{ym}")) c
    using (customer_id ,yyyymm)
    join (select * from ds_sec.cf_asset3 PARTITION ("P_{ym}")) d
    using (customer_id ,yyyymm)
    join (select * from ds_sec.cf_asset4 PARTITION ("P_{ym}")) e
    using (customer_id ,yyyymm)
    join (select * from ds_sec.cf_actubnf PARTITION ("P_{ym}")) f
    using (customer_id ,yyyymm)
    join (select * from ds_sec.cf_actubnfroi PARTITION ("P_{ym}")) g
    using (customer_id ,yyyymm)
    join (select * from ds_sec.cf_invbnf PARTITION ("P_{ym}")) h
    using (customer_id ,yyyymm)
    join (select * from ds_sec.cf_invbnfroi PARTITION ("P_{ym}")) i
    using (customer_id ,yyyymm)
    """
    
    query7 = f"""
    select
    /*+ PARALLEL(a 4) PARALLEL(inn 4) PARALLEL(b 4) PARALLEL(c 4) PARALLEL(d 4) PARALLEL(e 4) PARALLEL(f 4) PARALLEL(g 4) PARALLEL(h 4) PARALLEL(i 4) PARALLEL(j 4)*/
    *
    from (select * from ds_sec.cf_custid PARTITION ("P_{ym}")) a
    join(select customer_id,yyyymm FROM MLOPS_POPULATION WHERE YYYYMM = '{ym}')inn
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_TXN_AP PARTITION ("P_{ym}")) b
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_TXN_FD PARTITION ("P_{ym}")) c
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_TXN_FB PARTITION ("P_{ym}")) d
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_TXN_FS PARTITION ("P_{ym}")) e
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_TXN_FU PARTITION ("P_{ym}")) f
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_TXN_STMT PARTITION ("P_{ym}")) g
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_TXN_SN PARTITION ("P_{ym}")) h
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_TXN_STSS PARTITION ("P_{ym}")) i
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_TXN_STST PARTITION ("P_{ym}")) j
    using (customer_id ,yyyymm)
    """
        
    query8 = f"""
    select
    /*+ PARALLEL(a 4) PARALLEL(inn 4) PARALLEL(b 4) PARALLEL(c 4) PARALLEL(d 4) PARALLEL(e 4) PARALLEL(f 4) PARALLEL(g 4) PARALLEL(h 4) PARALLEL(i 4) PARALLEL(j 4) PARALLEL(k 4)*/
    *
    from (select * from ds_sec.cf_custid PARTITION ("P_{ym}")) a
    join(select customer_id,yyyymm FROM MLOPS_POPULATION WHERE YYYYMM = '{ym}')inn
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_TXN_BSBL PARTITION ("P_{ym}")) b
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_TXN_INSURANCE PARTITION ("P_{ym}")) c
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_TXN_SIP PARTITION ("P_{ym}")) d
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_TXN_STDT PARTITION ("P_{ym}")) e
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_TXN_LOAN PARTITION ("P_{ym}")) f
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_TXN_STYPE PARTITION ("P_{ym}")) g
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_TXN_MAEC PARTITION ("P_{ym}")) h
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_TXN_CURRENCY PARTITION ("P_{ym}")) i
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_TXN_FPBR PARTITION ("P_{ym}")) j
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_AUM PARTITION ("P_{ym}")) k
    using (customer_id ,yyyymm)
    """
        
    query9 = f"""
    select
    /*+ PARALLEL(a 4) PARALLEL(inn 4) PARALLEL(b 4) PARALLEL(c 4) PARALLEL(d 4) PARALLEL(e 4) PARALLEL(f 4) PARALLEL(g 4) PARALLEL(h 4) PARALLEL(i 4)*/
    *
    from (select * from ds_sec.cf_custid PARTITION ("P_{ym}")) a
    join(select customer_id,yyyymm FROM MLOPS_POPULATION WHERE YYYYMM = '{ym}')inn
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_PROFILE PARTITION ("P_{ym}")) b
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_PROFOLIO1 PARTITION ("P_{ym}")) c
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_PROFOLIO2 PARTITION ("P_{ym}")) d
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_PROFOLIO3 PARTITION ("P_{ym}")) e
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_PROFOLIO4 PARTITION ("P_{ym}")) f
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_PROFOLIO5 PARTITION ("P_{ym}")) g
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_PROFOLIO6 PARTITION ("P_{ym}")) h
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_PROFOLIO7 PARTITION ("P_{ym}")) i
    using (customer_id ,yyyymm)
    """
        
    query10 = f"""
    select
    /*+ PARALLEL(a 4) PARALLEL(inn 4) PARALLEL(b 4) PARALLEL(c 4) PARALLEL(d 4) PARALLEL(e 4) PARALLEL(f 4) PARALLEL(g 4) PARALLEL(h 4) PARALLEL(i 4) PARALLEL(j 4) PARALLEL(k 4) PARALLEL(l 4)*/
    *
    from (select * from ds_sec.cf_custid PARTITION ("P_{ym}")) a
    join(select customer_id,yyyymm FROM MLOPS_POPULATION WHERE YYYYMM = '{ym}')inn
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_INTERACT_ECDAY PARTITION ("P_{ym}")) b
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_INTERACT_ECPROD PARTITION ("P_{ym}")) c
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_INTERACT_EDM PARTITION ("P_{ym}")) d
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_INTERACT_LINE PARTITION ("P_{ym}")) e
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_CONTRACT_DUE PARTITION ("P_{ym}")) f
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_CONTRACT PARTITION ("P_{ym}")) g
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_EVENT PARTITION ("P_{ym}")) h
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_KYCQA PARTITION ("P_{ym}")) i
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_JCI PARTITION ("P_{ym}")) j
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_DGT1 PARTITION ("P_{ym}")) k
    using (customer_id ,yyyymm)
    join (select * from ds_sec.CF_DGT2 PARTITION ("P_{ym}")) l
    using (customer_id ,yyyymm)
    """
    
    try:
        if mother == '不分潛客':
            df1 = get_SQL_raw_data2(query=query6); print(f"特徵1: {0 if df1 is None else len(df1)}")
            df2 = get_SQL_raw_data2(query=query7); print(f"特徵2: {0 if df2 is None else len(df2)}")
            df3 = get_SQL_raw_data2(query=query8); print(f"特徵3: {0 if df3 is None else len(df3)}")
            df4 = get_SQL_raw_data2(query=query9); print(f"特徵4: {0 if df4 is None else len(df4)}")
            df5 = get_SQL_raw_data2(query=query10); print(f"特徵5: {0 if df5 is None else len(df5)}")
 
        else:
            df1 = get_SQL_raw_data2(query=query1); print(f"特徵1: {0 if df1 is None else len(df1)}")
            df2 = get_SQL_raw_data2(query=query2); print(f"特徵2: {0 if df2 is None else len(df2)}")
            df3 = get_SQL_raw_data2(query=query3); print(f"特徵3: {0 if df3 is None else len(df3)}")
            df4 = get_SQL_raw_data2(query=query4); print(f"特徵4: {0 if df4 is None else len(df4)}")
            df5 = get_SQL_raw_data2(query=query5); print(f"特徵5: {0 if df5 is None else len(df5)}")
        
        dfs = [df1, df2, df3, df4, df5]
        if any(d is None or len(d)==0 for d in dfs):
            print("有特徵表未撈到資料")
            return None

######################################################################################################
        
        # === 各表個別降型/類別處理（df4/df5 用你指定的類別欄位清單） ===
        df1 = postprocess(df1)
        df2 = postprocess(df2)
        df3 = postprocess(df3)
        df4 = postprocess(df4, category_cols=colname_catgory_list_202503_1)
        df5 = postprocess(df5, category_cols=colname_catgory_list_202503_2)
#########################################################################################################    
        # === 排除不要的特徵（每表自己先 drop，避免最後大表才 drop 的複製成本） ===
        if drop_key_word:
            for drop_kw in drop_key_word:
                for d in (df1, df2, df3, df4, df5):
                    to_drop = [a for a in d.columns if drop_kw in a]
                    if to_drop:
                        d.drop(columns=to_drop, inplace=True, errors='ignore')

        # === 用 MultiIndex 對齊後做連續 join（取代排序+reset+concat） ===
        # df1 保留 key 欄位；其他表在設好 index 後，先把 key 欄位去掉避免重複
        df1 = df1.set_index(['customer_id','yyyymm'], drop=False)

        def set_idx_and_drop_keys(d):
            d = d.set_index(['customer_id','yyyymm'], drop=False)
            d = d.drop(columns=['customer_id','yyyymm'], errors='ignore')
            return d

        df2 = set_idx_and_drop_keys(df2)
        df3 = set_idx_and_drop_keys(df3)
        df4 = set_idx_and_drop_keys(df4)
        df5 = set_idx_and_drop_keys(df5)

        # 連續 join（how='left' 保留 df1 母集合；不排序、不 reset、不額外 copy）
        merge_df = df1.join(df2, how='left')\
                      .join(df3, how='left')\
                      .join(df4, how='left')\
                      .join(df5, how='left')       
        if Fill_zero:
            feature_list = list(merge_df.select_dtypes(exclude = ['category','object']))
            merge_df[feature_list] = merge_df[feature_list].fillna(0)
        return merge_df
    except Exception as e:
        print(f"查詢失敗:-{e}")
        return None


# %%
def build_sampled_feature(ym,this_prod,mother,drop_key_word,Fill_zero, papu_and_y = pd.DataFrame()):
    merge_df = None
    try:
        if len(papu_and_y)>0:
            df = read_feature_by_all(ym,this_prod,mother,drop_key_word,Fill_zero)
# #             print(type(df))
# #             print(type(papu_and_y))
#             df = df[df['customer_id'].isin(papu_and_y['customer_id'])]
#             df.sort_values(["customer_id","yyyymm"], inplace=True)
#             df = df.reset_index(drop = True)
        else:
            df = read_feature_by_sampling(ym,this_prod,mother,drop_key_word,Fill_zero)

        print(f"目前資料數:{len(df)}-{len(df.columns)}")
            
        return df
    except Exception as e:
        print(f"誰的問題:-{e}")
        return None


# %%


def get_feature_by_SOP_202503(do_ym_lst, mother = None, drop_key_word = [], papu_and_y = pd.DataFrame(),
                       this_prod = None, just_for_check= False, Fill_zero=False):
    st_time = time.time()
    
    file_path = write_monthly_path + '/' + mother + '_' + this_prod + '.pickle'

    if os.path.exists(file_path):
        with open(file_path, "rb") as f:
            df_combined = pickle.load(f)
            print(f"資料筆數：{len(df_combined)}")
    else:
        concat_df_outcome = {}  
        if os.path.exists(table_fin_table_path):
            fin = pd.read_csv(table_fin_table_path)
            fin['ym'] = fin['ym'].astype('int')
            fin = fin.rename({'ym': 'yyyymm'}, axis=1)
        
        for ym in do_ym_lst:
            # os.makedirs(write_monthly_path, exist_ok=True)
            # out_path = os.path.join(write_monthly_path, f"{ym}.parquet")
            # if skip_existing and os.path.exists(out_path):
            #     print(f"[SKIP] {ym} 已存在：{out_path}；跳過當月處理")
            #     # 記錄路徑，讓後續讀取／合併仍可用
            #     concat_df_outcome[f"{ym}_path"] = out_path
            #     # 若需要狀態旗標也留著（可選）
            #     concat_df_outcome[f"{ym}_status"] = True
            #     continue
            
        #抓取母體跟Y
            if papu_and_y.empty and not just_for_check:
                raise ValueError("papu_and_y筆數為0")
    
            papu_and_y_yyyymm = papu_and_y[papu_and_y['yyyymm'] == ym]
            if papu_and_y_yyyymm.empty:
                raise ValueError(f"年月:{ym} 筆數為0")
    
            print(f"年月:{ym} 筆數為{len(papu_and_y_yyyymm)}")
    #         print(f"母體空值:{papu_and_y_yyyymm['yyyymm'].isnull().sum()}")
            
        #逐月撈取特徵
            st_time1 = time.time()
            print(' @@@@@@@@@@@@@@@@ Year of {} combine info @@@@@@@@@@@@@@@@ '.format(ym))
            if ym in sorted(do_ym_lst)[0:-1]:
                feature_sample = build_sampled_feature(ym,this_prod,mother,drop_key_word,Fill_zero)
            else:
                feature_sample = build_sampled_feature(ym,this_prod,mother,drop_key_word,Fill_zero,papu_and_y_yyyymm)
    
            end_time1 = time.time()
            print('全撈取特徵,  runtime: {} minutes'.format(round((end_time1-st_time1)/60),2))
    ######################################################################################################################        
            st_time2 = time.time()
            print(f"母體降維合併")
            # --- 1) 在進行 merge 前，保證鍵只在 columns ---
            # 如果前面曾 set_index(..., drop=False)，這裡先還原避免同名衝突
    
            feature_sample = feature_sample.reset_index(drop=True)
            papu_and_y_yyyymm = papu_and_y_yyyymm.reset_index(drop=True)
            
            # （可選）型別一致化，避免隱性型別不同造成對齊失敗
            feature_sample['yyyymm'] = pd.to_numeric(feature_sample['yyyymm'], downcast='integer')
            papu_and_y_yyyymm['yyyymm'] = pd.to_numeric(papu_and_y_yyyymm['yyyymm'], downcast='integer')
            
            # --- 2) 以 keys_df 做 semi-join：只保留在 feature_sample 的鍵 ---
            keys_df = feature_sample[['customer_id','yyyymm']].drop_duplicates()
            
            papu_and_y_yyyymm = papu_and_y_yyyymm.merge(
                keys_df, on=['customer_id','yyyymm'], how='inner', sort=False
            )
            
            
            # --- 3) 左右合併：此時改用 MultiIndex（鍵只在 index） ---
            feature_sample = feature_sample.set_index(['customer_id','yyyymm'], drop=False)
            papu_and_y_yyyymm = (
                papu_and_y_yyyymm
                    .set_index(['customer_id','yyyymm'], drop=False)
                    .drop(columns=['customer_id','yyyymm'], errors='ignore')  # 移除重複 columns
            )
    
    
            concat_df = feature_sample.join(papu_and_y_yyyymm, how='left')
            end_time2 = time.time()
                
            print('check5')
            concat_df = concat_df.reset_index(drop=True)
            fin = fin.reset_index(drop=True)
    
            concat_df['yyyymm'] = pd.to_numeric(concat_df['yyyymm'], downcast='integer')
            fin['yyyymm'] = pd.to_numeric(fin['yyyymm'], downcast='integer')
            # 合併金融指標（外部已讀入且降型）
            if fin is not None:
                concat_df = concat_df.merge(fin, on='yyyymm', how='left', sort=False, copy=False)
    
            mask1 = len(concat_df)==len(feature_sample)
            mask2 = len(concat_df) >= 1000
            status = ( mask1 and mask2)
            concat_df_outcome[str(ym)+'_status'] = status         
            concat_df_outcome[str(ym)+'_df'] = concat_df
            end_time2 = time.time()  
            print('全合併特徵,  runtime: {} minutes'.format(round((end_time2-st_time2)/60),2))
            
            # concat_df_outcome = write_one_month_parquet(concat_df_outcome, ym, write_monthly_path)
            del feature_sample, papu_and_y_yyyymm, keys_df
            gc.collect()
        print('check5')   
        st_time3 = time.time()
        df_combined = combine_multi_year_df(do_ym_lst, concat_df_outcome)
        end_time3 = time.time()  
        print('月份合併,  runtime: {} minutes'.format(round((end_time3-st_time3)/60),2))
    
        file_path = write_monthly_path + '/' + mother + '_' + this_prod + '.pickle'
        pickle.dump(df_combined, open(file_path, 'wb'), protocol = 5)
    # df_combined = read_parquet_with_dataset(
    #     dataset_dir=write_monthly_path,
    #     filter_expr=None,          # 若要只讀某月/條件，可換成 Arrow filter
    #     columns=None,              # 全欄位
    #     batch_size=500_000,        # 批次可略放大，減少 concat 次數（視記憶體再調）
    #     cast_uint_to_int64=False,  # 寫入端已移除 UInt*，這裡就不再強制 cast
    #     categorical=True,          # Arrow dictionary → pandas Categorical，保留語義
    #     use_threads=True,          # 啟用多執行緒加速
    #     preserve_nullable=True     # 保留 pandas nullable dtypes（Int*、Float32）
    # )


    
    end_time = time.time()
    print('get_feature_by_SOP,  runtime: {} minutes'.format(round((end_time-st_time)/60),2))
    return df_combined


# %%


# def check_undo_feature(do_concat_ym_lst, feature_file_path):
#     outcome = {}
#     for ym in do_concat_ym_lst:
#         #參數與宣告
#         check_path = feature_file_path + '/' + '{}'.format(ym)
#         exist_list = listdir(check_path)
#         notexist_list = []
#         undo_list = []
#         print('-----Check [undo_feature] info------')
#         print('年月: {} '.format(ym))
#         print('未執行清單:')
        
#         #抓出不存在TABLE
#         for table in table_append_list_2024:
#             check_file_name = table + '_{}.pickle'.format(ym)
#             if check_file_name not in exist_list :
#                 notexist_list.append(table)
#         ############################

#         #判斷是否有特殊情況
#         for not_exist_table in notexist_list:
#             if not_exist_table not in ['TRANS_CATE3','TRANS_CATE31','TRANS_CATE32','SAFETY_STOCK', 'SAFETY_STOCK_1', 'SAFETY_STOCK_2']:
#                 print(not_exist_table); undo_list.append(not_exist_table)
                
#             elif not_exist_table == 'TRANS_CATE3' and 'TRANS_CATE31' in notexist_list and 'TRANS_CATE32' in notexist_list:
#                 print(not_exist_table); undo_list.append(not_exist_table)
                
#             elif (not_exist_table == 'TRANS_CATE31' or not_exist_table == 'TRANS_CATE32')  and 'TRANS_CATE3' in notexist_list:
#                 print(not_exist_table); undo_list.append(not_exist_table)
                
#             elif not_exist_table == 'SAFETY_STOCK' and 'SAFETY_STOCK_1' in notexist_list and 'SAFETY_STOCK_2' in notexist_list:
#                 print(not_exist_table); undo_list.append(not_exist_table)
                
#             elif (not_exist_table == 'SAFETY_STOCK_1' or not_exist_table == 'SAFETY_STOCK_2')  and 'SAFETY_STOCK' in notexist_list:
#                 print(not_exist_table); undo_list.append(not_exist_table)
#         ############################
        
#         #存入確認結果
#         status = (undo_list==[])
#         outcome[str(ym)+'_status'] = status
#         outcome[str(ym)+'_undo_list'] = undo_list
#         if status : print('year: {} feature is no problem!!!!!!!!!'.format(ym))
#     return outcome


# %%


# def check_undo_feature_2024test(do_concat_ym_lst, feature_file_path):
#     outcome = {}
#     for ym in do_concat_ym_lst:
#         #參數與宣告
#         check_path = feature_file_path + '/' + '{}'.format(ym)
#         exist_list = listdir(check_path)
#         notexist_list = []
#         undo_list = []
#         print('-----Check [undo_feature] info------')
#         print('年月: {} '.format(ym))
#         print('未執行清單:')
        
#         #抓出不存在TABLE
#         for table in table_check_list:
#             check_file_name = table + '_{}.pickle'.format(ym)
#             if check_file_name not in exist_list :
#                 notexist_list.append(table)
#         ############################

#         #判斷是否有特殊情況
#         for not_exist_table in notexist_list:
#             if not_exist_table not in ['TRANS_CATE3','TRANS_CATE31','TRANS_CATE32','SAFETY_STOCK', 'SAFETY_STOCK_1', 'SAFETY_STOCK_2']:
#                 print(not_exist_table); undo_list.append(not_exist_table)
                
#             elif not_exist_table == 'TRANS_CATE3' and 'TRANS_CATE31' in notexist_list and 'TRANS_CATE32' in notexist_list:
#                 print(not_exist_table); undo_list.append(not_exist_table)
                
#             elif (not_exist_table == 'TRANS_CATE31' or not_exist_table == 'TRANS_CATE32')  and 'TRANS_CATE3' in notexist_list:
#                 print(not_exist_table); undo_list.append(not_exist_table)
                
#             elif not_exist_table == 'SAFETY_STOCK' and 'SAFETY_STOCK_1' in notexist_list and 'SAFETY_STOCK_2' in notexist_list:
#                 print(not_exist_table); undo_list.append(not_exist_table)
                
#             elif (not_exist_table == 'SAFETY_STOCK_1' or not_exist_table == 'SAFETY_STOCK_2')  and 'SAFETY_STOCK' in notexist_list:
#                 print(not_exist_table); undo_list.append(not_exist_table)
#         ############################
        
#         #存入確認結果
#         status = (undo_list==[])
#         outcome[str(ym)+'_status'] = status
#         outcome[str(ym)+'_undo_list'] = undo_list
#         if status : print('year: {} feature is no problem!!!!!!!!!'.format(ym))
#     return outcome


# %%


# outcome = check_undo_feature(['202112'])


# %%


# def check_length_and_index(do_concat_ym_lst,feature_file_path , number_of_check=2000):
#     outcome = {}
#     for ym in do_concat_ym_lst:
#         #參數與宣告
#         len_error_table = []
#         idx_error_table = []
#         col_error_table = []
#         check_path = feature_file_path + '/' + '{}'.format(ym)
#         exist_list = listdir(check_path)
#         df = pickle.load(open(check_path + '/' + 'CUST_{}.pickle'.format(ym), 'rb'))
#         df_len = len(df)
#         check_index_list = [random.randint(0,df_len-1) for n in range(number_of_check)]
#         check_id_df = df['customer_id'][check_index_list]
#         print('-----Check [length and index] info------')
#         print('Year: {} Row Number: {}'.format(ym, df_len))
#         print('Check df:')
#         print(check_id_df)
        
#         for exist_file in exist_list:
#             if 'ipynb_checkpoints' not in exist_file and 'CUST' not in exist_file:
#                 df = pickle.load(open(check_path + '/' + exist_file, 'rb'))
#                 df_compare = pickle.load(open(
#                     feature_file_path + '/{}/'.format(compare_column_ym)
#                     + exist_file.split('.')[0][:-6] + '{}.pickle'.format(compare_column_ym), 'rb'))
#                 #確認資料筆數
#                 if len(df) != df_len: 
#                     print('table: {} length not match!!!!!!!!!!!'.format(exist_file))
#                     len_error_table.append(exist_file)
#                 #確認INDEX
#                 if sum(df['customer_id'][check_index_list] != check_id_df) == number_of_check: 
#                     print('table: {} ID not match!!!!!!!!!!!'.format(exist_file))
#                     idx_error_table.append(exist_file)
#                 #確認欄位長度是否一致
#                 if exist_file[:-14] not in table_not_fixed_column_list  and len(df.columns) != len(df_compare.columns): 
#                     print('table: {} Columns size not match!!!!!!!!!!!'.format(exist_file))
#                     col_error_table.append(exist_file)
#         #存入確認結果
#         status = (len_error_table==[] and idx_error_table==[] and col_error_table==[])
#         outcome[str(ym)+'_status'] = status
#         outcome[str(ym)+'_len_error_table'] = len_error_table
#         outcome[str(ym)+'_idx_error_table'] = idx_error_table
#         if status: print('year: {} length and index are no problem!!!!!!!!!!'.format(ym))
#     return outcome


# %%


# number_of_check=100
# check_length_and_index(do_concat_ym_lst, number_of_check)


# %%


# def concat_all_feature_df(do_concat_ym_lst, mother,feature_file_path , outcome = {}, writing_path = None,
#                           drop_key_word = [], papu_and_y = pd.DataFrame(), just_for_check=False, Fill_zero=False,
#                           if_old = False):
#     def rename_dup_col(df):
#         if sum(df.columns.duplicated(keep='first')) > 0 :
#             dup_col_first = [i+'_x' for i in list(df.columns.values[df.columns.duplicated(keep='first')])]
#             dup_col_last = [i+'_y' for i in list(df.columns.values[df.columns.duplicated(keep='last')])]
#             dup_first_index = df.columns.duplicated(keep='first')
#             dup_last_index = df.columns.duplicated(keep='last')
#             df.columns.values[dup_first_index] = dup_col_first
#             df.columns.values[dup_last_index] = dup_col_last
#         return df
    
#     for ym in do_concat_ym_lst:
#         st_each_year_time = time.time()
#         print('-----Concat datafram info------')
#         #參數與宣告
#         check_path = feature_file_path + '/' + '{}'.format(ym)
#         exist_list = listdir(check_path)
#         #先抓客戶檔
#         df = pickle.load(open(check_path + '/' + 'CUST_{}.pickle'.format(ym), 'rb'))
#         df['yyyymm'] = df['yyyymm'].astype('int')
#         print('CUST_{}.pickle loading finished'.format(ym))    
#         #抓取母體跟Y
#         if (not papu_and_y.empty) :         
# #         if (not papu_and_y[papu_and_y['yyyymm']==int(ym)].empty) : 
#             papu_and_y['yyyymm'] = papu_and_y['yyyymm'].astype('int')
#             papu_and_y_yyyymm = papu_and_y[papu_and_y['yyyymm']==int(ym)]
#             if not papu_and_y_yyyymm.empty:  
#                 df_papu_and_y = pd.merge(df, papu_and_y_yyyymm, how='left', on=['customer_id','yyyymm']) 
#                 df_papu_and_y.drop(['customer_id','yyyymm'], axis=1, inplace=True)
#                 mask_papulation = df_papu_and_y['y'].notna()
#                 df_papu_and_y = df_papu_and_y[mask_papulation]
#                 df_papu_and_y['y'] = df_papu_and_y['y'].astype('int')
#                 print('papu_and_y loading finished with {} columns and {} length '.format(len(df_papu_and_y.columns), len(df_papu_and_y)))
#             else: 
#                 raise ValueError(f"年月:{ym} 筆數為0")
#         elif just_for_check:
#             print('允許空的dataframe用於check特徵完成情形!')
#         else: 
#             raise ValueError(f"papu_and_y筆數為0")
            
#         if os.path.exists(table_fin_table_path):
#             fin = pd.read_csv(table_fin_table_path)
#             fin['ym'] = fin['ym'].astype('int')
#             fin = fin.rename({'ym': 'yyyymm'}, axis=1)
#             df_fin = pd.merge(df, fin, how='left', on=['yyyymm']) 
#             if (not papu_and_y.empty) : 
#                     #透過母體調整DF
#                     df_fin = df_fin[mask_papulation]
#                     df = df[mask_papulation]
#             df_fin.drop(['customer_id','yyyymm'], axis=1, inplace=True)
#             print('df_fin loading finished with {} columns and {} length '.format(len(df_fin.columns), len(df_fin))) 
            
#         df_length = len(df) # for check length
#         #放入需合併DF
#         if (not papu_and_y.empty) : 
#             combine_table_list = [df, df_papu_and_y,df_fin]
#         else:
#             combine_table_list = [df,df_fin]
#         if if_old:
#             table_all_list = table_orginal_list + table_append_list
#         else:
#             table_all_list = table_append_list_2024
#         for table in table_all_list:
#             filename = table + '_{}.pickle'.format(ym)
#             if table != 'CUST' and filename in exist_list:
#                 df_temp = pickle.load(open(check_path + '/' + filename, 'rb'))
#                 if (not papu_and_y.empty) : 
#                     df_temp = df_temp[mask_papulation]
#                 #排除不要的特徵
#                 for drop_kw in drop_key_word:
#                     df_temp.drop([a for a in df_temp.columns if (drop_kw in a)], axis=1, inplace=True)
#                 #拿掉customer_id還有yyyymmm
#                 df_temp.drop(['customer_id'], axis=1, inplace=True)
#                 if 'yyyymm' in df_temp.columns: df_temp.drop(['yyyymm'], axis=1, inplace=True)
#                 print('{}_{}.pickle loading finished with {} columns and {} length '.format(table, ym, len(df_temp.columns), len(df_temp)))  
                
#                 # NA補0
#                 if Fill_zero:
#                     feature_list = list(df_temp.select_dtypes(exclude = ['category','object']))
#                     na_totally_num = sum(df_temp[feature_list].isna().sum(axis=1))
#                     print(f'補0前NA數量:{na_totally_num}')                    
#                     df_temp[feature_list] = df_temp[feature_list].fillna(0)
#                     print('NA補0完畢!!!')
#                     na_totally_num = sum(df_temp[feature_list].isna().sum(axis=1))
#                     print(f'補0後NA數量:{na_totally_num}')
                    
#                 var_name = 'df'+ table
#                 locals()[var_name] =  df_temp 
#                 combine_table_list.append(locals()[var_name])
#         #合併TABLE
#         df_combined = pd.concat(combine_table_list, axis= 1, join='outer')
#         mask1 = len(df_combined)==df_length
#         mask2 = len(df_combined) >= 1000
#         print('{}_{}.pickle concat finished , now is {} columns '.format(table, ym, len(df_combined.columns)))   
#         print('Concat df of {}, runtime: {} minutes'.format(ym, (time.time()-st_each_year_time)/60))
#         #存入確認結果
#         status = ( mask1 and mask2)
#         outcome[str(ym)+'_status'] = status    
#         df_combined = rename_dup_col(df_combined)
#         outcome[str(ym)+'_df'] = df_combined
#         if writing_path != None:
#             st_dumping_time = time.time()
#             table_filename = 'concat_feature_{}.pickle'.format(ym)
#             col_filename = 'colname_{}.pickle'.format(ym)
#             writing_path_fold = writing_path +'/'+ mother
            
#             if not os.path.exists(writing_path_fold):
#                 os.makedirs(writing_path_fold) 
                
#             pickle.dump(df_combined, open(writing_path_fold +'/' +table_filename, 'wb'), protocol = 4)
#             pickle.dump(df_combined.columns, open(writing_path_fold +'/' + col_filename, 'wb'), protocol = 4) 
#             print('all_fature{} dumping finished!!!!!!!!!!!!!!'.format(ym))      
#             print('dumping df of {}, runtime: {} minutes'.format(ym, (time.time()-st_dumping_time)/60))
  
#     return outcome       


# %%


# def concat_all_feature_df_2024test(do_concat_ym_lst, mother,feature_file_path , outcome = {}, writing_path = None,
#                           drop_key_word = [], papu_and_y = pd.DataFrame(), just_for_check=False, Fill_zero=False):
#     def rename_dup_col(df):
#         if sum(df.columns.duplicated(keep='first')) > 0 :
#             dup_col_first = [i+'_x' for i in list(df.columns.values[df.columns.duplicated(keep='first')])]
#             dup_col_last = [i+'_y' for i in list(df.columns.values[df.columns.duplicated(keep='last')])]
#             dup_first_index = df.columns.duplicated(keep='first')
#             dup_last_index = df.columns.duplicated(keep='last')
#             df.columns.values[dup_first_index] = dup_col_first
#             df.columns.values[dup_last_index] = dup_col_last
#         return df
    
#     for ym in do_concat_ym_lst:
#         st_each_year_time = time.time()
#         print('-----Concat datafram info------')
#         #參數與宣告
#         check_path = feature_file_path + '/' + '{}'.format(ym)
#         exist_list = listdir(check_path)
#         #先抓客戶檔
#         df = pickle.load(open(check_path + '/' + 'CUST_{}.pickle'.format(ym), 'rb'))
#         df['yyyymm'] = df['yyyymm'].astype('int')
#         print('CUST_{}.pickle loading finished'.format(ym))    
#         #抓取母體跟Y
#         if (not papu_and_y.empty) :         
# #         if (not papu_and_y[papu_and_y['yyyymm']==int(ym)].empty) : 
#             papu_and_y['yyyymm'] = papu_and_y['yyyymm'].astype('int')
#             papu_and_y_yyyymm = papu_and_y[papu_and_y['yyyymm']==int(ym)]
#             if not papu_and_y_yyyymm.empty:  
#                 df_papu_and_y = pd.merge(df, papu_and_y_yyyymm, how='left', on=['customer_id','yyyymm']) 
#                 df_papu_and_y.drop(['customer_id','yyyymm'], axis=1, inplace=True)
#                 mask_papulation = df_papu_and_y['y'].notna()
#                 df_papu_and_y = df_papu_and_y[mask_papulation]
#                 df_papu_and_y['y'] = df_papu_and_y['y'].astype('int')
#                 print('papu_and_y loading finished with {} columns and {} length '.format(len(df_papu_and_y.columns), len(df_papu_and_y)))
#             else: 
#                 raise ValueError(f"年月:{ym} 筆數為0")
#         elif just_for_check:
#             print('允許空的dataframe用於check特徵完成情形!')
#         else: 
#             raise ValueError(f"papu_and_y筆數為0")
            
#         if os.path.exists(table_fin_table_path):
#             fin = pd.read_csv(table_fin_table_path)
#             fin['ym'] = fin['ym'].astype('int')
#             fin = fin.rename({'ym': 'yyyymm'}, axis=1)
#             df_fin = pd.merge(df, fin, how='left', on=['yyyymm']) 
#             if (not papu_and_y.empty) : 
#                     #透過母體調整DF
#                     df_fin = df_fin[mask_papulation]
#                     df = df[mask_papulation]
#             df_fin.drop(['customer_id','yyyymm'], axis=1, inplace=True)
#             print('df_fin loading finished with {} columns and {} length '.format(len(df_fin.columns), len(df_fin))) 
            
#         df_length = len(df) # for check length
#         #放入需合併DF
#         if (not papu_and_y.empty) : 
#             combine_table_list = [df, df_papu_and_y,df_fin]
#         else:
#             combine_table_list = [df,df_fin]
#         for table in table_check_list:
#             filename = table + '_{}.pickle'.format(ym)
#             if table != 'CUST' and filename in exist_list:
#                 df_temp = pickle.load(open(check_path + '/' + filename, 'rb'))
#                 if (not papu_and_y.empty) : 
#                     df_temp = df_temp[mask_papulation]
#                 #排除不要的特徵
#                 for drop_kw in drop_key_word:
#                     df_temp.drop([a for a in df_temp.columns if (drop_kw in a)], axis=1, inplace=True)
#                 #拿掉customer_id還有yyyymmm
#                 df_temp.drop(['customer_id'], axis=1, inplace=True)
#                 if 'yyyymm' in df_temp.columns: df_temp.drop(['yyyymm'], axis=1, inplace=True)
#                 print('{}_{}.pickle loading finished with {} columns and {} length '.format(table, ym, len(df_temp.columns), len(df_temp)))  
                
#                 # NA補0
#                 if Fill_zero:
#                     feature_list = list(df_temp.select_dtypes(exclude = ['category','object']))
#                     na_totally_num = sum(df_temp[feature_list].isna().sum(axis=1))
#                     print(f'補0前NA數量:{na_totally_num}')                    
#                     df_temp[feature_list] = df_temp[feature_list].fillna(0)
#                     print('NA補0完畢!!!')
#                     na_totally_num = sum(df_temp[feature_list].isna().sum(axis=1))
#                     print(f'補0後NA數量:{na_totally_num}')
                    
#                 var_name = 'df'+ table
#                 locals()[var_name] =  df_temp 
#                 combine_table_list.append(locals()[var_name])
#         #合併TABLE
#         df_combined = pd.concat(combine_table_list, axis= 1, join='outer')
#         mask1 = len(df_combined)==df_length
#         mask2 = len(df_combined) >= 1000
#         print('{}_{}.pickle concat finished , now is {} columns '.format(table, ym, len(df_combined.columns)))   
#         print('Concat df of {}, runtime: {} minutes'.format(ym, (time.time()-st_each_year_time)/60))
#         #存入確認結果
#         status = ( mask1 and mask2)
#         outcome[str(ym)+'_status'] = status    
#         df_combined = rename_dup_col(df_combined)
#         outcome[str(ym)+'_df'] = df_combined
#         if writing_path != None:
#             st_dumping_time = time.time()
#             table_filename = 'concat_feature_{}.pickle'.format(ym)
#             col_filename = 'colname_{}.pickle'.format(ym)
#             writing_path_fold = writing_path +'/'+ mother
            
#             if not os.path.exists(writing_path_fold):
#                 os.makedirs(writing_path_fold) 
                
#             pickle.dump(df_combined, open(writing_path_fold +'/' +table_filename, 'wb'), protocol = 4)
#             pickle.dump(df_combined.columns, open(writing_path_fold +'/' + col_filename, 'wb'), protocol = 4) 
#             print('all_fature{} dumping finished!!!!!!!!!!!!!!'.format(ym))      
#             print('dumping df of {}, runtime: {} minutes'.format(ym, (time.time()-st_dumping_time)/60))
  
#     return outcome       


# %%


# concat_all_feature_df(do_concat_ym_lst)


# %%


# def get_feature_by_SOP(do_ym_lst, mother = None, writing_path = None, drop_key_word = [], papu_and_y = pd.DataFrame(),
#                        feature_file_path = feature_file_path_mlops, just_for_check=False, Fill_zero=False, if_old = False):
#     st_time = time.time()
#     concat_df_outcome = {}
#     for ym in do_ym_lst:
        
#         writing_path_fold = str(writing_path) +'/'+ str(mother) 
#         table_filename = 'concat_feature_{}.pickle'.format(ym)
#         writing_path_file = writing_path_fold + '/' + table_filename
        
#         if writing_path != None and os.path.exists(writing_path_file):
#             print(' year of {} df had been existed!!!!!'.format(ym))
#             print(' @@@@@@@@@@@@@@@@ Year of {} load info @@@@@@@@@@@@@@@@ '.format(ym))
#             print(' year of {} df is loading....'.format(ym))
#             df = pickle.load(open(writing_path_file, 'rb'))
#             concat_df_outcome[str(ym)+'_df'] = df
#             print(' year of {} df was be finished '.format(ym))
#         else:
#             print(' @@@@@@@@@@@@@@@@ Year of {} combine info @@@@@@@@@@@@@@@@ '.format(ym))
#             ym_status = str(ym)+'_status'
#             check_undo_outcome = check_undo_feature([ym], feature_file_path)
#             print(check_undo_outcome)
#             if check_undo_outcome[ym_status] :
#                 check_index_outcome = check_length_and_index([ym], feature_file_path)
#                 if check_index_outcome[ym_status] :
#                     concat_df_outcome =                     concat_all_feature_df([ym], mother,feature_file_path, concat_df_outcome, writing_path, 
#                                           drop_key_word, papu_and_y, just_for_check, Fill_zero, if_old)
#                     if concat_df_outcome[ym_status] :
#                         print('Succssed !! df: featue_{} already concated'.format(ym))                    
#                     else:
#                         print('Concat failed, feature of {} !!'.format(ym) )
#                 else: print('Index or length had problem !! feature of {} !'.format(ym))
#             else: print('Some table is unfinished !! feature of {} !'.format(ym))
#     end_time = time.time()
#     print('get_feature_by_SOP,  runtime: {} minutes'.format(round((end_time-st_time)/60),2))
#     return concat_df_outcome


# %%


# def get_feature_by_SOP_2024test(do_ym_lst, mother = None, writing_path = None, drop_key_word = [], papu_and_y = pd.DataFrame(),
#                        feature_file_path = feature_file_path_mlops, just_for_check=False, Fill_zero=False):
#     st_time = time.time()
#     concat_df_outcome = {}
#     for ym in do_ym_lst:
        
#         writing_path_fold = str(writing_path) +'/'+ str(mother) 
#         table_filename = 'concat_feature_{}.pickle'.format(ym)
#         writing_path_file = writing_path_fold + '/' + table_filename
        
#         if writing_path != None and os.path.exists(writing_path_file):
#             print(' year of {} df had been existed!!!!!'.format(ym))
#             print(' @@@@@@@@@@@@@@@@ Year of {} load info @@@@@@@@@@@@@@@@ '.format(ym))
#             print(' year of {} df is loading....'.format(ym))
#             df = pickle.load(open(writing_path_file, 'rb'))
#             concat_df_outcome[str(ym)+'_df'] = df
#             print(' year of {} df was be finished '.format(ym))
#         else:
#             print(' @@@@@@@@@@@@@@@@ Year of {} combine info @@@@@@@@@@@@@@@@ '.format(ym))
#             ym_status = str(ym)+'_status'
#             check_undo_outcome = check_undo_feature([ym], feature_file_path)
#             print(check_undo_outcome)
#             if check_undo_outcome[ym_status] :
#                 check_index_outcome = check_length_and_index([ym], feature_file_path)
#                 if check_index_outcome[ym_status] :
#                     concat_df_outcome =                     concat_all_feature_df_2024test([ym], mother,feature_file_path, concat_df_outcome, writing_path, 
#                                           drop_key_word, papu_and_y, just_for_check, Fill_zero)
#                     if concat_df_outcome[ym_status] :
#                         print('Succssed !! df: featue_{} already concated'.format(ym))                    
#                     else:
#                         print('Concat failed, feature of {} !!'.format(ym) )
#                 else: print('Index or length had problem !! feature of {} !'.format(ym))
#             else: print('Some table is unfinished !! feature of {} !'.format(ym))
#     end_time = time.time()
#     print('get_feature_by_SOP,  runtime: {} minutes'.format(round((end_time-st_time)/60),2))
#     return concat_df_outcome


# %%


# def get_feature_by_SOP_jihsun(do_ym_lst, mother = None, writing_path = None, drop_key_word = [], papu_and_y = pd.DataFrame(),
#                               feature_file_path = feature_file_path_jihsun, just_for_check=False, Fill_zero=False, if_old = False ):
#     st_time = time.time()
#     concat_df_outcome = {}
#     for ym in do_ym_lst:
        
#         writing_path_fold = str(writing_path) +'/'+ str(mother) 
#         table_filename = 'concat_feature_{}.pickle'.format(ym)
#         writing_path_file = writing_path_fold + '/' + table_filename
        
#         if writing_path != None and os.path.exists(writing_path_file):
#             print(' year of {} df had been existed!!!!!'.format(ym))
#             print(' @@@@@@@@@@@@@@@@ Year of {} load info @@@@@@@@@@@@@@@@ '.format(ym))
#             print(' year of {} df is loading....'.format(ym))
#             df = pickle.load(open(writing_path_file, 'rb'))
#             concat_df_outcome[str(ym)+'_df'] = df
#             print(' year of {} df was be finished '.format(ym))
#         else:
#             print(' @@@@@@@@@@@@@@@@ Year of {} combine info @@@@@@@@@@@@@@@@ '.format(ym))
#             ym_status = str(ym)+'_status'
#             check_undo_outcome = check_undo_feature([ym], feature_file_path)
#             print(check_undo_outcome)
#             if check_undo_outcome[ym_status] :
#                 check_index_outcome = check_length_and_index([ym], feature_file_path)
#                 if check_index_outcome[ym_status] :
#                     concat_df_outcome =                     concat_all_feature_df([ym], mother,feature_file_path, concat_df_outcome, writing_path, 
#                                           drop_key_word, papu_and_y, just_for_check, Fill_zero, if_old)
#                     if concat_df_outcome[ym_status] :
#                         print('Succssed !! df: featue_{} already concated'.format(ym))                    
#                     else:
#                         print('Concat failed, feature of {} !!'.format(ym) )
#                 else: print('Index or length had problem !! feature of {} !'.format(ym))
#             else: print('Some table is unfinished !! feature of {} !'.format(ym))
#     end_time = time.time()
#     print('get_feature_by_SOP,  runtime: {} minutes'.format(round((end_time-st_time)/60),2))
#     return concat_df_outcome


# %%


# def get_feature_by_SOP_jihsun_2024test(do_ym_lst, mother = None, writing_path = None, drop_key_word = [], papu_and_y = pd.DataFrame(),
#                               feature_file_path = feature_file_path_jihsun, just_for_check=False, Fill_zero=False ):
#     st_time = time.time()
#     concat_df_outcome = {}
#     for ym in do_ym_lst:
        
#         writing_path_fold = str(writing_path) +'/'+ str(mother) 
#         table_filename = 'concat_feature_{}.pickle'.format(ym)
#         writing_path_file = writing_path_fold + '/' + table_filename
        
#         if writing_path != None and os.path.exists(writing_path_file):
#             print(' year of {} df had been existed!!!!!'.format(ym))
#             print(' @@@@@@@@@@@@@@@@ Year of {} load info @@@@@@@@@@@@@@@@ '.format(ym))
#             print(' year of {} df is loading....'.format(ym))
#             df = pickle.load(open(writing_path_file, 'rb'))
#             concat_df_outcome[str(ym)+'_df'] = df
#             print(' year of {} df was be finished '.format(ym))
#         else:
#             print(' @@@@@@@@@@@@@@@@ Year of {} combine info @@@@@@@@@@@@@@@@ '.format(ym))
#             ym_status = str(ym)+'_status'
#             check_undo_outcome = check_undo_feature([ym], feature_file_path)
#             print(check_undo_outcome)
#             if check_undo_outcome[ym_status] :
#                 check_index_outcome = check_length_and_index([ym], feature_file_path)
#                 if check_index_outcome[ym_status] :
#                     concat_df_outcome =                     concat_all_feature_df_2024test([ym], mother,feature_file_path, concat_df_outcome, writing_path, 
#                                           drop_key_word, papu_and_y, just_for_check, Fill_zero)
#                     if concat_df_outcome[ym_status] :
#                         print('Succssed !! df: featue_{} already concated'.format(ym))                    
#                     else:
#                         print('Concat failed, feature of {} !!'.format(ym) )
#                 else: print('Index or length had problem !! feature of {} !'.format(ym))
#             else: print('Some table is unfinished !! feature of {} !'.format(ym))
#     end_time = time.time()
#     print('get_feature_by_SOP,  runtime: {} minutes'.format(round((end_time-st_time)/60),2))
#     return concat_df_outcome


# %%


def if_to_large_down_sampling(do_ym_lst, concat_df_outcome, limit_size=500000):
    st_time = time.time()
    for ym in sorted(do_ym_lst)[0:-1] :
        df = concat_df_outcome[str(ym)+'_df']
        if len(df) > limit_size:
            print(f'starting down sampling (year:{ym}) ...')
            df_y0 = df[df['y']==0]
            df_y1 = df[df['y']==1]
            df_y0_downsampled = resample(df_y0, random_state=42, n_samples=limit_size-len(df_y1), replace=True)
            #concat
            df_downsampled = pd.concat([df_y0_downsampled, df_y1])
            print(f'Successed!! down sampling (year:{ym})/ size:{len(df_downsampled)}) ...')
            concat_df_outcome[str(ym)+'_df'] = df_downsampled
        else:
            print(f'don"t need down sampling (year:{ym}/ size:{len(df)}) ...')
    end_time = time.time()
    print('if_to_large_down_sampling,  runtime: {} minutes'.format(round((end_time-st_time)/60),2))
    return concat_df_outcome


def downsample_by_month(
    df_combined: pd.DataFrame,
    limit_size_per_month: int = 500_000,
    y_col: str = 'y',
    month_col: str = 'yyyymm',
    random_state: int = 42,
    replace: bool = False  # 一般不建議重複抽樣，若正樣本太少可設 True
) -> pd.DataFrame:
    """
    在完整大表上，依月份分組做類別平衡降採樣：
    - 每月保留所有 y=1（正樣本），從 y=0 抽樣到 (limit_size - y=1 的數量)。
    - 若 y=1 > limit_size，則改成「每類都抽到 limit_size/2」，保證平衡。
    - 輸出：各月降採樣後的合併大表（不保證原順序）。
    """
    st_time = time.time()

    if month_col not in df_combined.columns or y_col not in df_combined.columns:
        raise ValueError(f"缺少必要欄位：{month_col} 或 {y_col}")

    # 分組逐月處理
    out_parts = []
    months = df_combined[month_col].unique()
    months = np.sort(months)  # 若你需要按月份順序

    for ym in months:
        df_m = df_combined[df_combined[month_col] == ym]
        n_m = len(df_m)
        if n_m <= limit_size_per_month:
            # 不需降採樣
            print(f'don\'t need down sampling (year:{ym}/ size:{n_m}) ...')
            out_parts.append(df_m)
            continue

        print(f'starting down sampling (year:{ym}) ... size={n_m}')
        # 分類
        df_y1 = df_m[df_m[y_col] == 1]
        df_y0 = df_m[df_m[y_col] == 0]

        n1 = len(df_y1)
        n0 = len(df_y0)

        if n1 == 0:
            # 沒有正樣本，直接隨機抽到 limit_size
            df_m_down = df_m.sample(n=limit_size_per_month, random_state=random_state, replace=replace)
            print(f'No positive class, sampled total={len(df_m_down)} for {ym}')
            out_parts.append(df_m_down)
            continue

        if n1 >= limit_size_per_month:
            # 正樣本已超過上限，等量抽樣各類到 limit/2
            half = limit_size_per_month // 2
            df_y1_sampled = df_y1.sample(n=half, random_state=random_state, replace=False)
            df_y0_sampled = df_y0.sample(n=limit_size_per_month - half, random_state=random_state, replace=replace)
            df_m_down = pd.concat([df_y1_sampled, df_y0_sampled], axis=0, ignore_index=True)
            print(f'Positive >= limit, sampled y=1:{len(df_y1_sampled)}, y=0:{len(df_y0_sampled)} for {ym}')
        else:
            # 正樣本全部保留，負樣本抽至剩餘
            need0 = limit_size_per_month - n1
            # 若負樣本不足，且 replace=False，則取全部負樣本
            if need0 > n0 and not replace:
                df_y0_sampled = df_y0  # 全收
                total = n1 + n0
                print(f'Not enough negatives (need {need0}, have {n0}), keep all; total={total} for {ym}')
            else:
                df_y0_sampled = df_y0.sample(n=min(need0, n0), random_state=random_state, replace=replace)
                total = n1 + len(df_y0_sampled)
            df_m_down = pd.concat([df_y1, df_y0_sampled], axis=0, ignore_index=True)
            print(f'Successed!! down sampling (year:{ym}) size:{len(df_m_down)}')

        out_parts.append(df_m_down)

    df_out = pd.concat(out_parts, axis=0, ignore_index=True, sort=False, copy=False)
    print('downsample_by_month,  runtime: {} minutes'.format(round((time.time() - st_time) / 60, 2)))
    return df_out


# %%


# def if_large_down_sampling_from_papu_and_y(do_ym_lst, papu_and_y, cust_source, limit_size=500000):
#     st_time = time.time()
#     papu_and_y['yyyymm'] = papu_and_y['yyyymm'].astype('int')
#     reduce_papu_and_y = papu_and_y[papu_and_y['yyyymm']==int(sorted(do_ym_lst)[-1])]
    
#     if cust_source == 'Fubon':
#         feature_file_path = config.feature_file_path_mlops
#     elif cust_source == 'Jihsun':
#         feature_file_path = config.feature_file_path_jihsun
        
#     for ym in sorted(do_ym_lst)[0:-1] :
#         print(f'-----Mapping CUST_{ym} info------')
#         #參數與宣告
#         check_path = feature_file_path + '/' + '{}'.format(ym)
#         print(f'PATH: {check_path}')
#         exist_list = listdir(check_path)
#         #先抓客戶檔
#         df = pickle.load(open(check_path + '/' + 'CUST_{}.pickle'.format(ym), 'rb'))
#         df['yyyymm'] = df['yyyymm'].astype('int')
#         print('CUST_{}.pickle loading finished'.format(ym)) 
        
#         if (not papu_and_y[papu_and_y['yyyymm']==int(ym)].empty) : 
#             # 抓取該yyyymm資料
#             papu_and_y_yyyymm = papu_and_y[papu_and_y['yyyymm']==int(ym)]
            
#             df_papu_and_y = pd.merge(df, papu_and_y_yyyymm, how='left', on=['customer_id','yyyymm']) 
#             mask_papulation = df_papu_and_y['y'].notna()
#             papu_and_y_yyyymm = df_papu_and_y[mask_papulation]
#             papu_and_y_yyyymm['y'] = papu_and_y_yyyymm['y'].astype('int')
#             papu_and_y_yyyymm.reset_index(drop=True, inplace=True)
#             print('papu_and_y mapping finished with {} columns and {} length '.format(len(papu_and_y_yyyymm.columns), len(papu_and_y_yyyymm)))

#             if len(papu_and_y_yyyymm) > limit_size:
#                 print(f'starting down sampling (year:{ym}) ...')
#                 papu_and_y_yyyymm_y0 = papu_and_y_yyyymm[papu_and_y_yyyymm['y']==0]
#                 papu_and_y_yyyymm_y1 = papu_and_y_yyyymm[papu_and_y_yyyymm['y']==1]
#                 papu_and_y_yyyymm_y0_downsampled = resample(papu_and_y_yyyymm_y0, random_state=42, n_samples=limit_size-len(papu_and_y_yyyymm_y1), replace=False)
#                 #concat
#                 papu_and_y_yyyymm_downsampled = pd.concat([papu_and_y_yyyymm_y0_downsampled, papu_and_y_yyyymm_y1])
#                 print(f'Successed!! down sampling (year:{ym})/ size:{len(papu_and_y_yyyymm_downsampled)}) ...')
#                 print(papu_and_y_yyyymm_downsampled)
#                 reduce_papu_and_y = reduce_papu_and_y.append(papu_and_y_yyyymm_downsampled)
#             else:
#                 print(f'don"t need down sampling (year:{ym}/ size:{len(papu_and_y_yyyymm)}) ...')
#                 reduce_papu_and_y = reduce_papu_and_y.append(papu_and_y_yyyymm)
#         else: 
#             raise ValueError(f"年月:{ym} 筆數為0")
#     #最新月份
#     reduce_papu_and_y.reset_index(drop=True,inplace=True)
#     print("Running time : %.0f sec" %(time.time() - st_time))
    
#     return reduce_papu_and_y


# %%


#固定母體 如果已經抓過了 就不送 query
def get_papu_and_y(do_ym_list, query_function, papulation_colname, papulation_train_value,
                   writing_popu_path,mother,
                   account1=config.account_yt , pwd1=config.pwd_yt,
                   account2=config.account_yichieh, pwd2=config.pwd_yichieh, failed_limit_times = 4,
                   y_type_name = ''):
    from Module.Model import monthdelta
    from Module.Sql_module import get_SQL_raw_data
    from datetime import date, timedelta , datetime    
    papu_and_y = pd.DataFrame()
    chage_acct = True
    failed_times = 0
    for ym in do_ym_list: 
        date =  datetime.date(datetime.strptime(ym,'%Y%m'))
        next_month = monthdelta(date, 1)
        print(next_month)    

        writing_path_fold = str(writing_popu_path) +'/'+ str(mother) 
        if writing_popu_path != None and not os.path.exists(writing_path_fold):
            os.makedirs(writing_path_fold) 
        table_filename = 'papu_and_y' + str(y_type_name) + '_{}.pickle'.format(ym)
        writing_path_file = writing_path_fold + '/' + table_filename
        if writing_popu_path != None and os.path.exists(writing_path_file):
            print(' year of {} papu_and_y had been existed!!!!!'.format(ym))

            df_temp = pickle.load(open(writing_path_file, 'rb'))
            # 抓target y的欄位名稱
            for i, col in enumerate(df_temp.columns):
                if 'y' in col and 'yyyy' not in col:
                    y_colname = col
            size = len(df_temp)
            y_number = sum(df_temp[y_colname]==1)
            
            print(f'yyyymm: {ym} propotion: {y_number/size}')
            print(f'size of df {size} and number of y is {y_number}')

            print(' year of {} papu_and_y loading finished '.format(ym))            
        else:
            # 判斷query_function是回傳
            if y_type_name == '':
                query = query_function(next_month)
            elif y_type_name == '2':
                query = query_function(next_month, int(y_type_name))
            if type(query) == str: 
                print('該Query function是傳回SQL語法')
                if chage_acct:
                    df_temp = get_SQL_raw_data(query, account1, pwd1)
                    time.sleep(10)
                else:
                    df_temp = get_SQL_raw_data(query, account2, pwd2)
                    time.sleep(10)
                chage_acct = not chage_acct
                time.sleep(10)
            elif isinstance(query,pd.DataFrame):
                print('該Query function是傳回DataFrame')
                df_temp = query
                
            if isinstance(df_temp,pd.DataFrame) and len(df_temp) > 0:
                print(f'此月份筆數為: {len(df_temp)}')
                pickle.dump(df_temp, open(writing_path_file, 'wb'), protocol = 4)
            elif isinstance(df_temp,pd.DataFrame) and len(df_temp) == 0:
                print('此月份筆數為: 0 ')
                failed_times = failed_times+1
            elif not isinstance(df_temp,pd.DataFrame):
                print(f'SQL Query 錯誤LOG: \n {df_temp}')
                
            if failed_times >= failed_limit_times:
                raise ValueError("已經兩次抓不到papu_and_y")
                
        if isinstance(df_temp,pd.DataFrame):
            papu_and_y = papu_and_y.append(df_temp)
        #print(papu_and_y)
    return papu_and_y


# %%


# mlops撈資料庫現成母體
def get_papu_and_y_202503(this_prod, do_ym_list, query_function, papulation_colname, papulation_train_value,mother,
                account1=config.account , pwd1=config.pwd,
                account2=config.account_yichieh, pwd2=config.pwd_yichieh, 
                failed_limit_times = 4, y_type_name = ''):
    from Module.Model import monthdelta
    from Module.Sql_module import get_SQL_raw_data, get_SQL_raw_data2
    from datetime import date, timedelta , datetime    
    papu_and_y = pd.DataFrame()
    chage_acct = True
    failed_times = 0
    for ym in do_ym_list: 
        date =  datetime.date(datetime.strptime(ym,'%Y%m')).strftime('%Y%m')
        print(date) 

        query = query_function(this_prod , mother , date, papulation_colname)

        if type(query) == str: 
            # print('該Query function是傳回SQL語法')
            if chage_acct:
                df_temp = get_SQL_raw_data2(query, account1, pwd1)
                # print('y')
                time.sleep(5)
            else:
                df_temp = get_SQL_raw_data2(query, account2, pwd2)
                # print('N')
                time.sleep(5)
            chage_acct = not chage_acct
            time.sleep(5)
        elif isinstance(query,pd.DataFrame):
            print('該Query function是傳回DataFrame')
            df_temp = query

        if isinstance(df_temp,pd.DataFrame) and len(df_temp) > 0:
            col = 'y'
            # print(f'此月份筆數為: {len(df_temp)}')
            # print(f'此月份Y有: {df_temp[col].sum()}')
        elif isinstance(df_temp,pd.DataFrame) and len(df_temp) == 0:
            print('此月份筆數為: 0 ')
            failed_times = failed_times+1
        elif not isinstance(df_temp,pd.DataFrame):
            print(f'SQL Query 錯誤LOG: \n {df_temp}')

        if failed_times >= failed_limit_times:
            raise ValueError("已經多次抓不到papu_and_y")
                
        if isinstance(df_temp,pd.DataFrame):
            papu_and_y = papu_and_y.append(df_temp)
        #print(papu_and_y)
    return papu_and_y


# %%


#固定母體 如果已經抓過了 就不送 query
def get_papu_and_y_local(do_ym_list, query_function, papulation_colname, papulation_train_value,
                   writing_popu_path,mother,
                   account1=config.account_yichieh, pwd1=config.pwd_yichieh,
                   account2=config.account_yt, pwd2=config.pwd_yt, failed_limit_times = 4,
                   y_type_name = ''):
    from Module.Model import monthdelta
    from Module.Sql_module import get_SQL_raw_data
    from datetime import date, timedelta , datetime    
    papu_and_y = pd.DataFrame()
    chage_acct = True
    failed_times = 0
    for ym in do_ym_list: 
        date =  datetime.date(datetime.strptime(ym,'%Y%m'))
        next_month = monthdelta(date, 1)
        print(next_month)    

        writing_path_fold = str(writing_popu_path) +'/'+ str(mother) 
        if writing_popu_path != None and not os.path.exists(writing_path_fold):
            os.makedirs(writing_path_fold) 
        table_filename = 'papu_and_y' + str(y_type_name) + '_{}.pickle'.format(ym)
        writing_path_file = writing_path_fold + '/' + table_filename
        if writing_popu_path != None and os.path.exists(writing_path_file):
            print(' year of {} papu_and_y had been existed!!!!!'.format(ym))

            df_temp = pickle.load(open(writing_path_file, 'rb'))
            # 抓target y的欄位名稱
            for i, col in enumerate(df_temp.columns):
                if 'y' in col and 'yyyy' not in col:
                    y_colname = col
            size = len(df_temp)
            y_number = sum(df_temp[y_colname]==1)
            
            print(f'yyyymm: {ym} propotion: {y_number/size}')
            print(f'size of df {size} and number of y is {y_number}')

            print(' year of {} papu_and_y loading finished '.format(ym))            
        else:
            raise ValueError(f'yyyymm: {ym} 沒有先跑好母體')
        if isinstance(df_temp,pd.DataFrame):
            papu_and_y = papu_and_y.append(df_temp)
        #print(papu_and_y)
    return papu_and_y


# %%


#固定母體 如果已經抓過了 就不送 query
def ntb_get_papu_and_y(do_ym_list, query_function, papulation_colname, papulation_train_value,
                   writing_popu_path,mother,
                   account1=config.account_yt , pwd1=config.pwd_yt,
                   account2=config.account_yichieh, pwd2=config.pwd_yichieh, failed_limit_times = 4,predict_dump=False):
    from Module.Model import monthdelta
    from Module.Sql_module import get_SQL_raw_data
    from datetime import date, timedelta , datetime    
    papu_and_y = pd.DataFrame()
    chage_acct = True
    failed_times = 0
    for ym in do_ym_list: 
        date =  datetime.date(datetime.strptime(ym,'%Y%m%d'))    

        writing_path_fold = str(writing_popu_path) +'/'+ str(mother) 
        if writing_popu_path != None and not os.path.exists(writing_path_fold):
            os.makedirs(writing_path_fold) 
        table_filename = 'papu_and_y_{}.pickle'.format(ym)
        writing_path_file = writing_path_fold + '/' + table_filename
        if writing_popu_path != None and os.path.exists(writing_path_file):
            print(' year of {} papu_and_y had been existed!!!!!'.format(ym))

            df_temp = pickle.load(open(writing_path_file, 'rb'))
            
            size = len(df_temp)
            y_number = sum(df_temp['y']==1)
            
            print(f'yyyymm: {ym} propotion: {y_number/size}')
            print(f'size of df {size} and number of y is {y_number}')

            print(' year of {} papu_and_y loading finished '.format(ym))            
        else:
            # 判斷query_function是回傳
            query = query_function(date)
            if type(query) == str: 
                print('該Query function是傳回SQL語法')
                if chage_acct:
                    df_temp = get_SQL_raw_data(query, account1, pwd1)
                    time.sleep(120)
                else:
                    df_temp = get_SQL_raw_data(query, account2, pwd2)
                    time.sleep(120)
                chage_acct = not chage_acct
                time.sleep(30)
            elif isinstance(query,pd.DataFrame):
                print('該Query function是傳回DataFrame')
                df_temp = query
                
            if isinstance(df_temp,pd.DataFrame) and len(df_temp) > 0:
                print(f'此月份筆數為: {len(df_temp)}')
                if predict_dump:
                    print("預測不儲存")
                else:
                    pickle.dump(df_temp, open(writing_path_file, 'wb'), protocol = 4)
            elif isinstance(df_temp,pd.DataFrame) and len(df_temp) == 0:
                print('此月份筆數為: 0 ')
                failed_times = failed_times+1
            elif not isinstance(df_temp,pd.DataFrame):
                print(f'SQL Query 錯誤LOG: \n {df_temp}')
                
            if failed_times >= failed_limit_times:
                raise ValueError("已經兩次抓不到papu_and_y")
                
        if isinstance(df_temp,pd.DataFrame):
            papu_and_y = papu_and_y.append(df_temp)
        #print(papu_and_y)
    return papu_and_y


# %%


# def ntb_concat_all_feature(do_concat_ym_lst, mother,feature_file_path = feature_file_path_ntb , writing_path = None,
#                           drop_key_word = [], papu_and_y = pd.DataFrame(), Fill_zero=False):
    
    
#     combine_table_list = []
    
#     for ym in do_concat_ym_lst:
#         st_each_year_time = time.time()
        
#         writing_path_fold = str(writing_path) +'/'+ str(mother) 
#         table_filename = 'concat_feature_{}.pickle'.format(ym)
#         writing_path_file = writing_path_fold + '/' + table_filename
        
#         print('-----Concat datafram info------')
#         #參數與宣告
#         check_path = feature_file_path + '/' + '{}'.format(ym)
#         exist_list = listdir(check_path)
#         #先抓軌跡檔               
#         df_digital = pickle.load(open(check_path + '/軌跡{}.pickle'.format(ym), 'rb'))
#         print('軌跡{}.pickle loading finished'.format(ym))    
#         #抓取母體跟Y
#         if (not papu_and_y.empty) :         
# #         if (not papu_and_y[papu_and_y['yyyymm']==int(ym)].empty) : 
#             papu_and_y['yyyymm'] = papu_and_y['yyyymm'].astype('int')
#             papu_and_y_yyyymm = papu_and_y[papu_and_y['yyyymm']==int(ym)]
#             if not papu_and_y_yyyymm.empty:  
#                 df_papu_and_y = pd.merge(papu_and_y_yyyymm,df_digital , how='inner', left_on=['customer_id'],right_on=['uid_']).drop('uid_',axis = 1)
#                 print('papu_and_y loading finished with {} columns and {} length '.format(len(df_papu_and_y.columns), len(df_papu_and_y)))
#             else: 
#                 raise ValueError(f"年月:{ym} 筆數為0")
#         else: 
#             raise ValueError(f"papu_and_y筆數為0")
        
             
#         df_score = pickle.load(open(check_path + '/分數_'+ mother +'_{}.pickle'.format(ym), 'rb'))
#         print('分數: {}'.format(len(df_score)))
#         df_combined = pd.merge(df_papu_and_y, df_score, how='left', left_on=['customer_id'],right_on=['party_id']).drop('party_id',axis = 1)
        
#         # NA補0
#         if Fill_zero:
#             df_combined = df_combined.fillna(0)
#             print('NA補0完畢!!!')
        
# #        pickle.dump(df_combined, open(writing_path_file, 'wb'), protocol = 4)
#         locals()[ym] = df_combined
#         combine_table_list.append(locals()[ym])
            

#     outcome = pd.concat(combine_table_list, join='outer')
  
#     return outcome       


# %%


def get_recommded_build_size(df, mother, test_propotion=0.1 ):
    ##################################################
    # 樣本建議比例是透過同月份下各商品去執行不同的樣本比例不斷Retrain
    # 會獲得各個回測的AUC以及萬人覆蓋率，這兩項相加用於判斷哪個樣本比例是最佳解後
    # 將Y=1的數量以 1~2000 / 2000~10000 / >10000 進行分組
    # 分組後將樣本比例取平均作為建議的樣本比例
    # !!!!!!! 補充 價值以上跟潛客為分開給予建議樣本比例
    #
    ###############################################
    # df 需要 yyyymm & y
    #####################################
    r1 = df['yyyymm'] != max(df['yyyymm'])
    r2 = df['y'] == 1
    y1_num = len(df[r1 & r2])
    if mother == '潛客':
        if y1_num <= 2000:
            y1_propotion = 0.001477
        elif y1_num <= 10000:
            y1_propotion = 0.005346
        elif y1_num > 10000:
            y1_propotion = 0.03583
    elif mother == '非潛客':
        if y1_num <= 2000:
            y1_propotion = 0.001049
        elif y1_num <= 10000:
            y1_propotion = 0.005516
        elif y1_num > 10000:
            y1_propotion = 0.019517
    build_size = int(y1_num / y1_propotion/ (1-test_propotion) ) 
    
    if len(df[r1]) <= build_size:
        need_adjust_sample = False
    else:
        need_adjust_sample = True
    return need_adjust_sample, build_size


# %%


def down_sampling_from_df(df, recommded_build_size):
    ############################
    # 具有特徵的df 需要 yyyymm & y
    ###############################
    # 先獨立回測年月資料
    r1 = df['yyyymm'] != max(df['yyyymm'])
    backtest_ym_df = df[~r1]
    
    # need_downsample的資料
    df_train_valid = df[r1]
    
    # 設定每個年月資料大小
    train_months_n = (len(set(df['yyyymm'])) - 1 )
    target_size = int(recommded_build_size / train_months_n)
    print(f'recommded_build_size = {recommded_build_size}')
    print(f'train_months_n = {train_months_n}')
    print(f'target_size = {target_size}')
    
    def downsample(group, target_size):
        y_1_data = group[group['y'] == 1]
        y_0_data = group[group['y'] == 0]
        
        if target_size < len(y_1_data):
            raise ValueError(f"target_size ({target_size}) 小於 y=1 資料量 ({len(y_1_data)})")
        # 計算所需 y = 0資料數量
        required_y_0 = target_size - len(y_1_data)
        # 抽樣
        y_0_sampled = y_0_data.sample(n=min(required_y_0, len(y_0_data)), random_state=42)
        
        return pd.concat([y_1_data, y_0_sampled])
    
    # 按yyyymm分組並處理
    downsample_df = df_train_valid.groupby('yyyymm').apply(lambda group: downsample(group, target_size)).reset_index(drop=True)
    
    return pd.concat([downsample_df, backtest_ym_df])





