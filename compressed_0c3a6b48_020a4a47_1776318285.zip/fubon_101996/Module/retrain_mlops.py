#!/usr/bin/env python
# coding: utf-8
# %%

# %%


#上個版本 retrain_mlops_np_and_p_double_opt_detailym_fillna_20241225
def retrain_mlops_np_and_p_double_opt_detailym_fillna_20250326(this_file_path, target, papulation_colname, papulation_train_value, drop_key_word, 
                           mother_list, bins_list, hit_rate_list, frequency, edition_detail, do_ym_list, query_function, write_db_Y_N,
                           limit_size_select, limit_size_build, write_feature_Y_N, market_flag_Y_N):
    import sys
    import os
    import gc
    from IPython.display import display
    #該檔案路徑
    this_prod = this_file_path.split('/')[-1]
    # 讀取模組設定
    import Module.config as config
    # MLOPS執行參數
    algorithm = config.algorithm
    #潛客參數
    max_depth_a = config.max_depth_a
    scale_pos_weight_a = config.scale_pos_weight_a
    n_estimator_a = config.n_estimator_a
    #非潛客參數
    max_depth_b = config. max_depth_b
    scale_pos_weight_b = config.scale_pos_weight_b
    n_estimator_b = config.n_estimator_b

    write_monthly_path = config.temp_concat_path


    from Module.Sql_module import get_SQL_raw_data, write_data_to_SQL, send_table_to_sql
    from Module.Pretreatment import read_feature_by_sampling,read_feature_by_all,build_sampled_feature,get_feature_by_SOP_202503,combine_multi_year_df,downsample_by_month, if_to_large_down_sampling, get_papu_and_y_202503, get_recommded_build_size, down_sampling_from_df
    from Module.Model import monthdelta, split_data, select_feature_v230517, build_model_v230726, back_test, retrain_log_v240115, Convert_log_v240111
    from Module.Model import model_log_v230410, get_next_model_version, whether_done_next_version, get_conversion_rank, get_backtest_df_pvalue_IV
    from Module.Model import get_backtest_df_pvalue_IV
    import calendar
    from sqlalchemy import create_engine
    import time
    import pandas as pd
    import pickle
    import numpy as np
    from xgboost import XGBClassifier
    from sklearn.model_selection import train_test_split
    from sqlalchemy.types import String, Integer, Float
    from datetime import date, timedelta , datetime
    from sklearn.metrics import roc_auc_score
    from os import listdir
    from os.path import isfile, join
#     pd.set_option('display.max_rows',300)
#     pd.set_option('display.max_columns',300)

    # 判斷是設定有無問題
    if len(mother_list) == len(bins_list) :
        print(f'將會以母體執行迴圈 {mother_list} \n切分方式為 {bins_list}\n ')
    else:
        raise Exception('mother_list、bins_list長度不一致')

    query_function = query_function[0]
    for index, mother in enumerate(mother_list):
        totally_st_time = time.time()
        print(f'第{index}圈執行 {mother} Retrain ...')
        # 抓取對應 bins / query
        bins = bins_list[index]
        hit_rate = hit_rate_list[index]
        print(f'bin = {bins}')
        print(f'do_ym_list = {do_ym_list}')# 透過DB TABLE(參照資訊檔)抓取下一個版本名稱
        new_edition = get_next_model_version(this_prod,target,mother,frequency,edition_detail, table_name = config.ref_info)
        print(f'new_edition = {new_edition}')

        if not whether_done_next_version(this_file_path, this_prod, mother, new_edition, target, algorithm,
                                    db_table_rt=config.retrain_log, db_table_md=config.model_log,
                                    account=config.account, pwd=config.pwd):  
            time.sleep(5)

            ######################################################################################################### 
            print('!!!!開始抓取資料')
            # 先抓一次
            
            papu_and_y = get_papu_and_y_202503(this_prod, do_ym_list, query_function, papulation_colname, papulation_train_value,mother)
            limit_times = 1
            try_times = 1

            # 重複抓
            while set(do_ym_list)!=set(papu_and_y['yyyymm'].astype('str')) and try_times <= limit_times:
                papu_and_y = get_papu_and_y_202503(this_prod, do_ym_list, query_function, papulation_colname, papulation_train_value,mother)
                try_times = try_times+1       

            print('papu_and_y :')
            display(papu_and_y.head())
            # 排除例外(例如:舊戶)
            papu_and_y = papu_and_y[papu_and_y[papulation_colname].isin(papulation_train_value)]
            papu_and_y.drop([papulation_colname], axis=1, inplace=True)

            # 將母體與特徵左右拼接
            # concat_df_outcome = get_feature_by_SOP_202503(do_ym_list, mother, drop_key_word, papu_and_y, this_prod, Fill_zero=True)

            # 將各年月的DF上下拼接
            # df_combined = combine_multi_year_df(do_ym_list, concat_df_outcome)
            df_combined = get_feature_by_SOP_202503(do_ym_list, mother, drop_key_word, papu_and_y, this_prod, Fill_zero=True)
            print(f'df_combined.shape = {df_combined.shape}')
            
            # 清出空間
            del papu_and_y
            gc.collect()

            # 額外縮減至每個年月最多10萬筆(用於select_feature)
            # concat_df_outcome_redeuced = if_to_large_down_sampling(do_ym_list, concat_df_outcome, limit_size=limit_size_select)
            # df_combined_redeuced = combine_multi_year_df(do_ym_list, concat_df_outcome_redeuced)
            
            df_combined_redeuced = downsample_by_month(df_combined,limit_size_per_month=limit_size_select,y_col='y',month_col='yyyymm',random_state=42,replace=False)
            
            # 清出空間
            del df_combined
            gc.collect()

            print(f'df_combined_redeuced.shape = {df_combined_redeuced.shape}')

            # 清出空間
            # del papu_and_y
            # del concat_df_outcome
            # del concat_df_outcome_redeuced
            # gc.collect()

            X_train_rdc, y_train_rdc, X_test_rdc, y_test_rdc = split_data(df_combined_redeuced, train_yyyymm=list(df_combined_redeuced['yyyymm'].sort_values().unique()[:-1]))
            feat_imp = select_feature_v230517(X_train_rdc, y_train_rdc, X_test_rdc, y_test_rdc, this_file_path,
                                              this_prod, mother, target, new_edition, algorithm)
            cols_top100 = feat_imp.loc[:100]['feature'].tolist()

            # 釋出空間
            del X_train_rdc
            del y_train_rdc
            del X_test_rdc
            del y_test_rdc
            del df_combined_redeuced
            gc.collect()

            file_path = write_monthly_path + '/' + mother + '_' + this_prod + '.pickle'
        
            if os.path.exists(file_path):
                with open(file_path, "rb") as f:
                    df_combined = pickle.load(f)

            # 若是做商品行銷類，則透過建議的母體比例調整正式建立模型的樣本比例
            if market_flag_Y_N:
                need_adjuste_sample, recommded_build_size = get_recommded_build_size(df_combined[['customer_id', 'yyyymm', 'y']], mother)

                if need_adjuste_sample:
                    print(f'現行流程富證日盛訓練資料每月抓取{limit_size_build}個樣本')
                    print(f'最後資料數為{len(df_combined)} 大於 建議的樣本數為{recommded_build_size}，故執行後續調整比例!!')
                    df_combined = down_sampling_from_df(df_combined, recommded_build_size)    
                else:
                    print(f'現行流程富證日盛訓練資料每月抓取{limit_size_build}個樣本')
                    print(f'最後資料數為{len(df_combined)} 小於 建議的樣本數為{recommded_build_size}，故不執行後續調整比例!!')

            # 以較大資料集，正式建模
            based_col = ['customer_id', 'yyyymm', 'y']
            X_train, y_train, X_test, y_test = split_data(df_combined[based_col+cols_top100], 
                                                          train_yyyymm=list(df_combined['yyyymm'].sort_values().unique()[:-1]))
            model, train_auc, test_auc,test_level_df, model_imp = build_model_v230726(X_train, y_train, X_test, y_test, cols_top100, this_file_path, 
                                                                           this_prod, mother, target, bins, new_edition, max_depth = max_depth_b, 
                                                                           scale_pos_weight = scale_pos_weight_b, n_estimator = n_estimator_b, algorithm= algorithm)
            print('cols_impt_top100 : ')
            display(model_imp)
            print('test_level_df: ')
            display(test_level_df)

            # 以最新年月進行回測並產出效度
            backtest_auc, vali_level_df, vali_predict_df, df_pred_and_features = back_test(df_combined, model, backtest_yyyymm=[df_combined['yyyymm'].sort_values().unique()[-1]], bins = bins)
            print(f'vali_level_df : ')
            display(vali_level_df)
            print(f'vali_predict_df.head() : ')
            display(vali_predict_df.head())
            print(f'vali_predict_df.shape :  {vali_predict_df.shape}\n')
            print(f'df_pred_and_features.columns : \n {df_pred_and_features.columns}\n')
            print(f'df_pred_and_features.shape : \n {df_pred_and_features.shape}\n')

            # 以詳細切分方法進行最新年月回測並產出效度
            backtest_auc_dt, vali_level_df_dt, vali_predict_df_dt, df_pred_and_features_dt =             back_test(df_combined, model, backtest_yyyymm=[df_combined['yyyymm'].sort_values().unique()[-1]],
                      bins = [0,100,200,300,400,500,600,700,800,900,
                              1000,2000,3000,4000,5000,6000,7000,8000,9000,10000,
                              11000,12000,13000,14000,15000,16000,17000,18000,19000,20000,
                              30000,40000,50000,60000,70000,80000,90000,100000,
                              120000,140000,160000,180000,200000,
                              1000000])
#             print(f'vali_level_df_dt : ')
            display(vali_level_df_dt)
#             print(f'vali_predict_df_dt.head() : ')
            display(vali_predict_df_dt.head())
            print(f'vali_predivali_predict_df_dtct_df.shape :  {vali_predict_df_dt.shape}\n')
            print(f'df_pred_and_features_dt.columns : \n {df_pred_and_features_dt.columns}\n')
            print(f'df_pred_and_features_dt.shape : \n {df_pred_and_features_dt.shape}\n')

            # 寫出PICKLE回測等級
            _pickle_dir = config.storage_root + '/processed/MLops/'+this_prod+'/'+mother
            os.makedirs(_pickle_dir, exist_ok=True) 
            pickle.dump(vali_predict_df_dt, open(config.storage_root + '/processed/MLops/'+this_prod+'/'+mother+'/'+algorithm + '_vali_pred_df_detail' + this_prod +'_' + str(new_edition) + '_' + mother + '.pickle' , 'wb'))
            
            # 行銷相關才做轉換率
            if market_flag_Y_N:

                hit_rate_setting_bin = []
                for ht in sorted([0]+hit_rate, reverse=True):
                        if  ht == 0:
                            hit_rate_setting_bin.append( "C{:02d}".format(int(round(ht * 100))) )
                        elif  ht < 0.001:
                            hit_rate_setting_bin.append( "C{:04d}".format(int(round(ht * 10000))) )
                        elif  ht < 0.01:
                            hit_rate_setting_bin.append( "C{:03d}".format(int(round(ht * 1000))) )
                        else:
                            hit_rate_setting_bin.append( "C{:02d}".format(int(round(ht * 100))) )                

                CHANCE_TEST_bin, CHANCE_TEST_num, CHANCE_TEST_hit_rate, CHANCE_TEST_prob = get_conversion_rank(vali_predict_df_dt, hit_rate)
                # retrain_log
                log_retrain = retrain_log_v240115(False, this_prod, mother, df_combined, X_train, y_train,test_level_df, vali_level_df,
                                                  train_auc, test_auc, backtest_auc, new_edition, table_name = config.retrain_log,
                                                  vali_level_df_detail=vali_level_df_dt, vali_predict_df_detail=vali_predict_df_dt,
                                                  CHANCE_TEST_bin=CHANCE_TEST_bin, CHANCE_TEST_num=CHANCE_TEST_num, 
                                                  CHANCE_TEST_hit_rate=CHANCE_TEST_hit_rate, CHANCE_TEST_prob=CHANCE_TEST_prob)
                print(f'retrain_log :')
                display(log_retrain)

                # model_log
                log_model = model_log_v230410(False, this_prod, mother, target, algorithm, hit_rate_setting_bin, new_edition, table_name = config.model_log)
                print(f'model_log :')
                display(log_model)



                log_retrain_v230410 = retrain_log_v240115(write_db_Y_N, this_prod, mother, df_combined, X_train, y_train,test_level_df,
                                                          vali_level_df, train_auc, test_auc, backtest_auc, new_edition, table_name = config.retrain_log,
                                                          vali_level_df_detail=vali_level_df_dt, vali_predict_df_detail=vali_predict_df_dt,
                                                          CHANCE_TEST_bin=CHANCE_TEST_bin, CHANCE_TEST_num=CHANCE_TEST_num, 
                                                          CHANCE_TEST_hit_rate=CHANCE_TEST_hit_rate, CHANCE_TEST_prob=CHANCE_TEST_prob)
                log_model_v230410 = model_log_v230410(write_db_Y_N, this_prod, mother, target, algorithm, hit_rate_setting_bin, new_edition, 
                                                      table_name = config.model_log)

                # 額外寫出轉換率對照表
                detail_hit_rate  = list(map(lambda x: round(x*0.0001,4), range(10)))[1:]  + list(map(lambda x: round(x*0.001,3), range(10)))[1:] + list(map(lambda x: round(x*0.01,2), range(26)))[1:]
                CHANCE_TEST_bin_dt, CHANCE_TEST_num_dt, CHANCE_TEST_hit_rate_dt, CHANCE_TEST_prob_dt = get_conversion_rank(vali_predict_df_dt, detail_hit_rate)
                conver_log = Convert_log_v240111(False, this_prod, mother, df_combined,
                                            backtest_auc, new_edition, table_name = config.convert_log,
                                           CHANCE_TEST_bin=CHANCE_TEST_bin_dt, CHANCE_TEST_num=CHANCE_TEST_num_dt, 
                                            CHANCE_TEST_hit_rate=CHANCE_TEST_hit_rate_dt, CHANCE_TEST_prob=CHANCE_TEST_prob_dt)
                print(f'conver_log :')
                display(conver_log)
                conver_log = Convert_log_v240111(write_db_Y_N, this_prod, mother, df_combined,
                                            backtest_auc, new_edition, table_name = config.convert_log,
                                           CHANCE_TEST_bin=CHANCE_TEST_bin_dt, CHANCE_TEST_num=CHANCE_TEST_num_dt, 
                                            CHANCE_TEST_hit_rate=CHANCE_TEST_hit_rate_dt, CHANCE_TEST_prob=CHANCE_TEST_prob_dt) 
            else:
                # retrain_log
                log_retrain = retrain_log_v240115(False, this_prod, mother, df_combined, X_train, y_train,test_level_df, vali_level_df,
                                                  train_auc, test_auc, backtest_auc, new_edition, table_name = config.retrain_log,
                                                  vali_level_df_detail=vali_level_df_dt, vali_predict_df_detail=vali_predict_df_dt,
                                                  )
                print(f'retrain_log :')
                display(log_retrain)

                # model_log
                log_model = model_log_v230410(False, this_prod, mother, target, algorithm, bins,new_edition, table_name = config.model_log)
                print(f'model_log :')
                display(log_model)



                log_retrain_v230410 = retrain_log_v240115(write_db_Y_N, this_prod, mother, df_combined, X_train, y_train,test_level_df,
                                                          vali_level_df, train_auc, test_auc, backtest_auc, new_edition, table_name = config.retrain_log,
                                                          vali_level_df_detail=vali_level_df_dt, vali_predict_df_detail=vali_predict_df_dt,
                                                          )
                log_model_v230410 = model_log_v230410(write_db_Y_N, this_prod, mother, target, algorithm, bins, new_edition, 
                                                      table_name = config.model_log)

            ## If retrain_auc < 0.7 then print

            if test_auc < 0.7:
                print('{}retrain_auc < 0.7'.format(mother))


            print('{} 花了 {} min'.format(mother,(time.time()-totally_st_time)/60))
            ############# START ##########################################
            # 額外針對回測月份計算p-value及IV值
            #
            # calcu_time = time.time()
            # calcuate_top_n = 20

            # pvalue_col = ['y'] + list(model_imp['feature'])[0:calcuate_top_n]
            # backtest_df_pvalue_IV = get_backtest_df_pvalue_IV(this_prod, target, mother, df_combined, pvalue_col)

            # backtest_df_pvalue_IV = backtest_df_pvalue_IV[['prod', 'target', 'population', 'test_period', 'feature', 'feature_chinese',
            #                        'dtype', 'p_value', 'IV', 'error_msg']]
            #  # 小數點126位限制轉換
            # lower_limit = 1E-126
            # def clip_float_values(value):
            #     if np.isfinite(value):
            #         if abs(value) < lower_limit and value != 0:
            #             return np.sign(value) * lower_limit
            #     return value

            # backtest_df_pvalue_IV['p_value'] = backtest_df_pvalue_IV['p_value'].apply(clip_float_values)

            # send_table_to_sql(backtest_df_pvalue_IV, 'impt_feature_statistic', account=config.account, pwd=config.pwd)
            # print('{} 計算p-value&IV值花了 {} min'.format(mother,(time.time()-calcu_time)/60))
            ######### END ###################################################                  

            del X_train
            del y_train
            del X_test
            del y_test
            del df_combined
            del vali_predict_df
            del df_pred_and_features
            gc.collect()

            print(f'{this_prod}_{mother}_{new_edition} 執行完畢，先跳出迴圈!')
            break
        else:
            print(f'{this_prod}_{mother}_{new_edition} 先前已執行過了，執行下個母體!')    


# %%


#上個版本 retrain_mlops_np_and_p_double_opt_fillna
def retrain_mlops_np_and_p_double_opt_fillna_20250326(this_file_path, target, papulation_colname, papulation_train_value, drop_key_word, 
                           mother_list, bins_list, frequency, edition_detail, do_ym_list, query_function, write_db_Y_N,
                           limit_size_select, limit_size_build, write_feature_Y_N):
    import sys
    import os
    import gc
    from IPython.display import display
    #該檔案路徑
    this_prod = this_file_path.split('/')[-1]
    # 讀取模組設定
    import Module.config as config
    # MLOPS執行參數
    algorithm = config.algorithm
    #潛客參數
    max_depth_a = config.max_depth_a
    scale_pos_weight_a = config.scale_pos_weight_a
    n_estimator_a = config.n_estimator_a
    #非潛客參數
    max_depth_b = config. max_depth_b
    scale_pos_weight_b = config.scale_pos_weight_b
    n_estimator_b = config.n_estimator_b

    from Module.Sql_module import get_SQL_raw_data, write_data_to_SQL, send_table_to_sql
    from Module.Pretreatment import read_feature_by_sampling,read_feature_by_all,build_sampled_feature,get_feature_by_SOP_202503,combine_multi_year_df, if_to_large_down_sampling, get_papu_and_y_202503, get_recommded_build_size, down_sampling_from_df
    from Module.Model import monthdelta, split_data, select_feature_v230517, build_model_v230726, back_test, retrain_log_v240115, Convert_log_v240111
    from Module.Model import model_log_v230410, retrain_log_v230726, get_next_model_version, whether_done_next_version, get_conversion_rank, get_backtest_df_pvalue_IV
    from Module.Model import get_backtest_df_pvalue_IV
    import calendar
    from sqlalchemy import create_engine
    import time
    import pandas as pd
    import pickle
    import numpy as np
    from xgboost import XGBClassifier
    from sklearn.model_selection import train_test_split
    from sqlalchemy.types import String, Integer, Float
    from datetime import date, timedelta , datetime
    from sklearn.metrics import roc_auc_score
    from os import listdir
    from os.path import isfile, join
#     pd.set_option('display.max_rows',300)
#     pd.set_option('display.max_columns',300)

    # 判斷是設定有無問題
    if len(mother_list) == len(bins_list):
        print(f'將會以母體執行迴圈 {mother_list} \n切分方式為 {bins_list}\n ')
    else:
        raise Exception('mother_list、bins_list長度不一致')
    
    query_function = query_function[0]
    for index, mother in enumerate(mother_list):

        totally_st_time = time.time()
        print(f'第{index}圈執行 {mother} Retrain ...')
        bins = bins_list[index]
        print(f'bin = {bins}')
        # 透過DB TABLE(參照資訊檔)抓取下一個版本名稱
        new_edition = get_next_model_version(this_prod,target,mother,frequency,edition_detail, table_name = config.ref_info)
        
        if not whether_done_next_version(this_file_path, this_prod, mother, new_edition, target, algorithm,
                                        db_table_rt=config.retrain_log, db_table_md=config.model_log,
                                        account=config.account_yt, pwd=config.pwd_yt):   
            time.sleep(15)
            print(f'do_ym_list = {do_ym_list}')

            ############################################################################################################
            print('!!!!開始抓取資料')
            # 先抓一次
            papu_and_y = get_papu_and_y_202503(this_prod, do_ym_list, query_function, papulation_colname, papulation_train_value,mother)
            limit_times = 1
            try_times = 1
            
            # 重複抓
            while set(do_ym_list)!=set(papu_and_y['yyyymm'].astype('str')) and try_times <= limit_times:
                papu_and_y = get_papu_and_y_202503(this_prod, do_ym_list, query_function, papulation_colname, papulation_train_value,mother)
                try_times = try_times+1    
            
            print('papu_and_y :')
#             display(papu_and_y.head())
            # 排除例外(例如:舊戶)
            papu_and_y = papu_and_y[papu_and_y[papulation_colname].isin(papulation_train_value)]
            papu_and_y.drop([papulation_colname], axis=1, inplace=True)
            
            
            # 將母體與特徵左右拼接
            concat_df_outcome = get_feature_by_SOP_202503(do_ym_list, mother, drop_key_word, papu_and_y, this_prod, Fill_zero=True)

            # 將各年月的DF上下拼接
            df_combined = combine_multi_year_df(do_ym_list, concat_df_outcome)
            print(f'df_combined.shape = {df_combined.shape}')

            # 額外縮減至每個年月最多10萬筆(用於select_feature)
            concat_df_outcome_redeuced = if_to_large_down_sampling(do_ym_list, concat_df_outcome, limit_size=limit_size_select)
            df_combined_redeuced = combine_multi_year_df(do_ym_list, concat_df_outcome_redeuced)
            print(f'df_combined_redeuced.shape = {df_combined_redeuced.shape}')
            
            # 清出空間
            del papu_and_y
            del concat_df_outcome
            del concat_df_outcome_redeuced
            gc.collect()

                
            # 以較小資料集，建模選取重要特徵
            X_train_rdc, y_train_rdc, X_test_rdc, y_test_rdc = split_data(df_combined_redeuced, train_yyyymm=list(df_combined_redeuced['yyyymm'].sort_values().unique()[:-1]))
            feat_imp = select_feature_v230517(X_train_rdc, y_train_rdc, X_test_rdc, y_test_rdc, this_file_path,
                                              this_prod, mother, target, new_edition, algorithm)
            cols_top100 = feat_imp.loc[:100]['feature'].tolist()

            # 釋出空間
            del X_train_rdc
            del y_train_rdc
            del X_test_rdc
            del y_test_rdc
            del df_combined_redeuced
            gc.collect()

            # 以較大資料集，正式建模
            based_col = ['customer_id', 'yyyymm', 'y']
            X_train, y_train, X_test, y_test = split_data(df_combined[based_col+cols_top100], 
                                                          train_yyyymm=list(df_combined['yyyymm'].sort_values().unique()[:-1]))
            model, train_auc, test_auc,test_level_df, model_imp = build_model_v230726(X_train, y_train, X_test, y_test, cols_top100, this_file_path, 
                                                                           this_prod, mother, target, bins, new_edition, max_depth = max_depth_b, 
                                                                           scale_pos_weight = scale_pos_weight_b, n_estimator = n_estimator_b, algorithm= algorithm)
            print('cols_impt_top100 : ')
            display(model_imp)
            print('test_level_df: ')
            display(test_level_df)

            # 以最新年月進行回測並產出效度
            backtest_auc, vali_level_df, vali_predict_df, df_pred_and_features = back_test(df_combined, model, backtest_yyyymm=[df_combined['yyyymm'].sort_values().unique()[-1]], bins = bins)
            print(f'vali_level_df : ')
            display(vali_level_df)
            print(f'vali_predict_df.head() : ')
            display(vali_predict_df.head())
            print(f'vali_predict_df.shape :  {vali_predict_df.shape}\n')
            print(f'df_pred_and_features.columns : \n {df_pred_and_features.columns}\n')
            print(f'df_pred_and_features.shape : \n {df_pred_and_features.shape}\n')

            # 以詳細切分方法進行最新年月回測並產出效度
            backtest_auc_dt, vali_level_df_dt, vali_predict_df_dt, df_pred_and_features_dt =             back_test(df_combined, model, backtest_yyyymm=[df_combined['yyyymm'].sort_values().unique()[-1]],
                      bins = [0,1000,2000,3000,4000,5000,6000,7000,8000,9000,10000,
                              11000,12000,13000,14000,15000,16000,17000,18000,19000,20000,
                              30000,40000,50000,60000,70000,80000,90000,100000,
                              120000,140000,160000,180000,200000,
                              1000000])
            print(f'vali_level_df_dt : ')
            display(vali_level_df_dt)
            print(f'vali_predict_df_dt.head() : ')
            display(vali_predict_df_dt.head())
            print(f'vali_predivali_predict_df_dtct_df.shape :  {vali_predict_df_dt.shape}\n')
            print(f'df_pred_and_features_dt.columns : \n {df_pred_and_features_dt.columns}\n')
            print(f'df_pred_and_features_dt.shape : \n {df_pred_and_features_dt.shape}\n')

            # 寫出PICKLE回測等級
            _pickle_dir = config.storage_root + '/processed/MLops/'+this_prod+'/'+mother
            os.makedirs(_pickle_dir, exist_ok=True) 
            pickle.dump(vali_predict_df_dt, open(config.storage_root + '/processed/MLops/'+this_prod+'/'+mother+'/'+algorithm + '_vali_pred_df_detail' + this_prod +'_' + str(new_edition) + '_' + mother + '.pickle' , 'wb'))
            # retrain_log
            log_retrain = retrain_log_v230726(False, this_prod, mother, df_combined, X_train, y_train,test_level_df, vali_level_df,
                                              train_auc, test_auc, backtest_auc, new_edition, table_name = config.retrain_log,
                                              vali_level_df_detail=vali_level_df_dt )
            print(f'retrain_log :')
            display(log_retrain)

            # model_log
            log_model = model_log_v230410(False, this_prod, mother, target, algorithm, bins,new_edition, table_name = config.model_log)
            print(f'model_log :')
            display(log_model)



            log_retrain_v230410 = retrain_log_v230726(write_db_Y_N, this_prod, mother, df_combined, X_train, y_train,test_level_df,
                                                      vali_level_df, train_auc, test_auc, backtest_auc, new_edition, table_name = config.retrain_log,
                                                      vali_level_df_detail=vali_level_df_dt )
            log_model_v230410 = model_log_v230410(write_db_Y_N, this_prod, mother, target, algorithm, bins, new_edition, 
                                                  table_name = config.model_log)

            ## If retrain_auc < 0.7 then print

            if test_auc < 0.7:
                print('{}retrain_auc < 0.7'.format(mother))

            print('{} 花了 {} min'.format(mother,(time.time()-totally_st_time)/60))
            
            
            ############# START ##########################################
            # 額外針對回測月份計算p-value及IV值
            #
            # calcu_time = time.time()
            # calcuate_top_n = 20

            
            
            # pvalue_col = ['y'] + list(model_imp['feature'])[0:calcuate_top_n]
            # backtest_df_pvalue_IV = get_backtest_df_pvalue_IV(this_prod, target, mother, df_combined, pvalue_col)

            # backtest_df_pvalue_IV = backtest_df_pvalue_IV[['prod', 'target', 'population', 'test_period', 'feature', 'feature_chinese',
            #                        'dtype', 'p_value', 'IV', 'error_msg']]
            #  # 小數點126位限制轉換
            # lower_limit = 1E-126
            # def clip_float_values(value):
            #     if np.isfinite(value):
            #         if abs(value) < lower_limit and value != 0:
            #             return np.sign(value) * lower_limit
            #     return value

            # backtest_df_pvalue_IV['p_value'] = backtest_df_pvalue_IV['p_value'].apply(clip_float_values)
            
            # send_table_to_sql(backtest_df_pvalue_IV, 'impt_feature_statistic', account=config.account, pwd=config.pwd)
            # print('{} 計算p-value&IV值花了 {} min'.format(mother,(time.time()-calcu_time)/60))
            ######### END ###################################################                  


            del X_train
            del y_train
            del X_test
            del y_test
            del df_combined
            del vali_predict_df
            del df_pred_and_features
            gc.collect()
            
            print(f'{this_prod}_{mother}_{new_edition} 執行完畢，先跳出迴圈!')
            break
        else:
            print(f'{this_prod}_{mother}_{new_edition} 先前已執行過了，執行下個母體!')        

